//
//  BindDeviceby4GViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2025/3/14.
//

import Foundation
import Combine
import YJOpenSDK
final class BindDeviceby4GViewModel {
    private(set) lazy var loading = PassthroughSubject<Bool, Never>()
    private(set) lazy var tips = PassthroughSubject<String, Never>()
    private(set) lazy var bindEnabled = PassthroughSubject<(Bool), Never>()
    private(set) lazy var binging = PassthroughSubject<Bool, Never>()
    private(set) lazy var bindSuccess = PassthroughSubject<String, Never>()
    private var cancels: Set<AnyCancellable> = []
    private let productKey: String
    private let deviceName: String
    init(
        productKey: String,
        deviceName: String
    ) {
        self.productKey = productKey
        self.deviceName = deviceName
        
        loading.sink(receiveValue: { [weak self] v in
            self?.bindEnabled.send(!v)
        }).store(in: &cancels)
        
        loading.send(false)
    }
    
    deinit {
//        YJBindDeviceBySoftAP.clearup()
    }
}

extension BindDeviceby4GViewModel {
    func prepareBind() {
        loading.send(true)
        binging.send(true)
        YJBindDeviceByCellular.bindDevice(productKey: productKey, deviceName: deviceName) { [weak self] result, error in
            if error != nil {
                self?.loading.send(false)
                self?.binging.send(false)
            }
            guard let result, let bindStatus = result["bindStatus"] else {
                return
            }
            guard bindStatus == "2", let did = result["deviceId"] else {
                self?.tips.send("绑定失败")
                self?.binging.send(false)
                return
            }
            self?.tips.send("绑定成功")
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: {
                self?.binging.send(false)
                self?.bindSuccess.send(did)
            })
        }
    }
    
    func stopBind() {
        YJBindDeviceByCellular.stopBindDevice()
    }
}
