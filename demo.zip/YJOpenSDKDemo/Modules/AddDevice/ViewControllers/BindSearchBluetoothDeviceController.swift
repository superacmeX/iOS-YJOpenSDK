//
//  BindSearchBluetoothDeviceController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2025/2/27.
//

import UIKit
import YJOpenSDK
import FJRouter
final class BindSearchBluetoothDeviceController: UIViewController {
    init(productKey: String, deviceName: String) {
        self.productKey = productKey
        self.deviceName = deviceName
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private let productKey: String
    private let deviceName: String
    
    private lazy var nextButton = UIButton()
    private var searchDeviceInfo: YJBLEScanDeviceInfo? {
        didSet {
            nextButton.isEnabled = searchDeviceInfo != nil
        }
    }
    deinit {
        YJBindDeviceByBLE.release()
    }
}

extension BindSearchBluetoothDeviceController {
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        searchDevice()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        nextButton.setBackgroundImage(UIImage(color: .theme, size: nextButton.bounds.size, cornerRadius: 12), for: .normal)
        nextButton.setBackgroundImage(UIImage(color: .gray, size: nextButton.bounds.size, cornerRadius: 12), for: .disabled)
    }
}

private extension BindSearchBluetoothDeviceController {
    func setup() {
        view.backgroundColor = .bgColor
        title = "搜索设备"
        navigationItem.backButtonDisplayMode = .minimal
        nextButton.isEnabled = false
        nextButton.setAttributedTitle(NSAttributedString(string: "下一步", attributes: [.foregroundColor: UIColor.white]), for: [])
        view.addSubview(nextButton)
        nextButton.addTarget(self, action: #selector(onTap), for: .primaryActionTriggered)
        nextButton.snp.makeConstraints { make in
            make.left.right.equalTo(view).inset(18)
            make.height.equalTo(50)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).inset(30)
        }
    }
    
    func searchDevice() {
        view.showIndicator()
        YJBindDeviceByBLE.scanDevice { [weak self] scanDeviceInfo, error in
            guard let self, let scanDeviceInfo, let display = scanDeviceInfo.display,
            let name = display.split(separator: ":").last,
            self.deviceName.contains(name) else {
                return
            }
            self.view.hideIndicator()
            YJBindDeviceByBLE.stopScan()
            self.searchDeviceInfo = scanDeviceInfo
        }
    }
    
    @IBAction func onTap() {
        FJRouter.jump().go(.name("bluetoothBind", params: ["pk": productKey, "dn": deviceName]), extra: self.searchDeviceInfo, from:  self)
    }
}
