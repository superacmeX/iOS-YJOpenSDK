//
//  BindDeviceby4GController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2025/3/14.
//

import UIKit
import Combine

final class BindDeviceby4GController: UIViewController {
    init(productKey: String, deviceName: String) {
        self.productKey = productKey
        self.deviceName = deviceName
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private let productKey: String
    private let deviceName: String
    private var viewModel: BindDeviceby4GViewModel!
    private var cancels: Set<AnyCancellable> = []
    private var backItem: UIBarButtonItem!
    private(set) lazy var bindButton = UIButton()
}

extension BindDeviceby4GController {
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        bind()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        bindButton.setBackgroundImage(UIImage(color: .theme, size: bindButton.bounds.size, cornerRadius: 12), for: .normal)
        bindButton.setBackgroundImage(UIImage(color: .gray, size: bindButton.bounds.size, cornerRadius: 12), for: .disabled)
    }
}

private extension BindDeviceby4GController {
    func setup() {
        title = "4G绑定"
        view.backgroundColor = .bgColor
        backItem = UIBarButtonItem(image: UIImage(systemName: "chevron.left"), style: .plain, target: self, action: #selector(self.onBack))
        bindButton.setAttributedTitle(NSAttributedString(string: "开始绑定", attributes: [.font: UIFont.systemFont(ofSize: 14), .foregroundColor: UIColor.white]), for: [])
        bindButton.isEnabled = true
        view.addSubview(bindButton)
        bindButton.snp.makeConstraints { make in
            make.left.right.equalTo(view).inset(24)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).inset(24)
            make.height.equalTo(50)
        }
    }
    
    @IBAction func onBack() {
        let alertVC = UIAlertController(title: "确定停止绑定设备吗?", message: nil, preferredStyle: .alert)
        let cancel = UIAlertAction(title: "继续", style: .default)
        let ok = UIAlertAction(title: "停止", style: .destructive) { [weak self] _ in
            self?.viewModel.stopBind()
        }
        alertVC.addAction(cancel)
        alertVC.addAction(ok)
        present(alertVC, animated: true)
    }
    
    func bind() {
        viewModel = BindDeviceby4GViewModel(
            productKey: productKey,
            deviceName: deviceName
        )
        
        viewModel.loading.sink(receiveValue: { [weak self] loading in
            loading ? self?.view.showIndicator() : self?.view.hideIndicator()
        }).store(in: &cancels)
        
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.binging.sink(receiveValue: { [weak self] binging in
            self?.navigationItem.leftBarButtonItem = binging ? self?.backItem : nil
        }).store(in: &cancels)
        
        viewModel.bindSuccess.sink(receiveValue: { [weak self] did in
            self?.navigationController?.popToRootViewController(animated: true)
        }).store(in: &cancels)
        
        viewModel.bindEnabled.sink(receiveValue: { [weak self] e in
            self?.bindButton.isEnabled = e
        }).store(in: &cancels)
        
        bindButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { [weak self] in
            self?.viewModel.prepareBind()
        }).store(in: &cancels)
    }
}
