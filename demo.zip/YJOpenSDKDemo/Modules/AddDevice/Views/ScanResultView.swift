//
//  ScanResultView.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/25.
//

import UIKit
import SDWebImage
final class ScanResultView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private(set) lazy var nextButton = UIButton()
}

extension ScanResultView {
    override func layoutSubviews() {
        super.layoutSubviews()
        nextButton.setBackgroundImage(UIImage(color: .theme, size: nextButton.bounds.size, cornerRadius: 12), for: .normal)
        nextButton.setBackgroundImage(UIImage(color: .gray, size: nextButton.bounds.size, cornerRadius: 12), for: .disabled)
    }
}

private extension ScanResultView {
    func setup() {
        let descLabel = UILabel()
        descLabel.numberOfLines = 0
        
        let str = """
        请按以下操作进行设备重置:
        1: 长按开关键5秒, 听到提示设备已开机
        2: 短按开关键2次,听到提示重置成功
        3: 看到设备蓝灯闪烁
        """
        
        let attr = NSMutableAttributedString(string: str, attributes: [.font: UIFont.systemFont(ofSize: 14), .foregroundColor: UIColor.gray])
        
        let r1 = (str as NSString).range(of: "请按以下操作进行设备重置:")
        attr.addAttributes([.font: UIFont.boldSystemFont(ofSize: 18), .foregroundColor: UIColor.red], range: r1)
        
        let style = NSMutableParagraphStyle()
        style.lineSpacing = 8
        
        let r = (str as NSString).range(of: str)
        attr.addAttributes([.paragraphStyle: style], range: r)
        
        descLabel.attributedText = attr
        addSubview(descLabel)
        descLabel.snp.makeConstraints { make in
            make.left.right.equalTo(self).inset(24)
            make.top.equalTo(safeAreaLayoutGuide.snp.top).offset(24)
        }
        
        nextButton.isEnabled = false
        nextButton.setAttributedTitle(NSAttributedString(string: "下一步", attributes: [.foregroundColor: UIColor.white]), for: [])
        addSubview(nextButton)
        nextButton.snp.makeConstraints { make in
            make.left.right.equalTo(self).inset(18)
            make.height.equalTo(50)
            make.bottom.equalTo(safeAreaLayoutGuide.snp.bottom).inset(30)
        }
    }
    
    func updateUI() {
        
    }
}
