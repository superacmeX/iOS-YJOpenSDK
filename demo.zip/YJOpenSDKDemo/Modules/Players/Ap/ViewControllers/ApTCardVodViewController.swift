//
//  ApTCardVodViewController.swift
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2025/3/1.
//

import UIKit
import YJOpenSDK

final class ApTCardVodViewController: UIViewController {
    private var kTag: String = ""
    private var player: YJRMPApVodPlayer?
    private var videoBaseView:      UIView = UIView()
    private var playerVideoView:    YJRMPVideoView? = nil
    private var link:               YJRMPApLink? = nil
    private var speedIdx:   Int    = 0
    private let speedArr: [NSNumber] = [1, 4, 8, 16].map { NSNumber(value: $0) }
    private var progressLabel:      UILabel?
    private var downloader: YJRMPMonoDownloader?
    private var downloadBtn: UIButton?
    private var downloadMgr: YJRMPDownloadManager?

    init() {
        kTag = String(describing: type(of: self))
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        self.link?.disconnect(withResult: nil)
        self.link?.deInit()
        print("\(kTag).deinit")
    }

    private lazy var loadingIndicator: UIActivityIndicatorView = {
        var type: UIActivityIndicatorView.Style = .whiteLarge
        if #available(iOS 13.0, *) {
            type = .large
        }
        let indicator = UIActivityIndicatorView(style: type)
        indicator.color = UIColor.green
        self.videoBaseView.addSubview(indicator)
        indicator.snp.makeConstraints { make in
            make.center.equalTo(self.videoBaseView)
        }
        return indicator
    }()
}

extension ApTCardVodViewController {

    override func viewDidLoad() {
        setUpUI()
        setUpPlayer()
    }
}

// MARK: YJRMPlayerDelegate
extension ApTCardVodViewController: YJRMPlayerDelegate {

    func onBufferStateUpdate(player: Any?, state: YJRMPlayerBufferState, bufferDurationMillis: Int) {
        print("\(kTag).\(#function)--\(#line), state=\(state), bufferDurationMillis=\(bufferDurationMillis)")

        switch state {
        case .loading:
            startLoading()
        case .ready:
            stopLoading()
        default:
            break
        }
    }

    func onError(player: Any?, type: YJRMPlayerErrorType, code: YJRMPlayerErrorCode, description: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), type=\(type.rawValue), code=\(code.rawValue), desc=\(String(describing: description))")

        let tips = "播放失败"
        let message = "type(\(type.rawValue)), code(\(code.rawValue)), \(String(describing: description))"
        let alertTips = UIAlertController(title: tips, message: message, preferredStyle: .alert)
        self.present(alertTips, animated: true, completion: nil)

        // 获取弱引用 self
        weak var weakSelf = self
        alertTips.addAction(UIAlertAction(title: "重试", style: .default, handler: { action in
            self.link?.disconnect(withResult: nil)
            self.link?.connect(peerIP: "192.168.43.1", peerPort: 6684, withResult: nil)

            guard let p = player as? YJRMPApVodPlayer else { return }
            p.stop()
            p.start()
            weakSelf?.startLoading()
        }))
        alertTips.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
    }

    func onFileRecordingError(player: Any?, file: String?, code: YJRMPlayerRecordingError, description: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file)), code=\(code.rawValue), desc=\(String(describing: description))")
        let toast = "code[\(code)], \(String(describing: description))"
        YJOpenSDKToast.show(toast)
    }

    func onFileRecordingFinish(player: Any?, file: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file))")
        let toast = "saved[\(String(describing: file))]"
        YJOpenSDKToast.show(toast)
    }

    func onFileRecordingStart(player: Any?, file: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file))")
    }

    func onFirstFrameRendered(player: Any?, elapseMills: Int) {
        print("\(kTag).\(#function)--\(#line), elapseMills=\(elapseMills)")
        self.stopLoading()
    }

    func onPlaybackSpeedUpdate(player: Any?, speed: Int) {
        print("\(kTag).\(#function)--\(#line), speed=\(speed)")
    }

    func onPlayerStateChange(player: Any?, state: YJRMPlayerState) {
        print("\(kTag).\(#function)--\(#line), state=\(state.rawValue)")
    }

    func onSnapshotResult(player: Any?, file: String?, code: YJRMPlayerSnapshotResult, description: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file)), code=\(code.rawValue), desc=\(String(describing: description))")
        switch code {
        case .snapshotOk:
            let toast = "saved[\(String(describing: file))]"
            YJOpenSDKToast.show(toast)
        case .snapshotUnknown, .snapshotWriteFileError, .snapshotCompressError:
            let toast = "saved[\(String(describing: description))]"
            YJOpenSDKToast.show(toast)
        }
    }

    func onVideoSizeChanged(player: Any?, size: CGSize) {
        print("\(kTag).\(#function)--\(#line), size=[\(size.width) x \(size.height)]")
    }

    func onSeekComplete(player: Any?, success: Bool) {
        print("\(kTag).\(#function)--\(#line), success=\(success)")
    }

    func onVodPlayComplete(player: Any?) {
        print("\(kTag).\(#function)--\(#line)")
    }

    func onVodPlayProgress(player: Any?, millis: Int) {
//        print("\(kTag).\(#function)--\(#line), millis=\(millis)")
        let date = Date(timeIntervalSince1970: TimeInterval(millis) / 1000.0)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        self.progressLabel?.text = dateFormatter.string(from: date)
    }
}

// MARK: YJRMPMonoDownloaderDelegate

extension ApTCardVodViewController: YJRMPMonoDownloaderDelegate {

    func downloader(_ downloader: Any?, onError error: YJRMPMonoDownloadErrorCode, desc: String) {
        print("\(kTag).\(#function)--\(#line), downloader=\(String(describing: downloader)), error=\(error.rawValue), desc=\(String(describing: desc))")
        let toast = "error[\(error)], \(String(describing: desc))"
        YJOpenSDKToast.show(toast)
    }

    func downloader(_ downloader: Any?, on progress: YJRMPMonoDownloadProgress) {
        self.downloadBtn?.setTitle("\(Int(progress.progress))%", for: .normal)
    }

    func downloader(_ downloader: Any?, onFinish files: [String]) {
        self.downloadBtn?.setTitle("download", for: .normal)
        let filesStr = files.joined(separator: ",")
        print("\(kTag).\(#function)--\(#line), files=\(String(describing: filesStr))")
    }
}

// MARK: YJRMPDownloadManagerDelegate

extension ApTCardVodViewController: YJRMPDownloadManagerDelegate {

    func downloader(_ downloader: Any?, onTaskStateChanged state: YJRMPDownloadState, taskId: String) {

    }

    func downloader(_ downloader: Any?, onTaskProgress progress: Int32, downloadedBytes: Int, totalBytes: Int, taskId: String) {
        self.downloadBtn?.setTitle("\(Int(progress))%", for: .normal)
    }

    func downloader(_ downloader: Any?, onTaskCompleted filePath: String, taskId: String) {
        self.downloadBtn?.setTitle("download", for: .normal)
        print("\(kTag).\(#function)--\(#line), file=\(String(describing: filePath)), taskId=\(String(describing: taskId))")
    }

    func downloader(_ downloader: Any?, onTaskFailed errorCode: YJRMPMonoDownloadErrorCode, error: String, taskId: String) {
        print("\(kTag).\(#function)--\(#line), downloader=\(String(describing: downloader)), errorCode=\(errorCode.rawValue), desc=\(String(describing: error)), taskId=\(String(describing: taskId))")
        let toast = "taskId[\(taskId)], error[\(errorCode)], \(String(describing: error))"
        YJOpenSDKToast.show(toast)
    }
}

// MARK: YJRMPApLinkDelegate
extension ApTCardVodViewController: YJRMPApLinkDelegate {
    func onLinkStatusChanged(status: YJRMPAPLinkStatus) {
        print("\(kTag).\(#function)--\(#line), status=\(status.rawValue)")
    }

    func onLinkPropertyPost(payload: Data?) {
        print("\(kTag).\(#function)--\(#line), payload=\(String(describing: payload))")
    }

    func onLinkEventPost(eventId: Data?, payload: Data?) {
        print("\(kTag).\(#function)--\(#line), eventId=\(String(describing: eventId)), payload=\(String(describing: payload))")
    }

    func onMediaRecordResult(records: [YJRMPRecordItem]?, pageNo: Int32, pageTotal: Int32, queryId: UInt32) {
        print("\(kTag).\(#function)--\(#line), records=\(String(describing: records)), pageNo=\(pageNo), pageTotal=\(pageTotal), queryId=\(queryId)")
    }

    func onLinkLogFile(seq: Int32, totalSeq: Int32, payload: Data?) {
        print("\(kTag).\(#function)--\(#line), seq=\(seq), totalSeq=\(totalSeq), payload=\(String(describing: payload))")
    }
}

private extension ApTCardVodViewController {

    func setUpPlayer() {

        self.link = YJRMPApLink.sharedInstance
        self.link?.deInit()
        self.link?.initSDK(localIP: "0.0.0.0", mobileID: "uuid")
        self.link?.delegate = self
        self.link?.disconnect(withResult: nil)
        self.link?.connect(peerIP: "192.168.43.1", peerPort: 6684, withResult: { code in
            print("connect code=\(code)")
        })

        self.player = YJRMPApVodPlayer()
        self.player?.delegate = self
        self.playerVideoView = YJRMPVideoView(frame: CGRectZero)
        self.player?.setVideoView(self.playerVideoView)
        self.videoBaseView.addSubview(self.playerVideoView!)
        self.playerVideoView?.snp.makeConstraints({ make in
            make.edges.equalTo(0);
        })
        self.playerVideoView?.backgroundColor = UIColor(white: 0.0, alpha: 1.0)
//        self.player?.setDeviceSource(startSec: 1760112000, endSec: 1760198399)
        self.player?.setDeviceSource(file: "100MEDIA/ACME_20251111112048_0019.mp4", seekSec: 0)
        self.player?.start()
        self.startLoading()
    }

    func setUpUI() {
        self.title = "Ap热点T卡回放"
        self.videoBaseView = UIView(frame: CGRectMake(0, DeviceHelper.navigationBarHeight + 20, DeviceHelper.mainScreenWidth, DeviceHelper.mainScreenWidth * 9 / 16))
        self.view.addSubview(self.videoBaseView)

        //pannel
        let panel_w = DeviceHelper.mainScreenWidth
        let panel_h = DeviceHelper.mainScreenWidth * 9 / 32;
        //pannel
        let pannel = UIView.init(frame: CGRectZero)
        pannel.backgroundColor = UIColor(white: 0.667, alpha: 1.0)
        self.view.addSubview(pannel)
        pannel.snp.makeConstraints { make in
            make.bottom.equalTo(self.view).offset(-20)
            make.size.equalTo(CGSize(width: panel_w, height: panel_h))
        }

        // Button parameters
        let btn_x_gap: CGFloat = 10
        let btn_y_gap: CGFloat = 10
        let btn_w = (panel_w - btn_x_gap * 5) / 4
        let btn_h = (panel_h - btn_y_gap * 3) / 2
        let btnSize = CGSize(width: btn_w, height: btn_h)

        // Stop/Start Button
        let stopBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        stopBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                // 停止播放
                self?.player?.stop()
                btn.setTitle("start", for: .normal)
            } else {
                // 开始播放
                self?.player?.start()
                btn.setTitle("stop", for: .normal)
            }
        }
        initBtn(btn: stopBtn, title: "stop", size: btnSize)
        pannel.addSubview(stopBtn)
        stopBtn.snp.makeConstraints { make in
            make.left.equalTo(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        // Mute/Unmute Button
        let mutBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        mutBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                self?.player?.muteRemoteAudio(true)
                btn.setTitle("unmute", for: .normal)
            } else {
                self?.player?.muteRemoteAudio(false)
                btn.setTitle("mute", for: .normal)
            }
        }
        initBtn(btn: mutBtn, title: "mute", size: btnSize)
        pannel.addSubview(mutBtn)
        mutBtn.snp.makeConstraints { make in
            make.left.equalTo(stopBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        //pause/resume
        let pauseBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        pauseBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                self?.player?.pause()
                btn.setTitle("resume", for: .normal)
            } else {
                self?.player?.resume()
                btn.setTitle("pause", for: .normal)
            }
        }
        initBtn(btn: pauseBtn, title: "pause", size: btnSize)
        pannel.addSubview(pauseBtn)
        pauseBtn.snp.makeConstraints { make in
            make.left.equalTo(mutBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        // Record Button
        let recordBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        recordBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                // 开始录制
                let path = "\(NSHomeDirectory())/Documents/_net_vod_vid_\(Int.random(in: 0...9999)).mp4"
                self?.player?.startFileRecording(path)
                btn.setTitle("record end", for: .normal)
            } else {
                self?.player?.stopFileRecording()
                // 停止录制
                btn.setTitle("record start", for: .normal)
            }
        }
        initBtn(btn: recordBtn, title: "record start", size: btnSize)
        pannel.addSubview(recordBtn)
        recordBtn.snp.makeConstraints { make in
            make.left.equalTo(pauseBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        // Snapshot Button
        let snapshotBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        snapshotBtn.addActionHandler { [weak self] control in
            let path = "\(NSHomeDirectory())/Documents/_net_vod_pic_\(Int.random(in: 0...9999)).jpg"
            self?.player?.snapshot(path)
        }
        initBtn(btn: snapshotBtn, title: "snapshot", size: btnSize)
        pannel.addSubview(snapshotBtn)
        snapshotBtn.snp.makeConstraints { make in
            make.left.equalTo(btn_x_gap)
            make.top.equalTo(btn_y_gap * 2 + btn_h)
            make.size.equalTo(btnSize)
        }

        // Speed
        let speedBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        speedBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            self?.speedIdx += 1
            if self?.speedIdx == self?.speedArr.count {
                self?.speedIdx = 0
            }

            if let speed = self?.speedArr[self!.speedIdx].intValue {
                self?.player?.setPlaybackSpeed(Int32(speed))
                let title = "speed \(speed)x"
                btn.setTitle(title, for: .normal)
            }
        }
        initBtn(btn: speedBtn, title: "speed 1x", size: btnSize)
        pannel.addSubview(speedBtn)
        speedBtn.snp.makeConstraints { make in
            make.left.equalTo(snapshotBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap * 2 + btn_h)
            make.size.equalTo(btnSize)
        }

        // seek
        let seekBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        seekBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            self?.player?.seek(2400)
        }
        initBtn(btn: seekBtn, title: "seek", size: btnSize)
        pannel.addSubview(seekBtn)
        seekBtn.snp.makeConstraints { make in
            make.left.equalTo(speedBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap * 2 + btn_h)
            make.size.equalTo(btnSize)
        }


        let downloadBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        self.downloadBtn = downloadBtn;
        downloadBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()


            // vod es流下载，需要支持vod下载的设备，例如 bc6v
            let config = YJRMPApConfig()
            config.link = self?.link?.link()
            config.link.engine = YJRMPEngine.getDefault()
            if let source = YJRMPApVodSource.create(with: config) {
                var path = NSHomeDirectory() + "/Documents/"
                let random = Int(arc4random())
                path += String(format: "_ap_vod_dld_%d.mp4", random)

                source.setRangeStartSec(1760156519, endSec: 1760156690)
                self?.downloader?.stop()
                self?.downloader = YJRMPMonoDownloader.create(with: source, delegate: self)
                self?.downloader?.setOutputFile(path)
                self?.downloader?.start()
            }



            /*
            //vod文件下载，需要支持文件下载的设备，例如 bc6v1
            let config = YJRMPDownloadConfig();
            if let link = self?.link?.link() {

                var path = NSHomeDirectory() + "/Documents/"
                let random = Int(arc4random())
                path += String(format: "_ap_file_dld_%d.mp4", random)

                self?.downloadMgr = YJRMPDownloadManager.create(with: link, config: config, delegate: self)
                self?.downloadMgr?.initialize()
                if let taskId = self?.downloadMgr?.addTask(withRemoteFile: "100MEDIA/ACME_20251111112048_0019.mp4", localFile: path, autoStart: false) {
                    self?.downloadMgr?.startTask(taskId)
                }
            }
             */
        }
        initBtn(btn: downloadBtn, title: "download", size: btnSize)
        pannel.addSubview(downloadBtn)
        downloadBtn.snp.makeConstraints { make in
            make.left.equalTo(seekBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap * 2 + btn_h)
            make.size.equalTo(btnSize)
        }

        //vod progress
        let pl = UILabel()
        pl.backgroundColor = UIColor(red: 0.0, green: 1.0, blue: 0.0, alpha: 1.0)
        self.view.addSubview(pl)
        self.progressLabel = pl
        pl.snp.makeConstraints { make in
            make.top.equalTo(videoBaseView.snp.bottom)
            make.left.equalTo(self.view.snp.centerX)
            make.right.equalTo(self.view)
            make.height.equalTo(20)
        }
    }

    func initBtn(btn: UIButton, title: String, size: CGSize) {
        btn.setTitle(title, for: .normal)
        btn.titleLabel?.font = UIFont(ofSize: 15)
        btn.setTitleColor(UIColor(hexString: "#FFFFFF"), for: .normal)
        btn.setTitleColor(UIColor(hexString: "#FFFFFF", alpha: 0.6), for: .highlighted)
        btn.layer.masksToBounds = true
        btn.layer.cornerRadius = size.height / 2
    }

    // MARK: - LoadingIndicator
    func startLoading() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.loadingIndicator.startAnimating()
        }
    }

    func stopLoading() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.loadingIndicator.stopAnimating()
        }
    }
}
