//
//  DeviceHelper.swift
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2025/2/13.
//

import UIKit

class DeviceHelper {
    // 设备屏幕大小
    static var mainScreenFrame: CGRect {
        return UIScreen.main.bounds
    }

    // 设备屏幕宽
    static var mainScreenWidth: CGFloat {
        return mainScreenFrame.size.width
    }

    // 设备屏幕高
    static var mainScreenHeight: CGFloat {
        return mainScreenFrame.size.height
    }

    static let epsilon: CGFloat = 0.02
    static let screen9x16Ratio: CGFloat = 0.56  // iPhone X 以前的手机的比例
    static let screen9x19Ratio: CGFloat = 0.46  // iPhone X 以后的手机的比例

    // 检查是否为 iPhone X 系列
    static var isIPhoneX: Bool {
        return abs((mainScreenWidth / mainScreenHeight) - screen9x19Ratio) < epsilon
    }

    // 是否包含安全区域
    static var isHasSafeArea: Bool {
        return isIPhoneX
    }

    // 导航栏高度
    static var navigationBarHeight: CGFloat {
        return isHasSafeArea ? 88.0 : 64.0
    }
}
