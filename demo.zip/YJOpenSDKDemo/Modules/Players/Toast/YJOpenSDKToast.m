//
//  YJOpenSDKToast.m
//  UITest
//
//  Created by leo.li on 16/7/5.
//  Copyright © 2016年 lujiongjian. All rights reserved.
//

#import "YJOpenSDKToast.h"
#import "MBProgressHUD.h"
#import "BaseDef.h"

@implementation YJOpenSDKToast

#pragma mark - Prinvate

+ (UIView *)defaultSuperView {
    return [UIApplication sharedApplication].windows.lastObject;
}

+ (void)showToast:(NSString *)text {
    dispatch_main_async_safe(^{
        [self showToast:text inView:[self defaultSuperView]];
    });
}

+ (void)showToast:(NSString *)text hideAfterDelay:(NSTimeInterval)delay {
    dispatch_main_async_safe(^{
        [self showToast:text inView:[self defaultSuperView] hideAfterDelay:delay];
    });
}

+ (void)showToast:(NSString *)text inView:(UIView *)view {
    dispatch_main_async_safe(^{
        [self showToast:text inView:view hideAfterDelay:3.0];
    });
}

+ (void)showToast:(NSString *)text inView:(UIView *)view hideAfterDelay:(NSTimeInterval)delay {
    dispatch_main_async_safe(^{
        [self showToast:text inView:view hideAfterDelay:delay userInteractionEnabled:NO];
    });
}

+ (void)showToastWaiting:(NSString *)text {
    dispatch_main_async_safe(^{
        [self showToast:text inView:[self defaultSuperView] hideAfterDelay:3.0 userInteractionEnabled:YES];
    });
}

static MBProgressHUD *toastHud = nil;

+ (void)showToast:(NSString *)text inView:(UIView *)view hideAfterDelay:(NSTimeInterval)delay userInteractionEnabled:(BOOL)userInteractionEnabled {
    dispatch_main_async_safe(^{

        if (text.length < 1) {
            return;
        }
        NSParameterAssert([text isValidString]);

        UIView *superView;
        if (view == nil) {
            superView = [self defaultSuperView];
        }
        else {
            superView = view;
        }

        if (toastHud) {
            [toastHud hideAnimated:NO];
        }
        toastHud = [MBProgressHUD showHUDAddedTo:superView animated:YES];
        toastHud.mode = MBProgressHUDModeText;
        toastHud.label.text = text;
        toastHud.label.numberOfLines = 2;
        toastHud.contentColor = [UIColor whiteColor];
        toastHud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
        toastHud.bezelView.color = [[UIColor blackColor] colorWithAlphaComponent:0.7];
        toastHud.userInteractionEnabled = userInteractionEnabled;
        [toastHud hideAnimated:YES afterDelay:delay];
    });
}

+ (void)showProgress:(NSString *)text {
    dispatch_main_async_safe(^{
        [self showProgress:text inView:[self defaultSuperView]];
    });
}

static MBProgressHUD *progressHud = nil;

+ (void)showProgress:(NSString *)text inView:(UIView *)view {
    dispatch_main_async_safe(^{
        UIView *superView;
        if (view == nil) {
            superView = [self defaultSuperView];
        }
        else {
            superView = view;
        }
        if (!progressHud) {
            progressHud = [MBProgressHUD showHUDAddedTo:superView animated:YES];
            progressHud.mode = MBProgressHUDModeIndeterminate;
            progressHud.contentColor = [UIColor whiteColor];
            progressHud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
            progressHud.bezelView.color = [[UIColor blackColor] colorWithAlphaComponent:0.7];
        }
        progressHud.label.text = text;
    });
}

+ (void)hideProgress {
    dispatch_main_async_safe(^{
        [self hideProgressInView:[self defaultSuperView]];
    });
}

+ (void)hideProgressInView:(UIView *)view {
    dispatch_main_async_safe(^{
        [MBProgressHUD hideHUDForView:view animated:YES];
        progressHud = nil;
    });
}

+ (void)YJ_showProgress:(NSString *)text inView:(UIView *)view {
    dispatch_main_async_safe(^{
        UIView *superView;
        if (view == nil) {
            superView = [self defaultSuperView];
        }
        else {
            superView = view;
        }

        MBProgressHUD *progressHud = [MBProgressHUD showHUDAddedTo:superView animated:YES];
        progressHud.mode = MBProgressHUDModeIndeterminate;
        progressHud.contentColor = [UIColor whiteColor];
        progressHud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
        progressHud.bezelView.color = [[UIColor blackColor] colorWithAlphaComponent:0.7];
        progressHud.label.text = text;
        progressHud.userInteractionEnabled = NO;
    });
}

+ (void)YJ_hideProgressInView:(UIView *)view {
    dispatch_main_async_safe(^{
        [MBProgressHUD hideHUDForView:view animated:YES];
    });
}

#pragma mark - debug
+ (void)showToast4Debug:(NSString *)text {
#if defined(DEBUG) && DEBUG
//    dispatch_main_async_safe(^{
//        [self showToast4Debug:text inView:[self defaultSuperView]];
//    });
#endif
}

static MBProgressHUD *toastHud4Debug = nil;

+ (void)showToast4Debug:(NSString *)text inView:(UIView *)view {
    dispatch_main_async_safe(^{

        if (text.length < 1) {
            return;
        }
        NSParameterAssert([text isValidString]);

        UIView *superView;
        if (view == nil) {
            superView = [self defaultSuperView];
        }
        else {
            superView = view;
        }

        if (toastHud4Debug) {
            [toastHud4Debug hideAnimated:NO];
        }
        toastHud4Debug = [MBProgressHUD showHUDAddedTo:superView animated:YES];
        toastHud4Debug.mode = MBProgressHUDModeText;
        toastHud4Debug.label.text = text;
        toastHud4Debug.label.numberOfLines = 0;
        toastHud4Debug.contentColor = [UIColor whiteColor];
        toastHud4Debug.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
        toastHud4Debug.bezelView.color = [[UIColor blackColor] colorWithAlphaComponent:0.7];
        CGFloat margin = 0;//距离底部和顶部的距离
        CGFloat offSetY = superView.bounds.size.height / 2 - margin;
        [toastHud4Debug setOffset:CGPointMake(0, offSetY)];
        [toastHud4Debug hideAnimated:YES afterDelay:3];
    });
}

@end
