//
//  UIFont+YJ.m
//  UITest
//
//  Created by leo.li on 16/7/7.
//  Copyright © 2016年 lujiongjian. All rights reserved.
//

#import "UIFont+YJ.h"

@implementation UIFont (YJ)

+ (UIFont *)fontOfSizePlus:(CGFloat)size {
    return [UIFont systemFontOfSize:(size+1)];
}

+ (UIFont *)boldFontOfSizePlus:(CGFloat)size {
    return [UIFont boldSystemFontOfSize:(size+1)];
}

+ (UIFont *)fontOfSize:(CGFloat)size {
    return [UIFont systemFontOfSize:size];
}

+ (UIFont *)boldFontOfSize:(CGFloat)size {
    return [UIFont boldSystemFontOfSize:size];
}

+ (UIFont *)italicSystemFontOfSize:(CGFloat)fontSize angle:(CGFloat)angle {
    CGAffineTransform matrix = CGAffineTransformMake(1, 0, tanf(angle * (CGFloat)M_PI / 180), 1, 0, 0);
    UIFontDescriptor *desc = [UIFontDescriptor fontDescriptorWithName:[UIFont systemFontOfSize:fontSize].fontName matrix:matrix];//取得系统字符并设置反射。
    UIFont *font = [UIFont fontWithDescriptor:desc size:fontSize];
    return font;
}

@end
