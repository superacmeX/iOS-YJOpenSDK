//
//  UIControl+YJ.m
//  UITest
//
//  Created by lujiongjian on 2020/5/21.
//  Copyright © 2020 lujiongjian. All rights reserved.
//

#import "UIControl+YJ.h"
#import <objc/runtime.h>

static const void *UIControlBlockKey = &UIControlBlockKey;

@implementation UIControl (YJ)

- (void)addActionHandler:(UIControlTouchedBlock)handler {
    objc_setAssociatedObject(self, UIControlBlockKey, handler, OBJC_ASSOCIATION_COPY_NONATOMIC);
    [self addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)action:(UIControl *)sender {
    UIControlTouchedBlock block = objc_getAssociatedObject(self, UIControlBlockKey);
    if (block) {
        block(sender);
    }
}

+ (UIControl *)gradientViewWithSize:(CGSize)size startColor:(UIColor *)startColor endColor:(UIColor *)endColor {
    UIControl *control = [[UIControl alloc] initWithFrame:CGRectZero];
    control.backgroundColor = [UIColor clearColor];

    CAGradientLayer *gl = [CAGradientLayer layer];
    gl.frame = CGRectMake(0, 0, size.width, size.height);
    gl.startPoint = CGPointMake(0, 0);
    gl.endPoint = CGPointMake(1, 0);
    gl.colors = @[(__bridge id)startColor.CGColor,(__bridge id)endColor.CGColor];
    [control.layer addSublayer:gl];

    return control;
}

@end
