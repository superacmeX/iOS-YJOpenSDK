//
//  NSString+YJ.m
//  UITest
//
//  Created by leo.li on 16/6/30.
//  Copyright © 2016年 lujiongjian. All rights reserved.
//

#import "NSString+YJ.h"
#import <CommonCrypto/CommonDigest.h>

@implementation NSString (YJ)

- (BOOL)isContain:(NSString *)aString {
    NSRange range = [self rangeOfString:aString];
    return range.location != NSNotFound;
}

- (NSDate *)dateFromStringWithFormatter:(NSString *)formatter {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:formatter];
    return [dateFormatter dateFromString:self];
}

- (NSDictionary *)dictionary {
    NSData *jsonData = [self dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *retDic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableLeaves error:nil];
    return retDic;
}

- (NSArray *)toArray{
    NSData *jsonData = [self dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSArray *arr = [NSJSONSerialization JSONObjectWithData:jsonData
                                                   options:NSJSONReadingMutableContainers
                                                     error:&err];

    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return arr;

}

@end
