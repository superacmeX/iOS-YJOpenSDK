//
//  NSString+YJ.h
//  UITest
//
//  Created by leo.li on 16/6/30.
//  Copyright © 2016年 lujiongjian. All rights reserved.
//

#import <Foundation/Foundation.h>

/** 字符串工具类
 *
 */
@interface NSString (YJ)

/**
 *  @brief 判断字符串包含关系
 *
 *  @param aString 被判断的字符串
 *
 *  @return YES：包含，否则不包含
 */
- (BOOL)isContain:(NSString *)aString;

/**
 *  @brief 根据制定格式转化成日期
 *
 *  @param formatter 格式
 *
 *  @return 日期
 */
- (NSDate *)dateFromStringWithFormatter:(NSString *)formatter;

#pragma mark - json -> dictionary

/**
 *  @brief 将字符串（json格式）转化成字典
 *
 *  @return 转化后的字典
 */
- (NSDictionary *)dictionary;

/**
 json字符串转数组

 @return return value description
 */
- (NSArray *)toArray;

@end
