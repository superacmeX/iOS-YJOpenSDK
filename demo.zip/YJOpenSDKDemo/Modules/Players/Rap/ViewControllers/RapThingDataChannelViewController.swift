//
//  RapThingDataChannelViewController.swift
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2025/3/1.
//

import UIKit
import YJOpenSDK

final class RapThingDataChannelViewController: UIViewController {
    private var kTag: String = ""
    private var channel: YJRMPRapDataChannel?
    private var deviceName: String = ""
    private var productKey: String = ""

    init() {
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        print("\(kTag).deinit")
    }
}

extension RapThingDataChannelViewController {
    convenience init(deviceName: String, productKey: String) {
        self.init()

        self.deviceName = deviceName
        self.productKey = productKey

        kTag = String(describing: type(of: self))
    }

    override func viewDidLoad() {
        setUpUI()
        setUpChannel()
    }
}

// MARK: YJRMPDataChannelDelegate

extension RapThingDataChannelViewController: YJRMPDataChannelDelegate {

  func onEvent(_ event: String) {
    //event，json字符串
  }

  func onProperty(_ property: String) {
    //event，json字符串
  }
}

private extension RapThingDataChannelViewController {

    func setUpChannel() {
      let config = YJRMPRapConfig()
      config.engine = YJRMPEngine.getDefault()
      config.deviceName = self.deviceName
      config.productKey = self.productKey

      self.channel = YJRMPRapDataChannel.create(with: config)
      self.channel?.delegate = self
      ///订阅属性上报
      self.channel?.subscribeProperty()
      ///按需获取，订阅某个事件，或多个事件，进来用这个方法
      self.channel?.subscribeEvents(["RemindEvent", "ReportNowLocation"])
      ///订阅所有事件，事件上报过多，可能会导致信令通道阻塞，导致拉流缓慢
      self.channel?.subscribeAllEvents()


      ///请求服务
      let postServiceReq = YJRMPPostService()
      postServiceReq.payload = makePayload()//json字符串
      postServiceReq.serviceId = "PTZ"
      postServiceReq.timeoutMillis = 120000

      self.channel?.send(postServiceReq) { (payload: String?, code: YJRMPDataChannelState, desc: String?) in
        if code == .responseOk {
              print("\(#function)--\(#line), payload = \(payload ?? "")")
        } else {
            print("\(#function)--\(#line), code = \(code.rawValue), desc = \(desc ?? "")")
        }
      }


      ///设置属性
      let setPropertyReq = YJRMPSetProperty();
      setPropertyReq.payload = makePayload()//json字符串
      setPropertyReq.timeoutMillis = 120000;

      self.channel?.send(setPropertyReq) { (payload: String?, code: YJRMPDataChannelState, desc: String?) in
        if code == .responseOk {
              print("\(#function)--\(#line), payload = \(payload ?? "")")
        } else {
            print("\(#function)--\(#line), code = \(code.rawValue), desc = \(desc ?? "")")
        }
      }


      ///获取属性
      let getPropertyReq = YJRMPGetProperty();
      getPropertyReq.payload = makePayload()//json字符串
      getPropertyReq.propertyId = "get_property";
      getPropertyReq.timeoutMillis = 120000;

      self.channel?.send(getPropertyReq) { (payload: String?, code: YJRMPDataChannelState, desc: String?) in
        if code == .responseOk {
              print("\(#function)--\(#line), payload = \(payload ?? "")")
        } else {
            print("\(#function)--\(#line), code = \(code.rawValue), desc = \(desc ?? "")")
        }
      }

    }

    func setUpUI() {
        self.title = "热点T卡回放"
    }

    func initBtn(btn: UIButton, title: String, size: CGSize) {
        btn.setTitle(title, for: .normal)
        btn.titleLabel?.font = UIFont(ofSize: 15)
        btn.setTitleColor(UIColor(hexString: "#FFFFFF"), for: .normal)
        btn.setTitleColor(UIColor(hexString: "#FFFFFF", alpha: 0.6), for: .highlighted)
        btn.layer.masksToBounds = true
        btn.layer.cornerRadius = size.height / 2
    }

    func makePayload() -> String {
        let dict: [String: Any] = [
            "name": "Alice",
            "age": 30,
            "skills": ["Objective-C", "Swift"]
        ]

        do {
            let jsonData = try JSONSerialization.data(withJSONObject: dict, options: [])
            let jsonString = String(data: jsonData, encoding: .utf8) ?? ""
            print("JSON 字符串: \(jsonString)")
            return jsonString
        } catch {
            print("JSON 序列化失败: \(error)")
            return ""
        }
    }
}
