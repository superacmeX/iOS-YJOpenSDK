//
//  VideoCallViewController.swift
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2025/11/9.
//

import UIKit
import YJOpenSDK

final class VideoCallViewController: UIViewController {
    private var kTag: String = ""
    private var player: YJRMPNetLivePlayer?
    private var videoBaseView:      UIView? = nil
    private var localVideoBaseView: UIView? = nil
    private var playerLocalVideoView:       YJRMPVideoView? = nil
    private var playerRemoteVideoView:      YJRMPVideoView? = nil
    private var deviceName: String = ""
    private var productKey: String = ""
    private var timer: Timer?

    init() {
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        print("\(kTag).deinit")
    }

    private lazy var loadingIndicator: UIActivityIndicatorView = {
        var type: UIActivityIndicatorView.Style = .whiteLarge
        if #available(iOS 13.0, *) {
            type = .large
        }
        let indicator = UIActivityIndicatorView(style: type)
        indicator.color = UIColor.green
        self.videoBaseView?.addSubview(indicator)
        indicator.snp.makeConstraints { make in
            make.center.equalTo(self.videoBaseView!)
        }
        return indicator
    }()
}

extension VideoCallViewController {
    convenience init(deviceName: String, productKey: String) {
        self.init()
        
        self.deviceName = deviceName
        self.productKey = productKey

        kTag = String(describing: type(of: self))
    }

    override func viewDidLoad() {
        setUpUI()
//        setUpTimer()
        setUpPlayer()
    }
}

// MARK: YJRMPVideoSinkDelegate
extension VideoCallViewController: YJRMPVideoSinkDelegate {
    func onI420Frame(player: Any?, frame: YJRMPI420PFrame) {
//        print("w:\(frame.width), h:\(frame.height), r:\(frame.rotation.rawValue), pts:\(frame.pts), cw:\(frame.chromaWidth), ch:\(frame.chromaHeight), dy:\(String(describing: frame.dataY)), du:\(String(describing: frame.dataU)), dv:\(String(describing: frame.dataV)), dy:\(frame.strideY), dy:\(frame.strideU), dy:\(frame.strideV)")
    }
}

// MARK: YJRMPSeiDelegate
extension VideoCallViewController: YJRMPSeiDelegate {
    func onSeiData(player: Any?, sei: Data?, pts: Int) {
//        print("\(#function)--\(#line), sei=\(String(describing: sei)), pts = \(pts)")
    }
}

// MARK: YJRMPlayerDelegate
extension VideoCallViewController: YJRMPlayerDelegate {

    func onBufferStateUpdate(player: Any?, state: YJRMPlayerBufferState, bufferDurationMillis: Int) {
        print("\(kTag).\(#function)--\(#line), state=\(state), bufferDurationMillis=\(bufferDurationMillis)")

        switch state {
        case .loading:
            startLoading()
        case .ready:
            stopLoading()
        default:
            break
        }  
    }

    func onError(player: Any?, type: YJRMPlayerErrorType, code: YJRMPlayerErrorCode, description: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), type=\(type.rawValue), code=\(code.rawValue), desc=\(String(describing: description))")

        let tips = "通话失败"
        let message = "type(\(type.rawValue)), code(\(code.rawValue)), \(String(describing: description))"
        let alertTips = UIAlertController(title: tips, message: message, preferredStyle: .alert)
        self.present(alertTips, animated: true, completion: nil)

        // 获取弱引用 self
        weak var weakSelf = self
        alertTips.addAction(UIAlertAction(title: "重试", style: .default, handler: { action in
            guard let p = player as? YJRMPNetLivePlayer else { return }
            p.stop()
            p.start()
            weakSelf?.startLoading()
        }))
        alertTips.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
    }

    func onFileRecordingError(player: Any?, file: String?, code: YJRMPlayerRecordingError, description: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file)), code=\(code.rawValue), desc=\(String(describing: description))")
        let toast = "code[\(code)], \(String(describing: description))"
        YJOpenSDKToast.show(toast)
    }

    func onFileRecordingFinish(player: Any?, file: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file))")
        let toast = "saved[\(String(describing: file))]"
        YJOpenSDKToast.show(toast)
    }

    func onFileRecordingStart(player: Any?, file: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file))")
    }

    func onFirstFrameRendered(player: Any?, elapseMills: Int) {
        print("\(kTag).\(#function)--\(#line), elapseMills=\(elapseMills)")
        self.stopLoading()
    }

    func onPlayerStateChange(player: Any?, state: YJRMPlayerState) {
        print("\(kTag).\(#function)--\(#line), state=\(state.rawValue)")
    }

    func onSnapshotResult(player: Any?, file: String?, code: YJRMPlayerSnapshotResult, description: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file)), code=\(code.rawValue), desc=\(String(describing: description))")
        switch code {
        case .snapshotOk:
            let toast = "saved[\(String(describing: file))]"
            YJOpenSDKToast.show(toast)
        case .snapshotUnknown, .snapshotWriteFileError, .snapshotCompressError:
            let toast = "saved[\(String(describing: description))]"
            YJOpenSDKToast.show(toast)
        }
    }

    func onTalkStateChange(player: Any?, state: YJRMPlayerTalkState) {
        print("\(kTag).\(#function)--\(#line), talk_state=\(state.rawValue)")
        guard let livePlayer = player as? YJRMPNetLivePlayer else { return }

        switch state {
        case .failDeviceInTalking:
            // 占线
            break
        case .deviceWaitingAnswer:
            // 等待设备接听
            break
        case .deviceNoAnswer:
            // 设备超时未接听
            break
        case .deviceRefuseAnswer:
            // 设备主动拒绝接听
            break
        case .deviceAnswered:
            // 设备已接听
            livePlayer.muteLocalVideo(false) // 发送本地视频
            livePlayer.muteLocalAudio(false) // 发送本地音频
            break
        case .deviceHangUp:
            // 通话中，设备主动挂断
            break
        case .deviceUnmuteVideo:
            // 设备打开摄像头通知
            break
        case .deviceMuteVideo:
            // 设备关闭摄像头通知
            break
        @unknown default:
            // 错误处理，stop，结束通话
            break
        }
    }

    func onVideoSizeChanged(player: Any?, size: CGSize) {
        print("\(kTag).\(#function)--\(#line), size=[\(size.width) x \(size.height)]")
    }
}

private extension VideoCallViewController {

    func setUpPlayer() {
        let config = YJRMPNetPlayerConfig()
        config.engine = YJRMPEngine.getDefault()
        config.deviceName = self.deviceName
        config.productKey = self.productKey

        self.player = YJRMPNetLivePlayer.create(with: config)
        self.player?.delegate = self
        self.playerRemoteVideoView?.removeFromSuperview()
        self.playerRemoteVideoView = YJRMPVideoView(frame: CGRectZero)
        self.player?.setVideoView(self.playerRemoteVideoView)
        self.videoBaseView?.addSubview(self.playerRemoteVideoView!)
        self.playerRemoteVideoView?.snp.makeConstraints({ make in
            make.edges.equalTo(0);
        })
        self.playerRemoteVideoView?.backgroundColor = UIColor(white: 0.0, alpha: 1.0)

        let con = YJLivePlayConfig()
        con.audioSend = true
        con.videoSend = true
        con.userId = "microbt"
        self.player?.configLivePlay(con)
        self.player?.muteLocalAudio(true)
        self.player?.muteLocalVideo(true)

        self.playerLocalVideoView?.removeFromSuperview()
        self.playerLocalVideoView = YJRMPVideoView(frame: CGRectZero)
        self.player?.setLocalVideoView(self.playerLocalVideoView)
        self.localVideoBaseView?.addSubview(self.playerLocalVideoView!)
        self.playerLocalVideoView?.snp.makeConstraints({ make in
            make.edges.equalTo(0);
        })
        self.playerLocalVideoView?.backgroundColor = UIColor(red: 1.0, green: 0.0, blue: 0.0, alpha: 1.0)
//        self.playerLocalVideoView?.videoContentMode = .scaleToFill; 设置图像缩放模式

        self.player?.startLocalPreview(.front)
        self.player?.start()
        self.startLoading()
    }

    func setUpUI() {
        self.title = "Net 视频通话"
        self.videoBaseView = UIView(frame: CGRectMake(0, DeviceHelper.navigationBarHeight + 20, DeviceHelper.mainScreenWidth, DeviceHelper.mainScreenWidth * 9 / 16))
        self.view.addSubview(self.videoBaseView!)

        self.localVideoBaseView = UIView(frame: CGRectMake(0, DeviceHelper.navigationBarHeight + DeviceHelper.mainScreenWidth * 9 / 16, DeviceHelper.mainScreenWidth, DeviceHelper.mainScreenWidth * 9 / 16))
        self.view.addSubview(self.localVideoBaseView!)

        //pannel
        let panel_w = DeviceHelper.mainScreenWidth
        let panel_h = DeviceHelper.mainScreenWidth * 9 / 32;
        //pannel
        let pannel = UIView.init(frame: CGRectZero)
        pannel.backgroundColor = UIColor(white: 0.667, alpha: 1.0)
        self.view.addSubview(pannel)
        pannel.snp.makeConstraints { make in
            make.bottom.equalTo(self.view).offset(-20)
            make.size.equalTo(CGSize(width: panel_w, height: panel_h))
        }

        // Button parameters
        let btn_x_gap: CGFloat = 10
        let btn_y_gap: CGFloat = 10
        let btn_w = (panel_w - btn_x_gap * 5) / 4
        let btn_h = (panel_h - btn_y_gap * 3) / 2
        let btnSize = CGSize(width: btn_w, height: btn_h)

        // Stop/Start Button
        let stopBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        stopBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                // 停止播放
                self?.player?.stop()
                btn.setTitle("呼叫", for: .normal)
            } else {
                // 开始播放
                self?.setUpPlayer()
                btn.setTitle("挂掉", for: .normal)
            }
        }
        initBtn(btn: stopBtn, title: "挂掉", size: btnSize)
        pannel.addSubview(stopBtn)
        stopBtn.snp.makeConstraints { make in
            make.left.equalTo(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        // close/open camera Button
        let mutBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        mutBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                self?.player?.muteLocalVideo(true)
                self?.player?.stopLocalPreview()
                btn.setTitle("开启摄像头", for: .normal)
            } else {
                self?.player?.muteLocalVideo(false)
                self?.player?.startLocalPreview(.front)
                btn.setTitle("关闭摄像头", for: .normal)
            }
        }
        initBtn(btn: mutBtn, title: "关闭摄像头", size: btnSize)
        pannel.addSubview(mutBtn)
        mutBtn.snp.makeConstraints { make in
            make.left.equalTo(stopBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        // close/open mic Button
        let talkBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        talkBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                self?.player?.muteLocalAudio(true)
                btn.setTitle("开麦", for: .normal)
            } else {
                self?.player?.muteLocalAudio(false)
                btn.setTitle("闭麦", for: .normal)
            }
        }
        initBtn(btn: talkBtn, title: "闭麦", size: btnSize)
        pannel.addSubview(talkBtn)
        talkBtn.snp.makeConstraints { make in
            make.left.equalTo(mutBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        // switch camera Button
        let recordBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        recordBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                self?.player?.switchCamera(.back)
                btn.setTitle("前置摄像头", for: .normal)
            } else {
                self?.player?.switchCamera(.front)
                btn.setTitle("后置摄像头", for: .normal)
            }
        }
        initBtn(btn: recordBtn, title: "后置摄像头", size: btnSize)
        pannel.addSubview(recordBtn)
        recordBtn.snp.makeConstraints { make in
            make.left.equalTo(talkBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

    }

    func setUpTimer() {
        self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(timerFired(_:)), userInfo: nil, repeats: true)
        let loop = RunLoop.current
        loop.add(self.timer!, forMode: .common)
    }

    @objc func timerFired(_ timer: Timer) {
//        let stats = player?.getStats()
//        print("stats:\(String(describing: stats?.fps))")

        let d = player?.getFileRecordingDuration()
        print("duration:\(String(describing: d))")
    }

    func initBtn(btn: UIButton, title: String, size: CGSize) {
        btn.setTitle(title, for: .normal)
        btn.titleLabel?.font = UIFont(ofSize: 15)
        btn.setTitleColor(UIColor(hexString: "#FFFFFF"), for: .normal)
        btn.setTitleColor(UIColor(hexString: "#FFFFFF", alpha: 0.6), for: .highlighted)
        btn.layer.masksToBounds = true
        btn.layer.cornerRadius = size.height / 2
    }

    // MARK: - LoadingIndicator
    func startLoading() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.loadingIndicator.startAnimating()
        }
    }

    func stopLoading() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.loadingIndicator.stopAnimating()
        }
    }
}
