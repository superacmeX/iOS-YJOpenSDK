//
//  DeviceSettingsInfoCell.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/29.
//

import UIKit

final class DeviceSettingsInfoCell: UICollectionViewCell {
    // 设备图标
    var iconUrl: String? {
        didSet {
            if let iconUrl {
                iconView.sd_setImage(with: URL(string: iconUrl))
            } else {
                iconView.sd_setImage(with: nil)
            }
        }
    }
    
    // 昵称
    var nickName = "" {
        didSet {
            nameLabel.text = nickName
        }
    }
    
    // 昵称
    var deviceName = "" {
        didSet {
            dnLabel.text = "设备号: \(deviceName)"
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private lazy var iconView = UIImageView()
    private lazy var nameLabel = UILabel()
    private lazy var dnLabel = UILabel()
}

extension DeviceSettingsInfoCell {
    private func setup() {
        iconView.contentMode = .scaleAspectFit
        contentView.addSubview(iconView)
        iconView.snp.makeConstraints { make in
            make.top.bottom.equalTo(contentView).inset(6)
            make.left.equalTo(contentView).inset(8)
            make.width.equalTo(iconView.snp.height)
        }
        
        let arrorView = UIImageView()
        arrorView.image = UIImage(systemName: "chevron.right")
        arrorView.isHidden = true
        contentView.addSubview(arrorView)
        arrorView.snp.makeConstraints { make in
            make.centerY.equalTo(contentView)
            make.right.equalTo(contentView).inset(8)
        }
        
        nameLabel.font = UIFont.systemFont(ofSize: 16)
        nameLabel.textColor = .black
        contentView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.left.equalTo(iconView.snp.right).offset(4)
            make.right.lessThanOrEqualTo(arrorView.snp.left).offset(-12)
            make.bottom.equalTo(contentView.snp.centerY).offset(-2)
        }
        
        dnLabel.font = UIFont.systemFont(ofSize: 12)
        dnLabel.textColor = .gray
        contentView.addSubview(dnLabel)
        dnLabel.snp.makeConstraints { make in
            make.left.equalTo(nameLabel)
            make.right.lessThanOrEqualTo(arrorView.snp.left).offset(-12)
            make.top.equalTo(contentView.snp.centerY).offset(2)
        }
    }
}
