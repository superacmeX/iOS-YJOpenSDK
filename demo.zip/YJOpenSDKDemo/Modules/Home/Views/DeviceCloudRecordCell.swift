//
//  DeviceCloudRecordCell.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/10.
//

import UIKit

final class DeviceCloudRecordCell: UICollectionViewCell {
    var picUrl: String? {
        didSet {
            if let picUrl {
                iconView.sd_setImage(with: URL(string: picUrl))
            } else {
                iconView.sd_setImage(with: nil)
            }
        }
    }
    
    var name = "" {
        didSet {
            titleLabel.text = name
        }
    }
    
    var time = "" {
        didSet {
            timeLabel.text = time
        }
    }
    
    var duration = 0 {
        didSet {
            durationLabel.text = "\(duration)'"
        }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    private lazy var titleLabel = UILabel()
    private lazy var timeLabel = UILabel()
    private lazy var durationLabel = UILabel()
    private lazy var iconView = UIImageView()
}

private extension DeviceCloudRecordCell {
    func setup() {
        let boxView = UIView()
        boxView.backgroundColor = .white
        boxView.layer.cornerRadius = 12
        boxView.layer.shadowColor = UIColor.gray.cgColor
        boxView.layer.shadowOpacity = 0.3
        boxView.layer.shadowOffset = CGSize(width: 2, height: 2)
        contentView.addSubview(boxView)
        boxView.snp.makeConstraints { make in
            make.edges.equalTo(contentView).inset(2)
        }
        
        boxView.addSubview(iconView)
        iconView.snp.makeConstraints { make in
            make.top.right.bottom.equalTo(boxView).inset(12)
            make.width.equalTo(boxView).dividedBy(2).offset(-20)
        }
        
        titleLabel.textColor = .theme
        titleLabel.font = .systemFont(ofSize: 16)
        titleLabel.numberOfLines = 3
        boxView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.left.top.equalTo(boxView).inset(12)
            make.right.equalTo(iconView.snp.left).offset(-12)
        }
        
        timeLabel.textColor = .gray
        timeLabel.font = .systemFont(ofSize: 15)
        timeLabel.numberOfLines = 0
        boxView.addSubview(timeLabel)
        timeLabel.snp.makeConstraints { make in
            make.left.equalTo(titleLabel)
            make.top.equalTo(titleLabel.snp.bottom).offset(5)
            make.right.equalTo(iconView.snp.left).offset(-12)
        }
        
        durationLabel.textColor = .gray
        durationLabel.font = .systemFont(ofSize: 13)
        durationLabel.numberOfLines = 0
        boxView.addSubview(durationLabel)
        durationLabel.snp.makeConstraints { make in
            make.left.equalTo(titleLabel)
            make.top.equalTo(timeLabel.snp.bottom).offset(5)
            make.right.equalTo(iconView.snp.left).offset(-12)
        }
    }
}
