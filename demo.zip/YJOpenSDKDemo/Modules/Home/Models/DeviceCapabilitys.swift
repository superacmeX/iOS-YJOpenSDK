//
//  DeviceCapabilitys.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/29.
//

import Foundation
import Combine
import YJOpenSDK

struct DeviceCapabilitys {
    let id: String
    let capabilitys: [AnyHashable: Any]
}

extension DeviceCapabilitys {
    /// 获取设备能力级
    /// - Parameter id: 设备id
    static func load(id: String) -> AnyPublisher<DeviceCapabilitys, AppError> {
        var isFirstRequest = true
        return Just(()).setFailureType(to: AppError.self)
            .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global())
            .flatMap({ _ in
                isFirstRequest = false
                return Deferred {
                    return Future<String, AppError> { promise in
                        YJApiClient.request(apiPath: "/operation/api/v1/unified/operation/tag/key/get", param: ["deviceIds": [id], "attrKey": "Capabilitys"]) { code, msg, data in
                            guard let json = data as? [[AnyHashable: Any]],
                                  let fc = json.first?["attrValue"] as? String else {
                                promise(.failure(AppError("获取能力级失败")))
                                return
                            }
                            promise(.success(fc))
                        } fail: { error in
                            promise(.failure(AppError(error.localizedDescription, code: error.code)))
                        }
                    }
                }
            })
            .retry(2)
            .flatMap { str -> AnyPublisher<[AnyHashable: Any], AppError> in
                guard let data = str.data(using: .utf8),
                      let json = try? JSONSerialization.jsonObject(with: data) as? [AnyHashable: Any],
                      let caps = json["caps"] as? [AnyHashable: Any] else {
                    return Fail(error: AppError("数据解析失败")).eraseToAnyPublisher()
                }
                return Just(caps).setFailureType(to: AppError.self).eraseToAnyPublisher()
            }
            .map({ DeviceCapabilitys(id: id, capabilitys: $0) })
            .eraseToAnyPublisher()
    }
}
