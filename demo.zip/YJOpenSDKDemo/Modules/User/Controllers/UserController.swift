//
//  UserController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/26.
//

import UIKit
import Combine
import YJOpenSDK
import FJRouter
import YJSAIAssistant

private var cancels: Set<AnyCancellable> = []
final class UserController: UIViewController {
    
}

extension UserController {
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "用户中心"
        
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(title: "重置密码", style: .plain, target: self, action: #selector(onResetPasswordTapped))
        ]
        
        setup()
        setupDeregister()
        setupAIAssistant()
    }
    
    @objc private func onResetPasswordTapped() {
        FJRouter.jump().go(.name("forgotPassword"))
    }
}

private extension UserController {
    func setup() {
        let logoutButton = UIButton()
        logoutButton.setAttributedTitle(NSAttributedString(string: "Logout", attributes: [.font: UIFont.systemFont(ofSize: 17), .foregroundColor: UIColor.white]), for: [])
        logoutButton.layer.cornerRadius = 12
        logoutButton.backgroundColor = .theme
        view.addSubview(logoutButton)
        logoutButton.snp.makeConstraints { make in
            make.left.right.equalTo(view).inset(20)
            make.centerY.equalTo(view)
            make.height.equalTo(50)
        }
        
        logoutButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { _ in
            YJOpenSDKManager.default.accountService.logout()
        }).store(in: &cancels)
    }
    
    func setupDeregister() {
        let deregisterButton = UIButton()
        deregisterButton.setAttributedTitle(NSAttributedString(string: "Deregister", attributes: [.font: UIFont.systemFont(ofSize: 17), .foregroundColor: UIColor.white]), for: [])
        deregisterButton.layer.cornerRadius = 12
        deregisterButton.backgroundColor = .theme
        view.addSubview(deregisterButton)
        deregisterButton.snp.makeConstraints { make in
            make.left.right.equalTo(view).inset(20)
            make.centerY.equalTo(view).offset(60.0)
            make.height.equalTo(50)
        }
        
        deregisterButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { _ in
            let alertTips = UIAlertController(title: "Are you sure deregister?", message: "please relace your tips", preferredStyle: .alert)
            alertTips.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            alertTips.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                debugPrint("YJOpenSDKManager.default.accountService.deregister")
                YJOpenSDKManager.default.accountService.deregister { error in
                    guard let error else {
                        print("deregister success")
                        return
                    }
                    print("deregister failed \(error)")
                }
            }))
            self.present(alertTips, animated: true, completion: nil)
        }).store(in: &cancels)
    }
    
    func setupAIAssistant() {
        let button = UIButton()
        button.setAttributedTitle(NSAttributedString(string: "AI Assistant", attributes: [.font: UIFont.systemFont(ofSize: 17), .foregroundColor: UIColor.white]), for: [])
        button.layer.cornerRadius = 12
        button.backgroundColor = .theme
        view.addSubview(button)
        button.snp.makeConstraints { make in
            make.left.right.equalTo(view).inset(20)
            make.centerY.equalTo(view).offset(120.0)
            make.height.equalTo(50)
        }
        
        button.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { [weak self] _ in
            let vc = YJSAIAssistantSDK.default.aiChat()
            self?.navigationController?.pushViewController(vc, animated: true)
        }).store(in: &cancels)
    }
}
