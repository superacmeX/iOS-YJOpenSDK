//
//  RegisterViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/25.
//

import Foundation
import Combine
import YJOpenSDK
final class RegisterViewModel {
    private(set) lazy var loading = PassthroughSubject<Bool, Never>()
    private(set) lazy var tips = PassthroughSubject<String, Never>()
    private(set) lazy var codeState = CurrentValueSubject<(enabled: Bool, text: String), Never>((false, "发送验证码"))
    private(set) lazy var registerEnabled = PassthroughSubject<Bool, Never>()
    private(set) lazy var registerAndLoginEnabled = PassthroughSubject<Bool, Never>()
    private(set) lazy var registerSuccess = PassthroughSubject<Void, Never>()
    private(set) lazy var registerAndLoginSuccess = PassthroughSubject<Void, Never>()
    private lazy var sendCodeState = CurrentValueSubject<FireTimerState, Never>(.initialize)
    private var cancels: Set<AnyCancellable> = []
    private var account = ""
    private var code = ""
    private var pwd = ""
    private var timerCancel: AnyCancellable?
    private var registerTask: (any YJOpenSDK.YJOpenAccountRegisterTask)?
    private var needLogin = false
    
    init(account: AnyPublisher<String?, Never>, code: AnyPublisher<String?, Never>, pwd: AnyPublisher<String?, Never>, needLogin:Bool = false) {
        account.combineLatest(code, pwd).sink(receiveValue: { [weak self] (acc, code, pwd) in
            self?.account = acc ?? ""
            self?.code = code ?? ""
            self?.pwd = pwd ?? ""
            self?.needLogin = needLogin
        }).store(in: &cancels)
        
        loading.combineLatest(account, code, pwd).sink(receiveValue: { [weak self] (loading, acc, code, pwd) in
            if loading {
                self?.registerEnabled.send(false)
                self?.registerAndLoginEnabled.send(false)
                return
            }
            let enabled = ((acc ?? "").count >= 8) && ((code ?? "").count == 6) && ((pwd ?? "").count >= 6)
            self?.registerEnabled.send(enabled)
            let registerAndLoginEnabled = ((acc ?? "").count >= 8) && ((code ?? "").count == 6)
            self?.registerAndLoginEnabled.send(registerAndLoginEnabled)
        }).store(in: &cancels)
        
        loading.combineLatest(account, sendCodeState).sink(receiveValue: { [weak self] (loading, acc, state) in
            guard let self else {
                return
            }
            if loading {
                let cv = self.codeState.value
                self.codeState.send((false, cv.text))
                return
            }
            switch state {
            case .initialize:
                let enabled = (acc ?? "").count >= 8
                self.codeState.send((enabled, "发送验证码"))
            case let .timer(total: _, current: c):
                let text = "重试 \(c)s"
                self.codeState.send((false, text))
            case .reset:
                self.codeState.send((true, "发送验证码"))
                return
            }
        }).store(in: &cancels)
        
        
        loading.send(false)
    }
    
    deinit {
        clearTimer()
    }
}

extension RegisterViewModel {
    func prepareSendCode() {
        guard case let .success(task) = YJOpenSDKManager.default.accountService.registerTask(needLogin) else {
            return
        }
        self.registerTask = task
        loading.send(true)
        task.sendAuthcode(userName: account) { [weak self] error in
            self?.loading.send(false)
            if let error {
                self?.tips.send(error.localizedDescription)
                return
            }
            self?.startTimer()
        }
    }

    func prepareRegister() {
        guard let task = registerTask else {
            return
        }
        loading.send(true)
        let code = code
        let verifyCode = Deferred {
            Future<Void, YJOpenAccountError> { promise in
                task.verifyAuthcode(authcode: code) { error in
                    if let error {
                        promise(.failure(error))
                    } else {
                        promise(.success(()))
                    }
                }
            }
        }
        
        let pwd = pwd
        let setPwd = verifyCode.flatMap({ _ in
            return Deferred {
                Future<Void, YJOpenAccountError> { promise in
                    task.signupWithPassword(pwd) { error in
                        if let error {
                            promise(.failure(error))
                        } else {
                            promise(.success(()))
                        }
                    }
                }
            }
        }).eraseToAnyPublisher()
        
        setPwd.sink(receiveCompletion: { [weak self] comp in
            self?.loading.send(false)
            if case .failure(let failure) = comp {
                self?.tips.send("注册失败: \(failure.rawValue)")
            }
        }, receiveValue: { [weak self] _ in
            self?.registerSuccess.send(())
        }).store(in: &cancels)
    }
    
    func prepareRegisterAndLogin() {
        guard let task = registerTask else {
            return
        }
        loading.send(true)
        let code = code
        let verifyCode = Deferred {
            Future<Void, YJOpenAccountError> { promise in
                task.verifyAuthcode(authcode: code) { error in
                    if let error {
                        promise(.failure(error))
                    } else {
                        promise(.success(()))
                    }
                }
            }
        }
        
        let registerAndLogin = verifyCode.flatMap({ _ in
            return Deferred {
                Future<Void, YJOpenAccountError> { promise in
                    task.signupAndLogin() { error in
                        if let error {
                            promise(.failure(error))
                        } else {
                            promise(.success(()))
                        }
                    }
                }
            }
        }).eraseToAnyPublisher()
        
        registerAndLogin.sink(receiveCompletion: { [weak self] comp in
            self?.loading.send(false)
            if case .failure(let failure) = comp {
                self?.tips.send("注册登录失败: \(failure.rawValue)")
            }
        }, receiveValue: { [weak self] _ in
            self?.registerAndLoginSuccess.send(())
        }).store(in: &cancels)
    }
    
    
    func clearTimer() {
        timerCancel?.cancel()
        timerCancel = nil
    }
}

private extension RegisterViewModel {
    func startTimer() {
        let total = 60
        var current = total
        timerCancel = Timer.publish(every: 1, on: .main, in: .common).autoconnect().flatMap({ _ -> Just<Int> in
            current -= 1
            return Just(current)
        }).sink(receiveValue: { [weak self] d in
            if d > 0 {
                self?.sendCodeState.send(.timer(total: total, current: d))
            } else {
                self?.clearTimer()
                self?.sendCodeState.send((.reset(total: total)))
            }
        })
    }
}
