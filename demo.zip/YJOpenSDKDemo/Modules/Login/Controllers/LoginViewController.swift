//
//  LoginViewController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import UIKit
import Combine
import CombineCocoa
import FJRouter

//#define UMSDKModule __has_include(<UMCommon/UMCommon.h>)
//#define UMVerifySDKModule __has_include(<UMVerify/UMVerify.h>)
//
//#if UMSDKModule
//#import <UMCommon/UMCommon.h>
//#endif
//#if UMVerifySDKModule
//#import <UMVerify/UMVerify.h>
//#endif

import UMCommon
import UMVerify
import YJOpenSDK


private let umAppKey = "XXXX"
private let umAuthCode = "XXXX"

final class LoginViewController: UIViewController {
    private var loginView: LoginView {
        return view as! LoginView
    }
    private var viewModel: LoginViewModel!
    private var cancels: Set<AnyCancellable> = []
}

extension LoginViewController {
    override func loadView() {
        view = LoginView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        bind()
    }
}

private extension LoginViewController {
    func setup() {
        title = "登录"
        view.backgroundColor = .bgColor
        onlyDisplayBackBarItemImage()
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(title: "注册", style: .plain, target: self, action: #selector(onTapRegister)),
            UIBarButtonItem(title: "UM", style: .plain, target: self, action: #selector(onUMLoginTapped))
        ]
        
        navigationItem.leftBarButtonItems = [
            UIBarButtonItem(title: "重置密码", style: .plain, target: self, action: #selector(onResetPasswordTapped))
        ]
        
        UMConfigure.initWithAppkey(umAppKey, channel: "Test")
        UMCommonHandler.setVerifySDKInfo(umAuthCode)
    }
    
    @objc private func onResetPasswordTapped() {
        FJRouter.jump().go(.name("forgotPassword"))
    }
    
    @objc private func onUMLoginTapped() {
        UMCommonHandler.getLoginToken(
            withTimeout: 8.0,
            controller: self,
            model: nil
        ) { dict in
            guard let resultCode = dict["resultCode"] as? String else {
                return
            }
            
            if PNSCodeSuccess == resultCode,
               let token = dict["token"] as? String
            {
                print("登录成功")
                YJOpenSDKManager.default.accountService.thirdPartyLogin(
                    type: .um(umToken: token, umAppKey: umAppKey)
                ) { error in
                    #if DEBUG
                    debugPrint("\(error)")
                    #endif
                }
            }
        }
    }
    
    @IBAction func onTapRegister() {
        FJRouter.jump().go(.name("registerAccount"))
    }
    
    func bind() {
        viewModel = LoginViewModel(account: loginView.accountTextField.textField.textPublisher, pwd: loginView.pwdTextField.textField.textPublisher)
        
        viewModel.loading.sink(receiveValue: { [weak self] loading in
            loading ? self?.view.showIndicator() : self?.view.hideIndicator()
        }).store(in: &cancels)
        
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.loginEnabled.sink(receiveValue: { [weak self] enabeld in
            self?.loginView.loginButton.isEnabled = enabeld
        }).store(in: &cancels)
        
        loginView.loginButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { [weak self] in
            self?.viewModel.prepareLogin()
        }).store(in: &cancels)
        
        viewModel.loginSuccess.sink(receiveValue: {
            FJRouter.jump().go(.loc("/"))
        }).store(in: &cancels)
    }
}
