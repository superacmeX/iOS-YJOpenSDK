//
//  RegisterViewController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/25.
//

import UIKit
import Combine
import FJRouter

final class RegisterViewController: UIViewController {
    private var registerView: RegisterView {
        return view as! RegisterView
    }
    private var viewModel: RegisterViewModel!
    private var cancels: Set<AnyCancellable> = []
    
    deinit {
        viewModel.clearTimer()
    }
}

extension RegisterViewController {
    override func loadView() {
        view = RegisterView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "注册"
        view.backgroundColor = .bgColor
        bind()
    }
}

private extension RegisterViewController {
    func bind() {
        /// needLogin true为注册并登录 false为注册
        viewModel = RegisterViewModel(
            account: registerView.accountTextField.textField.textPublisher,
            code: registerView.codeTextField.textField.textPublisher,
            pwd: registerView.pwdTextField.textField.textPublisher,
            needLogin: true
        )
        
        viewModel.loading.sink(receiveValue: { [weak self] loading in
            loading ? self?.view.showIndicator() : self?.view.hideIndicator()
        }).store(in: &cancels)
        
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.codeState.sink(receiveValue: { [weak self] state in
            self?.registerView.codeButton.setTitle(state.text, for: [])
            self?.registerView.codeButton.isEnabled = state.enabled
        }).store(in: &cancels)
        
        viewModel.registerEnabled.sink(receiveValue: { [weak self] enabeld in
            self?.registerView.registerButton.isEnabled = enabeld
        }).store(in: &cancels)
        
        viewModel.registerAndLoginEnabled.sink(receiveValue: { [weak self] enabeld in
            self?.registerView.registerAndLoginButton.isEnabled = enabeld
        }).store(in: &cancels)
       
        viewModel.registerSuccess.sink(receiveValue: { [weak self] in
            self?.view.showMessage("注册成功", duration: 1.5, then: {
                self?.navigationController?.popViewController(animated: true)
            })
        }).store(in: &cancels)
        
        viewModel.registerAndLoginSuccess.sink(receiveValue: { [weak self] in
            self?.view.showMessage("注册并登录成功", duration: 1.5, then: {
                FJRouter.jump().go(.loc("/"))
            })
        }).store(in: &cancels)
        
        registerView.codeButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { [weak self] in
            self?.viewModel.prepareSendCode()
        }).store(in: &cancels)
        
        registerView.registerButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { [weak self] in
            self?.viewModel.prepareRegister()
        }).store(in: &cancels)
        
        registerView.registerAndLoginButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { [weak self] in
            self?.viewModel.prepareRegisterAndLogin()
        }).store(in: &cancels)
    }
}
