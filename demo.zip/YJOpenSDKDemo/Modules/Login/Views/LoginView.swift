//
//  LoginView.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import UIKit
import SnapKit
final class LoginView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private(set) lazy var accountTextField = EntryBoxView()
    private(set) lazy var pwdTextField = EntryBoxView()
    private(set) lazy var loginButton = UIButton()
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        accountTextField.textField.resignFirstResponder()
        pwdTextField.textField.resignFirstResponder()
    }
}

extension LoginView {
    private func setup() {
        loginButton.isEnabled = false
        loginButton.setTitle("登录", for: [])
        addSubview(loginButton)
        loginButton.snp.makeConstraints { make in
            make.left.right.equalTo(self).inset(24)
            make.height.equalTo(55)
            make.bottom.equalTo(safeAreaLayoutGuide.snp.bottom).inset(150)
        }
        
        pwdTextField.textField.placeholder = "请输入密码"
        addSubview(pwdTextField)
        pwdTextField.snp.makeConstraints { make in
            make.width.centerX.equalTo(self).inset(24)
            make.bottom.equalTo(loginButton.snp.top).offset(-60)
        }
        
        accountTextField.textField.placeholder = "请输入账号"
        addSubview(accountTextField)
        accountTextField.snp.makeConstraints { make in
            make.size.centerX.equalTo(pwdTextField)
            make.bottom.equalTo(pwdTextField.snp.top).offset(-30)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        loginButton.setBackgroundImage(UIImage(color: .theme, size: loginButton.bounds.size, cornerRadius: 12), for: .normal)
        loginButton.setBackgroundImage(UIImage(color: .gray, size: loginButton.bounds.size, cornerRadius: 12), for: .disabled)
    }
}
