//
//  EntryBoxView.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import UIKit

final class EntryBoxView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private(set) lazy var textField = UITextField()
    
    override var intrinsicContentSize: CGSize {
        let ts = textField.intrinsicContentSize
        return CGSize(width: ts.width, height: max(ts.height, 50))
    }
}

extension EntryBoxView {
    private func setup() {
        backgroundColor = UIColor(hexString: "#FAFAFA")
        layer.cornerRadius = 10
        layer.borderWidth = 1
        layer.borderColor = UIColor(hexString: "#DEE2ED")?.cgColor
        textField.clearButtonMode = .whileEditing
        textField.keyboardType = .asciiCapable
        addSubview(textField)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        textField.frame = bounds.insetBy(dx: 10, dy: 1)
    }
}
