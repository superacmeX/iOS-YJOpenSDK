//
//  APPAIAssistant.swift
//  YJOpenSDKDemo
//
//  Created by 裘俊云 on 2025/12/9.
//

import Foundation
import YJOpenSDK
//import YJSAIAssistant

final class APPAIAssistant: NSObject {
    
}

//extension APPAIAssistant: YJSAIAssistantDelegate {
//    func log(msg: String) {
//        print(msg)
//    }
//    
//    func suggest() -> [String] {
//        ["我是第一句推荐", "我是第二句推荐"]
//    }
//    
//    func route(url: String) {
//        print("route to \(url)")
//    }
//    
//    
//}
