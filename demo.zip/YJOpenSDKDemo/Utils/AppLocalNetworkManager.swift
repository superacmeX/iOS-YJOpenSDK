//
//  AppLocalNetworkManager.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/28.
//

import Foundation
import Network
import NetworkExtension
import UIKit
/// 本地网络助手
public final class AppLocalNetworkManager: NSObject {
    public enum AuthStatus: Int {
        /// 获取失败failed 等走这个
        case unknown = -1
        /// 拒绝
        case denied = 0
        /// 允许
        case allow = 1
    }
    
    /// 默认助手
    public static var `default` = AppLocalNetworkManager()
    private override init() {
        super.init()
    }
    
    /// 本地网络标识符 在info.plist 配置 Bonjour services
    /// Privacy - Local Network Usage Description String 请点击“好”以访问本地网络，发现、连接其他设备并进行数据传输
    public var browserServiceName = "_cinmoore._tcp"
    
    /// 权限申请结果
    public typealias AuthResult = (_ granted: AuthStatus) -> Void
    
    private var authResult: AuthResult?
    
    private var netService: NetService?
}

public extension AppLocalNetworkManager {
    /// 开始申请本地网络权限: 需要确保主线程
    func requestAuthorization(file: String = #file, function: String = #function, line: Int = #line, completion: AuthResult?) {
        self.authResult = completion
        guard #available(iOS 14, *) else {
            self.authResult?(.allow)
            return
        }
        iOS14_requestAuthorization()
    }
    
    /// 弹窗显示去开启本地网络
    func showNoOpenLocalNetAlert(title: String?, message: String = "本地网络不能访问, 请添加权限", source: UIViewController, goSettings: (() -> ())? = nil, cancel: (() -> ())? = nil) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "去设置", style: .default) { _ in
            goSettings?()
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url)
            }
        }
        okAction.setValue(UIColor(hexString: "#5F2AD1"), forKey: "titleTextColor")
        let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: { _ in
            cancel?()
        })
        cancelAction.setValue(UIColor(hexString: "#9B9DB1"), forKey: "titleTextColor")
        alertController.addAction(cancelAction)
        alertController.addAction(okAction)
        source.present(alertController, animated: true)
    }
    
    /// 连接设备热点
    /// - Parameters:
    ///   - ssid: 设备名称
    ///   - passphrase: 设备热点密码
    ///   - isWEP: 是否是wep
    ///   - completion: 回调
    func connectDeviceWifi(ssid: String, passphrase: String, isWEP: Bool = false, completion: @escaping (_ success: Bool) -> Void) {
        let config = NEHotspotConfiguration(ssid: ssid, passphrase: passphrase, isWEP: isWEP)
        NEHotspotConfigurationManager.shared.apply(config) { error in
            guard let error = error as? NSError else {
                // 连接成功
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    completion(true)
                }
                return
            }
            guard error.code != 13 else {
                // 已经连接
                DispatchQueue.main.async {
                    completion(true)
                }
                return
            }
            // 连接失败
            DispatchQueue.main.async { [weak self] in
                completion(false)
                if error.code != 7 { // 7是手动取消
                    self?.showLinkDeviceErrorAlert(ssid: ssid)
                }
            }
        }
    }
    
    /// 显示连接设备热点失败弹窗
    /// - Parameter ssid: 设备名称
    func showLinkDeviceErrorAlert(ssid: String) {
        UIAlertController(title: "连接设备热点失败",
                          message: "请检查设备是否重置成功, 请重试或手动切换手机WiFi网络(进入到iPhone设备->无线网络, 切换到WiF名称为\(ssid)网络)").addAction("取消").addAction("手动选择") {
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url)
            }
        }.show()
    }
    
    /// 一个方法调用连接设备热点: 申请本地网络权限+跳转未开启弹窗+连接设备热点+设备热点连接弹窗
    /// - Parameters:
    ///   - ssid: 设备名称
    ///   - passphrase: 设备热点密码
    ///   - source: 源自控制器
    ///   - completion: 回调
    func allStepsToConnectDevice(ssid: String, passphrase: String, source: UIViewController, file: String = #file, function: String = #function, line: Int = #line, completion: @escaping (_ success: Bool) -> Void) {
        DispatchQueue.main.async { [weak self] in
            self?.requestAuthorization(completion: { [weak self] granted in
                guard let self else {
                    return
                }
                switch granted {
                case .allow, .unknown: // 已有本地网络权限
                    self.connectDeviceWifi(ssid: ssid, passphrase: passphrase, completion: completion)
                case .denied:
                    completion(false)
                    self.showNoOpenLocalNetAlert(title: nil, source: source)
                }
            })
        }
    }
}

private var yjsBrowserKey: Void?
private var yjsNWConnectionKey: Void?

@available(iOS 14.0, *)
private extension AppLocalNetworkManager {
    private var browser: NWBrowser? {
        get {
            objc_getAssociatedObject(self, &yjsBrowserKey) as? NWBrowser
        }
        set {
            objc_setAssociatedObject(self, &yjsBrowserKey, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    func iOS14_requestAuthorization() {
        let parameters = NWParameters()
        parameters.includePeerToPeer = true
        
        let browser = NWBrowser(for: .bonjour(type: browserServiceName, domain: nil), using: parameters)
        self.browser = browser
        browser.stateUpdateHandler = { newState in
            switch newState {
            case .failed:
                self.reset()
                self.authResult?(.unknown)
            case .ready, .cancelled:
                return
            case .waiting:
                self.reset()
                self.authResult?(.denied)
            default:
                break
            }
        }
        
        self.netService = NetService(domain: "local.", type: self.browserServiceName, name: "LocalNetworkPrivacy", port: 1100)
        self.netService?.delegate = self
        self.browser?.start(queue: .main)
        self.netService?.publish()
    }
    
    func reset() {
        self.browser?.cancel()
        self.browser = nil
        self.netService?.delegate = nil
        self.netService?.stop()
        self.netService = nil
    }
}

@available(iOS 14.0, *)
extension AppLocalNetworkManager: NetServiceDelegate {
    public func netServiceDidPublish(_ sender: NetService) {
        self.reset()
        self.authResult?(.allow)
        self.authResult = nil
    }
}
