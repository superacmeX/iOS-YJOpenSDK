//
//  UIColor+Extensions.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/26.
//

import UIKit

extension UIColor {
    static var bgColor = UIColor(hexString: "#F3F3FD")!
    static var theme = UIColor(hexString: "#8251EC")!
}
