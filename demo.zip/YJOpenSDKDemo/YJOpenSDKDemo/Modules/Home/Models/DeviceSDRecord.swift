//
//  DeviceSDRecord.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/10.
//

import Foundation

struct DeviceSDRecord {
    /// 开始时间
    let beginTime: Double
    /// 结束时间
    let endTime: Double
    /// 事件类型
    let eventType: Int
    let beginDate: String
    let endDate: String
    private let uuid: UUID
    
    init(beginTime: Double, endTime: Double, eventType: Int, beginDate: String, endDate: String) {
        self.beginTime = beginTime
        self.endTime = endTime
        self.eventType = eventType
        self.beginDate = beginDate
        self.endDate = endDate
        self.uuid = UUID()
    }
}

extension DeviceSDRecord: Hashable {
    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.beginTime == rhs.beginTime
        && lhs.endTime == rhs.endTime
        && lhs.eventType == rhs.eventType
        && lhs.uuid == rhs.uuid
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(beginTime)
        hasher.combine(endTime)
        hasher.combine(eventType)
        hasher.combine(uuid)
    }
}
