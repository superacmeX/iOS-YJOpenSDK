//
//  DeviceInfo.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/28.
//

import Foundation
import Combine
import YJOpenSDK
struct DeviceInfo {
    let id: String
    let deviceName: String
    let productKey: String
    let nickName: String
    let iconUrl: String
    /// 类型
    let devModel: String
    /// 权限: "MANAGE", "VIEW", "CONTROL"
    let authorities: [String]
}

extension DeviceInfo {
    /// 获取设备信息
    /// - Parameter id: 设备id
    static func load(id: String) -> AnyPublisher<DeviceInfo, AppError> {
        var isFirstRequest = true
        return Just(()).setFailureType(to: AppError.self)
            .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global())
            .flatMap({ _ in
                isFirstRequest = false
                return Deferred {
                    return Future<[AnyHashable: Any], AppError> { promise in
                        YJApiClient.request(apiPath: "/user/api/v1/getDeviceBriefInfo", param: ["deviceId": id]) { code, msg, data in
                            if let json = data as? [AnyHashable: Any] {
                                promise(.success(json))
                            } else {
                                promise(.failure(AppError("失败")))
                            }
                        } fail: { error in
                            promise(.failure(AppError(error.localizedDescription, code: error.code)))
                        }
                    }
                }
            })
            .retry(2)
            .flatMap { json -> AnyPublisher<Data, AppError> in
                do {
                    let data = try JSONSerialization.data(withJSONObject: json, options: [])
                    return Just(data).setFailureType(to: AppError.self).eraseToAnyPublisher()
                } catch {
                    return Fail(error: AppError("数据解析失败")).eraseToAnyPublisher()
                }
            }
            .decode(type: DeviceInfo.self, decoder: JSONDecoder())
            .mapError({ AppError($0.localizedDescription) })
            .eraseToAnyPublisher()
    }
}

extension DeviceInfo: Decodable {
    fileprivate enum DeviceInfoCodingKey: String, CodingKey {
        case id, deviceName, productKey, nickName, devModel, authorities
        case colorPic, picUrl
    }
    
    init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: DeviceInfoCodingKey.self)
        self.id = try container.decode(String.self, forKey: .id)
        self.deviceName = try container.decodeIfPresent(String.self, forKey: .deviceName) ?? ""
        self.productKey = try container.decodeIfPresent(String.self, forKey: .productKey) ?? ""
        self.nickName = try container.decode(String.self, forKey: .nickName)
        self.devModel = try container.decode(String.self, forKey: .devModel)
        self.authorities = try container.decode([String].self, forKey: .authorities)
        if let url = try? container.decodeIfPresent(String.self, forKey: .colorPic) {
            self.iconUrl = url
        } else if let url = try? container.decodeIfPresent(String.self, forKey: .picUrl) {
            self.iconUrl = url
        } else {
            self.iconUrl = ""
        }
    }
}

extension DeviceInfo: Hashable {
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(deviceName)
        hasher.combine(productKey)
        hasher.combine(nickName)
        hasher.combine(iconUrl)
        hasher.combine(devModel)
        hasher.combine(authorities)
    }
    
    static func == (lhs: Self, rhs: Self) -> Bool {
        return lhs.id == rhs.id
        && lhs.deviceName == rhs.deviceName
        && lhs.productKey == rhs.productKey
        && lhs.iconUrl == rhs.iconUrl
        && lhs.nickName == rhs.nickName
        && lhs.devModel == rhs.devModel
        && lhs.authorities == rhs.authorities
    }
}
