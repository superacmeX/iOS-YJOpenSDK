//
//  DeviceSettingsDetailJumpCell.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/5.
//

import UIKit

final class DeviceSettingsDetailJumpCell: UICollectionViewCell {
    var icon: UIImage? {
        didSet {
            iconView.image = icon
        }
    }
    var title = "" {
        didSet {
            titleLabel.text = title
        }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    private lazy var iconView = UIImageView()
    private lazy var titleLabel = UILabel()
}

extension DeviceSettingsDetailJumpCell {
    private func setup() {
        let arrorView = UIImageView()
        arrorView.image = UIImage(systemName: "chevron.right")
        contentView.addSubview(arrorView)
        arrorView.snp.makeConstraints { make in
            make.centerY.equalTo(contentView)
            make.right.equalTo(contentView).inset(8)
        }
        
        iconView.contentMode = .scaleAspectFit
        contentView.addSubview(iconView)
        iconView.snp.makeConstraints { make in
            make.width.height.equalTo(30)
            make.centerY.equalTo(contentView)
            make.left.equalTo(contentView).offset(8)
        }
        
        titleLabel.font = UIFont.systemFont(ofSize: 15)
        titleLabel.textColor = .black
        contentView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.centerY.equalTo(contentView)
            make.left.equalTo(iconView.snp.right).offset(8)
            make.right.lessThanOrEqualTo(arrorView.snp.left).offset(-12)
        }
    }
}
