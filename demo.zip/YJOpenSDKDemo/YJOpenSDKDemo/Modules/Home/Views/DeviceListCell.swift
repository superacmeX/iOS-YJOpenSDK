//
//  DeviceListCell.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/27.
//

import UIKit

@MainActor protocol DeviceListCellDelegate: NSObjectProtocol {
    func onTapSettings(at cell: DeviceListCell)
    func onTapLiving(at cell: DeviceListCell)
    func onTapSDLiving(at cell: DeviceListCell)
    func onTapCloudLiving(at cell: DeviceListCell)
}

final class DeviceListCell: UICollectionViewCell {
    weak var delegate: (any DeviceListCellDelegate)?
    
    // 设备图标
    var iconUrl: String? {
        didSet {
            if let iconUrl {
                iconView.sd_setImage(with: URL(string: iconUrl))
            } else {
                iconView.sd_setImage(with: nil)
            }
        }
    }
    
    // 昵称
    var deviceName = "" {
        didSet {
            nameLabel.text = deviceName
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    private lazy var iconView = UIImageView()
    private lazy var nameLabel = UILabel()
}

extension DeviceListCell {
    private func setup() {
        let boxView = UIView()
        boxView.backgroundColor = .white
        boxView.layer.cornerRadius = 12
        boxView.layer.shadowColor = UIColor.gray.cgColor
        boxView.layer.shadowOpacity = 0.3
        boxView.layer.shadowOffset = CGSize(width: 2, height: 2)
        contentView.addSubview(boxView)
        boxView.snp.makeConstraints { make in
            make.edges.equalTo(contentView).inset(2)
        }
        
        iconView.contentMode = .scaleAspectFit
        boxView.addSubview(iconView)
        iconView.snp.makeConstraints { make in
            make.left.top.equalTo(boxView).offset(10)
            make.width.height.equalTo(30)
        }
        
        let settingsButton = UIButton()
        settingsButton.addTarget(self, action: #selector(onTapSettings), for: .primaryActionTriggered)
        settingsButton.setImage(UIImage(systemName: "gearshape.fill"), for: [])
        boxView.addSubview(settingsButton)
        settingsButton.snp.makeConstraints { make in
            make.centerY.equalTo(iconView)
            make.right.equalTo(boxView).inset(10)
        }
        
        nameLabel.font = UIFont.systemFont(ofSize: 17)
        nameLabel.textColor = UIColor.black
        boxView.addSubview(nameLabel)
        nameLabel.snp.makeConstraints { make in
            make.centerY.equalTo(iconView)
            make.left.equalTo(iconView.snp.right).offset(8)
            make.right.lessThanOrEqualTo(settingsButton.snp.left).offset(-12)
        }
        
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.spacing = 12
        stackView.alignment = .center
        stackView.distribution = .fillEqually
        
        boxView.addSubview(stackView)
        stackView.snp.makeConstraints { make in
            make.left.right.equalTo(boxView).inset(20)
            make.top.equalTo(iconView.snp.bottom)
            make.bottom.equalTo(boxView)
        }
        
        let livingButton = generateButton(title: "直播", action: #selector(onTapLiving))
        stackView.addArrangedSubview(livingButton)
        
        let sdButton = generateButton(title: "卡录像", action: #selector(onTapSD))
        stackView.addArrangedSubview(sdButton)
        
        let cloudButton = generateButton(title: "云录像", action: #selector(onTapCloud))
        stackView.addArrangedSubview(cloudButton)
        
        [livingButton, sdButton, cloudButton].forEach { b in
            b.snp.makeConstraints { make in
                make.height.equalTo(50)
            }
        }
    }
    
    private func generateButton(title: String, action: Selector) -> UIButton {
        let button = UIButton()
        button.layer.cornerRadius = 12
        button.layer.borderWidth = 2
        button.layer.borderColor = UIColor.theme.cgColor
        button.addTarget(self, action: action, for: .primaryActionTriggered)
        button.setAttributedTitle(NSAttributedString(string: title, attributes: [.font: UIFont.systemFont(ofSize: 14)]), for: [])
        return button
    }
    
    @IBAction private func onTapSettings() {
        delegate?.onTapSettings(at: self)
    }
    
    @IBAction private func onTapLiving() {
        delegate?.onTapLiving(at: self)
    }
    
    @IBAction private func onTapSD() {
        delegate?.onTapSDLiving(at: self)
    }
    
    @IBAction private func onTapCloud() {
        delegate?.onTapCloudLiving(at: self)
    }
}
