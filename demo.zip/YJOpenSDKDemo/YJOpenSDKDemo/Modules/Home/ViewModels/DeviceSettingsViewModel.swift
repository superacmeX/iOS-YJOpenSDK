//
//  DeviceSettingsViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/29.
//

import Foundation
import Combine
import YJOpenSDK
import FJRouter
final class DeviceSettingsViewModel {
    private(set) lazy var loading = PassthroughSubject<Bool, Never>()
    private(set) lazy var tips = PassthroughSubject<String, Never>()
    private(set) lazy var setctions = CurrentValueSubject<[DeviceSettingsSection], Never>([])
    private(set) lazy var deleteSuccess = PassthroughSubject<Void, Never>()
    private let deviceId: String
    private lazy var cancels: Set<AnyCancellable> = []
    private let devicerOperator: DevicerOperator
    init(deviceId: String) {
        self.deviceId = deviceId
        devicerOperator = DevicerOperator(id: deviceId)
    }
}

extension DeviceSettingsViewModel {
    /// 获取信息
    func loadInfo() {
        let id = self.deviceId
        loading.send(true)
        let deviceInfo = DeviceInfo.load(id: id)
        let status = DeviceStatus.loadLatest(id: id)
        let capabilitys = DeviceCapabilitys.load(id: id)
        Publishers.Zip3(deviceInfo, status, capabilitys)
        .flatMap({ pairs -> AnyPublisher<[DeviceSettingsSection], AppError> in
            Deferred {
                Future { promise in
                    _Concurrency.Task { [weak self] in
                        guard let self else {
                            promise(.failure(AppError("")))
                            return
                        }
                        let s = await self.setupWith(info: pairs.0, status: pairs.1, caps: pairs.2)
                        promise(.success(s))
                    }
                }
            }.eraseToAnyPublisher()
        }).receive(on: DispatchQueue.main).sink(receiveCompletion: { [weak self] comp in
            self?.loading.send(false)
            if case let .failure(err) = comp {
                self?.tips.send(err.localizedDescription)
            }
        }, receiveValue: { [weak self] values in
            self?.setctions.send(values)
        }).store(in: &cancels)
    }
    
    /// 重启设备: 通过下发 物模型服务指令 进行操作
    func rebootDevice() {
        loading.send(true)
        devicerOperator.invokeService(key: "Reboot", params: ["service_id": "Reboot"])
            .receive(on: OperationQueue.main)
            .sink (receiveCompletion: { [weak self] comp in
                self?.loading.send(false)
                if case let .failure(error) = comp {
                    self?.tips.send(error.localizedDescription)
                }
            }, receiveValue: { [weak self] _ in
                self?.tips.send("重启设备指令下发成功")
            }).store(in: &cancels)
    }
    
    /// 删除设备
    func deleteDevice() {
        let id = self.deviceId
        loading.send(true)
        var isFirstRequest = true
        Just(()).setFailureType(to: AppError.self)
        .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global())
        .flatMap({ _ in
            isFirstRequest = false
            return Deferred {
                return Future<Void, AppError> { promise in
                    YJApiClient.request(apiPath: "/user/api/v1/unbindDevice", param: ["deviceId": id]) { code, msg, data in
                        promise(.success(()))
                    } fail: { error in
                        promise(.failure(AppError(error.localizedDescription, code: error.code)))
                    }
                }
            }
        })
        .retry(2)
        .receive(on: OperationQueue.main)
        .sink(receiveCompletion: { [weak self] comp in
            self?.loading.send(false)
            if case let .failure(err) = comp {
                self?.tips.send(err.localizedDescription)
            }
        }, receiveValue: { [weak self] _ in
            self?.tips.send("删除设备成功")
            DispatchQueue.main.asyncAfter(deadline: .now() + 1, execute: {
                self?.deleteSuccess.send(())
            })
        }).store(in: &cancels)
    }
}

private extension DeviceSettingsViewModel {
    func setupWith(info: DeviceInfo, status: DeviceStatus, caps: DeviceCapabilitys) async -> [DeviceSettingsSection] {
        var allSetcions: [DeviceSettingsSection] = []
        // 信息
        let infoSetction = DeviceSettingsSection(section: DeviceSettingsSection.Section(title: "信息", itemHeight: 70), items: [.info(icon: info.iconUrl, name: info.nickName, dn: info.deviceName, action: "", jump: "")])
        allSetcions.append(infoSetction)
        
        // 设置项
        let voiceRouteLoc = try? await FJRouter.shared.convertLocationBy(name: "deviceVoiceSettings", params: ["deviceId": deviceId])
        let voiceItem = DeviceSettingsSection.Item.detail(icon: UIImage(systemName: "speaker.wave.3"), title: "声音设置", jump: voiceRouteLoc ?? "")
        
        let settingsSection = DeviceSettingsSection(section: DeviceSettingsSection.Section(title: "设置项", itemHeight: 50), items: [voiceItem])
        allSetcions.append(settingsSection)
        
        // 重启
        let resetSetcion = DeviceSettingsSection(section: DeviceSettingsSection.Section(title: "重启设备", itemHeight: 50), items: [.buttons(icon: UIImage(systemName: "power")?.withTintColor(.theme, renderingMode: .alwaysOriginal), title: NSAttributedString(string: "重启设备", attributes: [.foregroundColor: UIColor.black]), action: "onTapReboot:")])
        allSetcions.append(resetSetcion)
        
        // 删除
        let deleteSetcion = DeviceSettingsSection(section: DeviceSettingsSection.Section(title: "删除设备", itemHeight: 50), items: [.buttons(icon: nil, title: NSAttributedString(string: "删除设备", attributes: [.foregroundColor: UIColor.red]), action: "onTapDelete:")])
        allSetcions.append(deleteSetcion)

        return allSetcions
    }
}
