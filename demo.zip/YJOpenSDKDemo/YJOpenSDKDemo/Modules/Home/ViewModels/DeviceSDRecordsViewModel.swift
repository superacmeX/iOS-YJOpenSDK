//
//  DeviceSDRecordsViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/10.
//

import Foundation
import Combine
import YJOpenSDK

final class DeviceSDRecordsViewModel {
    /// 打点信息
    private(set) lazy var eventDots = CurrentValueSubject<[Date], Never>([])
    private(set) lazy var device = CurrentValueSubject<DeviceInfo?, Never>(nil)
    private(set) lazy var tips = PassthroughSubject<String, Never>()
    private lazy var envetRequest = PassthroughSubject<String, Never>()
    let deviceId: String
    private let dateFormatter: DateFormatter
    private lazy var cancels: Set<AnyCancellable> = []
    private let devicerOperator: DevicerOperator
    init(deviceId: String) {
        self.deviceId = deviceId
        devicerOperator = DevicerOperator(id: deviceId)
        dateFormatter = DateFormatter()
        dateFormatter.locale = Locale.init(identifier: "zh_Hans_CN")
        dateFormatter.calendar = Calendar.init(identifier: .iso8601)
        dateFormatter.timeZone = TimeZone.autoupdatingCurrent
        dateFormatter.dateFormat = "yyyyMM"
        
        envetRequest.removeDuplicates()
            .map({ [weak self] month -> AnyPublisher<[Date], Never> in
            if let self {
                return self.requestMonthEvent(month: month)
            }
            return Just([]).eraseToAnyPublisher()
        })
        .switchToLatest()
        .sink(receiveValue: { [weak self] values in
            self?.eventDots.send(values)
        }).store(in: &cancels)
        
        DeviceInfo.load(id: deviceId).receive(on: RunLoop.main)
        .sink(receiveCompletion: { _ in
            
        }, receiveValue: { [weak self] obj in
            self?.device.send(obj)
        }).store(in: &cancels)
    }
}

extension DeviceSDRecordsViewModel {
    /// 查询月打点
    func prepareLoadMonthEventDot(for date: Date) {
        let hasSearchMonth = eventDots.value.contains { d in
            Calendar.current.isDate(date, equalTo: d, toGranularity: .month)
        }
        if hasSearchMonth {
            return
        }
        envetRequest.send(dateFormatter.string(from: date))
    }
    
    private func requestMonthEvent(month: String) -> AnyPublisher<[Date], Never> {
        let date = dateFormatter.date(from: month)
        let timestamp = date?.timeIntervalSince1970 ?? Date().timeIntervalSince1970
        let params: [String: Any] = [
            "month": month,
            "monthTimeStamp": timestamp
        ]
        return devicerOperator.invokeService(key: "QueryRecordMonthView", params: params)
        .compactMap({ data -> [Int]? in
            if let data = data as? [AnyHashable: Any], let flags = data["recordFlags"] as? String {
                var result: [Int] = []
                for (index, char) in Array(flags).enumerated() {
                    if char == "1" {
                        result.append(index)
                    }
                }
                return result
            }
            return nil
        })
        .map({ indexs -> [Date] in
            return indexs.map { idx in
                let tis = timestamp + 86400 * Double(idx)
                return Date(timeIntervalSince1970: TimeInterval(tis))
            }
        })
        .replaceError(with: [])
        .eraseToAnyPublisher()
    }
}
