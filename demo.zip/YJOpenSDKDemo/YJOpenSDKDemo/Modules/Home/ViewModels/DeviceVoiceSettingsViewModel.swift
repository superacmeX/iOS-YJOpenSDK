//
//  DeviceVoiceSettingsViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/5.
//

import Foundation
import Combine
import YJOpenSDK

final class DeviceVoiceSettingsViewModel {
    private(set) lazy var loading = PassthroughSubject<Bool, Never>()
    private(set) lazy var tips = PassthroughSubject<String, Never>()
    private(set) lazy var currentVolume = CurrentValueSubject<Int, Never>(50)
    private lazy var changeVolume = PassthroughSubject<Int, Never>()
    private let deviceId: String
    private lazy var cancels: Set<AnyCancellable> = []
    private let devicerOperator: DevicerOperator
    init(deviceId: String) {
        self.deviceId = deviceId
        devicerOperator = DevicerOperator(id: deviceId)
        
        changeVolume.map({ [weak self] value -> AnyPublisher<Int, Never> in
            guard let self else {
                return Just(0).eraseToAnyPublisher()
            }
            return self.dealChangeVolume(value)
        })
        .switchToLatest()
        .receive(on: RunLoop.main)
        .sink(receiveValue: { [weak self] value in
            self?.loading.send(false)
            self?.currentVolume.send(value)
        }).store(in: &cancels)
    }
}

extension DeviceVoiceSettingsViewModel {
    /// 获取设备的物模型属性值
    func loadInfo() {
        loading.send(true)
        devicerOperator.getProperties(key: "CallVolume")
            .receive(on: RunLoop.main)
            .sink(receiveCompletion: { [weak self] comp in
                self?.loading.send(false)
                if case let .failure(err) = comp {
                    self?.tips.send(err.localizedDescription)
                }
            }, receiveValue: { [weak self] value in
                if let v = value as? Int {
                    self?.currentVolume.send(v)
                } else if let v = value as? Float {
                    self?.currentVolume.send(Int(v))
                }
            }).store(in: &cancels)
    }
    
    func prepareChangeVolume(_ value: Float) {
        let v = Int(value)
        if v == currentVolume.value {
            return
        }
        changeVolume.send(v)
    }
    
    /// 设置设备的物模型属性
    private func dealChangeVolume(_ value: Int) -> AnyPublisher<Int, Never> {
        loading.send(true)
        return devicerOperator.setProperties(key: "CallVolume", params: value)
            .map({ _ in value })
            .catch({ [weak self] err in
                self?.tips.send(err.localizedDescription)
                return Just(self?.currentVolume.value ?? value)
            })
            .eraseToAnyPublisher()
    }
}
