//
//  DeviceDaySDRecordsViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/10.
//

import Foundation
import Combine
import YJOpenSDK
import Gzip
final class DeviceDaySDRecordsViewModel {
    private(set) lazy var records = CurrentValueSubject<[DeviceSDRecord], Never>([])
    private(set) lazy var tips = PassthroughSubject<String, Never>()
    private(set) lazy var endRefresh = PassthroughSubject<Void, Never>()
    private(set) var device: DeviceInfo?
    private let deviceId: String
    private lazy var request = PassthroughSubject<Void, Never>()
    private lazy var cancels: Set<AnyCancellable> = []
    let date: Date
    private let dateFormatter: DateFormatter
    private let devicerOperator: DevicerOperator
    init(deviceId: String, date: Date) {
        self.deviceId = deviceId
        self.date = date
        devicerOperator = DevicerOperator(id: deviceId)
        dateFormatter = DateFormatter()
        dateFormatter.locale = Locale.init(identifier: "zh_Hans_CN")
        dateFormatter.calendar = Calendar.init(identifier: .iso8601)
        dateFormatter.timeZone = TimeZone.autoupdatingCurrent
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        request.map({ [weak self] _ -> AnyPublisher<[DeviceSDRecord], Never> in
            if let self {
                return self.dealLoadRecords().eraseToAnyPublisher()
            }
            return Just([]).eraseToAnyPublisher()
        }).switchToLatest()
        .receive(on: OperationQueue.main)
        .sink(receiveValue: { [weak self] objs in
            self?.records.send(objs)
            self?.endRefresh.send(())
        }).store(in: &cancels)
    }
}

extension DeviceDaySDRecordsViewModel {
    func updateDeviceInfo(_ device: DeviceInfo?) {
        self.device = device
    }
    
    func loadRecords() {
        request.send(())
    }
    
    private func dealLoadRecords() -> AnyPublisher<[DeviceSDRecord], Never> {
        let calendar = Calendar.current
        // 获取当前日期的开始时间（第一秒）
        let startDate = calendar.startOfDay(for: date)
        // 获取当前日期的结束时间（最后一秒）
        let endDate = calendar.date(byAdding: .day, value: 1, to: startDate) ?? Date()
        let startTimeInterval = startDate.timeIntervalSince1970
        let endTimeInterval = endDate.timeIntervalSince1970 - 1
        return queryAllDateeRecords(start: startTimeInterval, end: endTimeInterval)
    }
    
    private func queryAllDateeRecords(start: Double, end: Double) -> AnyPublisher<[DeviceSDRecord], Never> {
        let pageSize = 100
        return queryPageRecord(start: start, end: end, page: 0, pageSize: pageSize)
            .flatMap({ pairs -> AnyPublisher<[DeviceSDRecord], Never> in
                let (files, currentPage, totalPage) = pairs
                if currentPage >= (totalPage - 1) {
                    return Just(files).eraseToAnyPublisher()
                }
                let indexs = Array((currentPage + 1)...(totalPage - 1))
                let others = indexs.compactMap { [weak self] page in
                    return self?.queryPageRecord(start: start, end: end, page: page, pageSize: pageSize).map({ $0.files }).replaceError(with: [])
                }
                let all = Publishers.MergeMany(others).reduce(files) { result, pairs in
                    var final = result
                    final.append(contentsOf: pairs)
                    return final
                }.replaceError(with: [])
                return all.eraseToAnyPublisher()
            })
            .replaceError(with: [])
            .eraseToAnyPublisher()
    }
    
    private func queryPageRecord(start: Double, end: Double, page: Int, pageSize: Int) -> AnyPublisher<(files: [DeviceSDRecord], currentPage: Int, totalPage: Int), AppError> {
        let params:[String : Any] = [
            "BeginTime": start,
            "EndTime": end,
            "PageSize": pageSize,
            "Type": 99,
            "PageNo": page
        ]
        return devicerOperator.invokeService(key: "QueryRecordTimeListByPage", params: params)
            .receive(on: DispatchQueue.global())
            .flatMap({ data -> AnyPublisher<([String], Int), Never> in
                guard let json = data as? [AnyHashable: Any],
                      let timeList = json["TimeList"] as? [String] else {
                    return Just(([], 0)).eraseToAnyPublisher()
                }
                let totalCount = (json["TotalCount"] as? Int) ?? 1
                guard let encoding = json["Encoding"] as? String, encoding == "gzip", let base64Encod = timeList.first else {
                    return Just((timeList, totalCount)).eraseToAnyPublisher()
                }
                return Future ({ promise in
                    guard let base64EncodedData = base64Encod.data(using: .utf8),
                            let compressedData = Data( base64Encoded: base64EncodedData),
                           let decodedData = try? compressedData.gunzipped(),
                           let decodedString = String(data: decodedData, encoding: .utf8) else {
                        promise(.success((timeList, totalCount)))
                        return
                    }
                    let list = decodedString.components(separatedBy: ",")
                    promise(.success((list, totalCount)))
                }).eraseToAnyPublisher()
            })
            .map({ pairs -> ([DeviceSDRecord], Int) in
                let (list, total) = pairs
                let files = list.compactMap { [weak self] time -> DeviceSDRecord? in
                    guard let self else {
                        return nil
                    }
                    let elements = time.components(separatedBy: "_")
                    guard elements.count >= 4 else {
                        return nil
                    }
                    let hourStr = elements[0]
                    let typeStr = elements[1]
                    let startInHoutStr = elements[2]
                    let lengthStr = elements[3]
                    let nf = NumberFormatter()
                    guard let hour = nf.number(from: hourStr)?.intValue,
                          let type = nf.number(from: typeStr)?.intValue,
                          let startInHout = nf.number(from: startInHoutStr)?.intValue,
                          let length = nf.number(from: lengthStr)?.intValue else {
                        return nil
                    }
                    let beginTime = start + Double(hour * 3600 + startInHout)
                    let endTime = beginTime + Double(length)
                    let bd = self.dateFormatter.string(from: Date(timeIntervalSince1970: beginTime))
                    let ed = self.dateFormatter.string(from: Date(timeIntervalSince1970: endTime))
                    return DeviceSDRecord(beginTime: beginTime, endTime: endTime, eventType: type, beginDate: bd, endDate: ed)
                }
                return (files, total)
            })
            .map({ ($0.0, page, $0.1) })
            .eraseToAnyPublisher()
    }
}
