//
//  ScanResultController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/25.
//

import UIKit
import Combine
import FJRouter
final class ScanResultController: UIViewController {
    init(qr: String) {
        viewModel = ScanResultViewModel(qr: qr)
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private let viewModel: ScanResultViewModel
    private var cancels: Set<AnyCancellable> = []
    private var resultView: ScanResultView {
        return view as! ScanResultView
    }
}

extension ScanResultController {
    override func loadView() {
        view = ScanResultView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        bind()
        viewModel.loadInfo()
    }
}

private extension ScanResultController {
    func setup() {
        onlyDisplayBackBarItemImage()
        view.backgroundColor = .bgColor
        title = "重置设备"
    }
    
    func bind() {
        viewModel.loading.sink(receiveValue: { [weak self] loading in
            loading ? self?.view.showIndicator() : self?.view.hideIndicator()
        }).store(in: &cancels)
        
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.info.sink(receiveValue: { [weak self] info in
            self?.resultView.nextButton.isEnabled = true
        }).store(in: &cancels)
        
        resultView.nextButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { [weak self] in
            if let self {
                // TODO: - 区分设备绑定类型: wifi、4g还是蓝牙设备,
                // 此处只是wifi绑定设备事例
                try? FJRouter.shared.goNamed("wifiBind", params: ["pk": self.viewModel.pk, "dn": self.viewModel.dn])
            }
        }).store(in: &cancels)
    }
}
