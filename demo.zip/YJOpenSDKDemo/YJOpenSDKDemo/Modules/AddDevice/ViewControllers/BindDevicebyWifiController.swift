//
//  BindDevicebyWifiController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/27.
//

import UIKit
import Combine

final class BindDevicebyWifiController: UIViewController {
    init(productKey: String, deviceName: String) {
        self.productKey = productKey
        self.deviceName = deviceName
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private let productKey: String
    private let deviceName: String
    private var viewModel: BindDevicebyWifiViewModel!
    private var cancels: Set<AnyCancellable> = []
    private var backItem: UIBarButtonItem!
    private var bindView: BindDevicebyWifiView {
        return view as! BindDevicebyWifiView
    }
}

extension BindDevicebyWifiController {
    override func loadView() {
        view = BindDevicebyWifiView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        bind()
    }
}

private extension BindDevicebyWifiController {
    func setup() {
        title = "WiFi绑定"
        backItem = UIBarButtonItem(image: UIImage(systemName: "chevron.left"), style: .plain, target: self, action: #selector(self.onBack))
    }
    
    @IBAction func onBack() {
        let alertVC = UIAlertController(title: "确定停止绑定设备吗?", message: nil, preferredStyle: .alert)
        let cancel = UIAlertAction(title: "继续", style: .default)
        let ok = UIAlertAction(title: "停止", style: .destructive) { [weak self] _ in
            self?.viewModel.stopBind()
        }
        alertVC.addAction(cancel)
        alertVC.addAction(ok)
        present(alertVC, animated: true)
    }
    
    func bind() {
        viewModel = BindDevicebyWifiViewModel(
            productKey: productKey,
            deviceName: deviceName,
            wifi: bindView.wifissidTextField.textField.textPublisher,
            pwd: bindView.wifipwdTextField.textField.textPublisher
        )
        
        viewModel.loading.sink(receiveValue: { [weak self] loading in
            loading ? self?.view.showIndicator() : self?.view.hideIndicator()
        }).store(in: &cancels)
        
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.binging.sink(receiveValue: { [weak self] binging in
            self?.navigationItem.leftBarButtonItem = binging ? self?.backItem : nil
        }).store(in: &cancels)
        
        viewModel.bindSuccess.sink(receiveValue: { [weak self] did in
            self?.navigationController?.popToRootViewController(animated: true)
        }).store(in: &cancels)
        
        viewModel.bindEnabled.sink(receiveValue: { [weak self] e in
            self?.bindView.bindButton.isEnabled = e
        }).store(in: &cancels)
        
        bindView.bindButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { [weak self] in
            self?.connectDeviceWifi()
        }).store(in: &cancels)
    }
    
    func connectDeviceWifi() {
        AppLocalNetworkManager.default.requestAuthorization { [weak self] granted in
            guard let self else {
                return
            }
            switch granted {
            case .allow, .unknown: // 已有本地网络权限
                self.viewModel.prepareBind()
            case .denied:
                AppLocalNetworkManager.default.showNoOpenLocalNetAlert(title: nil, source: self)
            }
        }
    }
}
