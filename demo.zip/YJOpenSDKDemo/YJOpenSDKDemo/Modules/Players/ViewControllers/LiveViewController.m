//
//  LiveViewController.m
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2024/12/10.
//

#import "LiveViewController.h"
#import "BaseDef.h"

@interface LiveViewController () <
RMPlayerDelegate,
RMPSEIDataDelegate,
RTC_OBJC_TYPE(RTCVideoSink)
>

@property (nonatomic, strong) RMPNetLivePlayer *player;
@property (nonatomic, strong) UIView *videoBaseView;
@property (nonatomic, strong) UIView *playerVideoView;
@property (nonatomic, strong) UIActivityIndicatorView *loadingIndicator;
@property (nonatomic, copy) NSString *deviceName;
@property (nonatomic, copy) NSString *productKey;
@end

@implementation LiveViewController

- (instancetype)initWithDeviceName:(NSString *)devName productKey:(NSString *)prodKey {
    if (self = [super init]) {
        self.deviceName = devName;
        self.productKey = prodKey;
    }

    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setUpUI];
    [self setUpPlayer];
}

- (void)setUpPlayer {
    RMPNetPlayerConfig *config = [[RMPNetPlayerConfig alloc] init];
    config.deviceName = self.deviceName;
    config.productKey = self.productKey;

    self.player = [RMPNetLivePlayer createWithConfig:config];
    self.player.delegate = self;
    self.playerVideoView = [self.player playerView];
    [self.videoBaseView addSubview:self.playerVideoView];
    [self.playerVideoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    self.playerVideoView.backgroundColor = YJColorBlack;
    [self.player setVideoSink:self];
    [self.player start];
    [self startLoading];
}

- (void)setUpUI {
    self.title = @"直播";

    self.videoBaseView = [[UIView alloc] initWithFrame:CGRectMake(0, kNavigationBarHeight+20, kMainScreenWidth, kMainScreenWidth* 9 / 16)];
    [self.view addSubview:self.videoBaseView];

    //pannel
    CGFloat panel_w = kMainScreenWidth;
    CGFloat panel_h = kMainScreenWidth * 9 / 32;
    //pannel
    UIView *pannel = [[UIView alloc] initWithFrame:CGRectZero];
    pannel.backgroundColor = [[UIColor alloc] initWithWhite:0.667 alpha:1.0];
    [self.view addSubview:pannel];
    [pannel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.view).offset(-20);
        make.size.mas_equalTo(CGSizeMake(panel_w, panel_h));
    }];

    //btn param
    CGFloat btn_x_gap = 10;
    CGFloat btn_y_gap = 10;

    CGFloat btn_w = (panel_w - btn_x_gap * 5) / 4;
    CGFloat btn_h = (panel_h - btn_y_gap * 3) / 2;
    CGSize btnSize = CGSizeMake(btn_w, btn_h);
    //stop/start
    UIButton *stopBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    WS(weakSelf);
    [stopBtn addActionHandler:^(UIControl *control) {
        UIButton *btn = (UIButton *)control;
        btn.selected = !btn.selected;
        if (btn.selected) {
            [weakSelf.player stop];
//            [weakSelf.player setSeiDataCallback:nil];
            [btn setTitle:@"start" forState:UIControlStateNormal];
        }
        else {
            [weakSelf.player start];
//            [weakSelf.player setSeiDataCallback:weakSelf];
            [btn setTitle:@"stop" forState:UIControlStateNormal];
        }
    }];
    [stopBtn setTitle:@"stop" forState:UIControlStateNormal];
    stopBtn.titleLabel.font = [UIFont fontOfSize:15];
    [stopBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [stopBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    stopBtn.layer.masksToBounds = YES;
    stopBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:stopBtn];
    [stopBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap);
        make.size.mas_equalTo(btnSize);
    }];
    //mute/unmute
    UIButton *mutBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    [mutBtn addActionHandler:^(UIControl *control) {
        UIButton *btn = (UIButton *)control;
        btn.selected = !btn.selected;
        if (btn.selected) {
            [weakSelf.player muteRemoteAudio:NO];
            [btn setTitle:@"mute" forState:UIControlStateNormal];
        }
        else {
            [weakSelf.player muteRemoteAudio:YES];
            [btn setTitle:@"unmute" forState:UIControlStateNormal];
        }
    }];
    [mutBtn setTitle:@"unmute" forState:UIControlStateNormal];
    mutBtn.titleLabel.font = [UIFont fontOfSize:15];
    [mutBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [mutBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    mutBtn.layer.masksToBounds = YES;
    mutBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:mutBtn];
    [mutBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(stopBtn.mas_right).offset(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap);
        make.size.mas_equalTo(btnSize);
    }];
    //talk open/close
    UIButton *talkBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    [talkBtn addActionHandler:^(UIControl *control) {
        UIButton *btn = (UIButton *)control;
        btn.selected = !btn.selected;
        if (btn.selected) {
            [weakSelf.player startTalk];
            [btn setTitle:@"talk close" forState:UIControlStateNormal];
        }
        else {
            [weakSelf.player stopTalk];
            [btn setTitle:@"talk open" forState:UIControlStateNormal];
        }
    }];
    [talkBtn setTitle:@"talk open" forState:UIControlStateNormal];
    talkBtn.titleLabel.font = [UIFont fontOfSize:15];
    [talkBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [talkBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    talkBtn.layer.masksToBounds = YES;
    talkBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:talkBtn];
    [talkBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(mutBtn.mas_right).offset(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap);
        make.size.mas_equalTo(btnSize);
    }];
    //record
    UIButton *recordBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    [recordBtn addActionHandler:^(UIControl *control) {
        UIButton *btn = (UIButton *)control;
        btn.selected = !btn.selected;
        if (btn.selected) {
            NSString *path = [NSHomeDirectory() stringByAppendingString:@"/Documents/"];
            path = [NSString stringWithFormat:@"%@_net_live_vid_%d.mp4", path, (int)arc4random()];
            [weakSelf.player startFileRecording:path];
            [btn setTitle:@"record end" forState:UIControlStateNormal];
        }
        else {
            [weakSelf.player stopFileRecording];
            [btn setTitle:@"record start" forState:UIControlStateNormal];
        }
    }];
    [recordBtn setTitle:@"record start" forState:UIControlStateNormal];
    recordBtn.titleLabel.font = [UIFont fontOfSize:15];
    [recordBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [recordBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    recordBtn.layer.masksToBounds = YES;
    recordBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:recordBtn];
    [recordBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(talkBtn.mas_right).offset(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap);
        make.size.mas_equalTo(btnSize);
    }];
    //snapshot
    UIButton *snapshotBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    [snapshotBtn addActionHandler:^(UIControl *control) {
        NSString *path = [NSHomeDirectory() stringByAppendingString:@"/Documents/"];
        path = [NSString stringWithFormat:@"%@_net_live_pic_%d.jpg", path, (int)arc4random()];
        [weakSelf.player snapshot:path];
    }];
    [snapshotBtn setTitle:@"snapshot" forState:UIControlStateNormal];
    snapshotBtn.titleLabel.font = [UIFont fontOfSize:15];
    [snapshotBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [snapshotBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    snapshotBtn.layer.masksToBounds = YES;
    snapshotBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:snapshotBtn];
    [snapshotBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap*2+btn_h);
        make.size.mas_equalTo(btnSize);
    }];
}

#pragma mark - RTCVideoSink
- (void)onFrame:(nullable RTC_OBJC_TYPE(RTCVideoFrame) *)frame {
    id<RTC_OBJC_TYPE(RTCI420Buffer)> buffer = [frame.buffer toI420];
    const uint8_t *dataY = buffer.dataY;
    const uint8_t *dataU = buffer.dataU;
    const uint8_t *dataV = buffer.dataV;

    int strideY = buffer.strideY;
    int strideU = buffer.strideU;
    int strideV = buffer.strideV;

    int width  = buffer.width;
    int height = buffer.height;


//    NSLog(@"@@@@@@@@@@wing start [wxh] = [%d, %d], frame.timeStamp=%d", width, height, frame.timeStamp);

//    if (self.dumpfile == NULL) {
//        NSString *path = [NSHomeDirectory() stringByAppendingString:@"/Documents/"];
//        self.path = [NSString stringWithFormat:@"%@_void_I420_%d.yuv", path, (int)arc4random()];
//
//        const char *p = [self.path UTF8String];
//
//        self.dumpfile = fopen(p, "wb");
//
//        NSLog(@"@@@@@@@@@@wing 1111 open %@, [wxh] = [%d, %d]", self.path, width, height);
//    }
//
//
//    // Dump Y plane
//    for (int i = 0; i < height; i++) {
//        fwrite(dataY + i * strideY, 1, width, self.dumpfile);
//    }
//
//    // Dump UV plane
//    for (int i = 0; i < height / 2; i++) {
//        fwrite(dataU + i * strideU, 1, width/2, self.dumpfile);
//    }
//
//    // Dump V plane
//    for (int i = 0; i < height / 2; i++) {
//        fwrite(dataV + i * strideV, 1, width/2, self.dumpfile);
//    }

//    NSLog(@"@@@@@@@@@@wing end [wxh] = [%d, %d]", width, height);
}

#pragma mark - LoadingIndicator

- (UIActivityIndicatorView *)loadingIndicator {
    if (!_loadingIndicator) {
        UIActivityIndicatorViewStyle type = UIActivityIndicatorViewStyleWhiteLarge;
        if (@available(iOS 13.0, *)) {
            type = UIActivityIndicatorViewStyleLarge;
        }
        _loadingIndicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:type];
        _loadingIndicator.color = [UIColor greenColor];
        [self.videoBaseView addSubview:_loadingIndicator];
        [_loadingIndicator mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(self.videoBaseView);
        }];
    }
    return _loadingIndicator;
}

- (void)startLoading {
    WS(weakSelf);
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakSelf.loadingIndicator startAnimating];
    });
}

- (void)stopLoading {
    WS(weakSelf);
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakSelf.loadingIndicator stopAnimating];
    });
}

#pragma mark - RMPlayerDelegate

- (void)player:(id)player onBufferStateUpdate:(RMPlayerBufferState)state bufferDurationMillis:(NSInteger)bufferDurationMillis {
    NSLog(@"%s--%d, state =%ld, bufferDurationMillis=%ld", __FUNCTION__, __LINE__, state, bufferDurationMillis);
    switch (state) {
        case RMPlayerBufferState_Loading:
            [self startLoading];
            break;
        case RMPlayerBufferState_Ready:
            [self stopLoading];
            break;
        default:
            break;
    }
}

- (void)player:(id)player onError:(RMPlayerErrorType)type playErrorCode:(RMPlayerErrorCode)code playErrorDesc:(NSString *)desc {
    NSLog(@"%s--%d,, player=%@, type=%ld, code=%ld, desc=%@", __FUNCTION__, __LINE__, player, (long)type, (long)code, desc);

    NSString *tips = @"播放失败";
    NSString *message = [NSString stringWithFormat:@"type(%ld), code(%ld), %@", type, code, desc];
    UIAlertController *alertTips = [UIAlertController alertControllerWithTitle:tips message:message preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:alertTips animated:true completion:nil];
    WS(weakSelf);
    [alertTips addAction:[UIAlertAction actionWithTitle:@"重试" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        RMPNetLivePlayer *p = player;
        [p stop];
        [p start];
        [weakSelf startLoading];
    }]];
    [alertTips addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];

}

- (void)player:(id)player onFileRecordingError:(NSString *)file recordErrorCode:(RMPlayerRecordingError)code recordErrorDesc:(NSString *)desc {
    NSLog(@"%s--%d,, player=%@, file=%@, code=%ld, desc=%@", __FUNCTION__, __LINE__, player, file, (long)code, desc);
    NSString *toast = [NSString stringWithFormat:@"code[%ld], %@", (long)code, desc];
    [YJToast showToast:toast];
}

- (void)player:(id)player onFileRecordingFinish:(NSString *)file {
    NSLog(@"%s--%d,, player=%@, file=%@", __FUNCTION__, __LINE__, player, file);
    NSString *toast = [NSString stringWithFormat:@"saved[%@]", file];
    [YJToast showToast:toast];
}

- (void)player:(id)player onFileRecordingStart:(NSString *)file {
    NSLog(@"%s--%d,, player=%@, file=%@", __FUNCTION__, __LINE__, player, file);
}

- (void)player:(id)player onFirstFrameRendered:(NSInteger)elapseMills {
    NSLog(@"%s--%d, player=%@, elapseMills=%ld", __FUNCTION__, __LINE__, player, elapseMills);
    [self stopLoading];
}

- (void)player:(id)player onPlayerStateChange:(RMPlayerState)state {
    NSLog(@"%s--%d, state=%ld", __FUNCTION__, __LINE__, state);
}

- (void)player:(id)player onSnapshotResult:(NSString *)file snapErrorCode:(RMPlayerSnapshotResult)code snapErrorDesc:(NSString *)desc {
    NSLog(@"%s--%d, file=%@, code=%ld, desc=%@", __FUNCTION__, __LINE__, file, (long)code, desc);
}

- (void)player:(id)player onTalkStateChange:(RMPlayerTalkState)state {
    NSLog(@"%s--%d, player=%@, talk_state=%ld", __FUNCTION__, __LINE__, player, (long)state);
}

- (void)player:(id)player onVideoSizeChanged:(CGSize)size {
    NSLog(@"%s--%d, player=%@, size=[%f x %f]", __FUNCTION__, __LINE__, player, size.width, size.height);
}

- (void)player:(id)player onSeiData:(NSData *)data pts:(long)pts {
    NSLog(@"%s--%d, data=%@, pts=%ld", __FUNCTION__, __LINE__, data, pts);
}

@end
