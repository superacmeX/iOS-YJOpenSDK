//
//  TCardVodViewController.h
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2024/12/11.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TCardVodViewController : UIViewController

- (instancetype)initWithDeviceName:(NSString *)devName
                        productKey:(NSString *)prodKey
                         startTime:(long)startTime
                           endTime:(long)endTime;

@end

NS_ASSUME_NONNULL_END
