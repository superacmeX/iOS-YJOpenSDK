//
//  CloudVodViewController.h
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2024/12/11.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CloudVodViewController : UIViewController

- (instancetype)initWithDeviceName:(NSString *)devName
                        productKey:(NSString *)prodKey
                               url:(NSString *)url
                              meta:(NSString *)meta;

@end

NS_ASSUME_NONNULL_END
