//
//  TCardVodViewController.m
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2024/12/11.
//

#import "TCardVodViewController.h"
#import "BaseDef.h"

@interface TCardVodViewController ()<
RMPlayerDelegate,
RMPSEIDataDelegate>

@property (nonatomic, strong) RMPNetVodPlayer *player;
@property (nonatomic, strong) UIView *videoBaseView;
@property (nonatomic, strong) UIView *playerVideoView;
@property (nonatomic, strong) UIActivityIndicatorView *loadingIndicator;
@property (nonatomic, assign) int speedIdx;
@property (nonatomic, strong) NSArray <NSNumber *>*speedArr;
@property (nonatomic, strong) UILabel *progressLabel;
@property (nonatomic, copy) NSString *deviceName;
@property (nonatomic, copy) NSString *productKey;
@property (nonatomic, assign) long startTime;
@property (nonatomic, assign) long seekTime;
@property (nonatomic, assign) long endTime;
@end

@implementation TCardVodViewController

- (instancetype)initWithDeviceName:(NSString *)devName 
                        productKey:(NSString *)prodKey
                         startTime:(long)startTime
                           endTime:(long)endTime {
    if (self = [super init]) {
        self.deviceName = devName;
        self.productKey = prodKey;
        self.startTime  = startTime;
        self.seekTime   = startTime;
        self.endTime    = endTime;
    }

    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    self.speedIdx = 0;
    self.speedArr = @[@(1), @(4), @(8), @(16)];

    [self setUpUI];
    [self setUpPlayer];
}

- (void)setUpPlayer {
    RMPNetPlayerConfig *config = [[RMPNetPlayerConfig alloc] init];
    config.deviceName = self.deviceName;
    config.productKey = self.productKey;

    self.player = [RMPNetVodPlayer createWithConfig:config];
    self.player.delegate = self;
    self.playerVideoView = [self.player playerView];
    [self.videoBaseView addSubview:self.playerVideoView];
    [self.playerVideoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    self.playerVideoView.backgroundColor = YJColorBlack;

    [self.player setRangeStartSec:self.startTime endSec:self.endTime seekSec:self.seekTime-self.startTime];
    [self.player setSeiDataCallback:self];

    [self.player start];
    [self startLoading];
}

- (void)setUpUI {
    self.title = @"T卡录像";

    self.videoBaseView = [[UIView alloc] initWithFrame:CGRectMake(0, kNavigationBarHeight+20, kMainScreenWidth, kMainScreenWidth* 9 / 16)];
    [self.view addSubview:self.videoBaseView];
    
    //panneld
    CGFloat panel_w = kMainScreenWidth;
    CGFloat panel_h = kMainScreenWidth * 9 / 32;
    //pannel
    UIView *pannel = [[UIView alloc] initWithFrame:CGRectZero];
    pannel.backgroundColor = [[UIColor alloc] initWithWhite:0.667 alpha:1.0];
    [self.view addSubview:pannel];
    [pannel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.view).offset(-20);
        make.size.mas_equalTo(CGSizeMake(panel_w, panel_h));
    }];

    //btn param
    CGFloat btn_x_gap = 10;
    CGFloat btn_y_gap = 10;

    CGFloat btn_w = (panel_w - btn_x_gap * 5) / 4;
    CGFloat btn_h = (panel_h - btn_y_gap * 3) / 2;
    CGSize btnSize = CGSizeMake(btn_w, btn_h);
    //stop/start
    UIButton *stopBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    WS(weakSelf);
    [stopBtn addActionHandler:^(UIControl *control) {
        UIButton *btn = (UIButton *)control;
        btn.selected = !btn.selected;
        if (btn.selected) {
            [weakSelf.player stop];
            [btn setTitle:@"start" forState:UIControlStateNormal];
        }
        else {
            [weakSelf.player start];
            [btn setTitle:@"stop" forState:UIControlStateNormal];
        }
    }];
    [stopBtn setTitle:@"stop" forState:UIControlStateNormal];
    stopBtn.titleLabel.font = [UIFont fontOfSize:15];
    [stopBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [stopBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    stopBtn.layer.masksToBounds = YES;
    stopBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:stopBtn];
    [stopBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap);
        make.size.mas_equalTo(btnSize);
    }];
    //mute/unmute
    UIButton *mutBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    [mutBtn addActionHandler:^(UIControl *control) {
        UIButton *btn = (UIButton *)control;
        btn.selected = !btn.selected;
        if (btn.selected) {
            [weakSelf.player muteRemoteAudio:YES];
            [btn setTitle:@"unmute" forState:UIControlStateNormal];
        }
        else {
            [weakSelf.player muteRemoteAudio:NO];
            [btn setTitle:@"mute" forState:UIControlStateNormal];
        }
    }];
    [mutBtn setTitle:@"mute" forState:UIControlStateNormal];
    mutBtn.titleLabel.font = [UIFont fontOfSize:15];
    [mutBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [mutBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    mutBtn.layer.masksToBounds = YES;
    mutBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:mutBtn];
    [mutBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(stopBtn.mas_right).offset(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap);
        make.size.mas_equalTo(btnSize);
    }];
    //pause/resume
    UIButton *talkBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    [talkBtn addActionHandler:^(UIControl *control) {
        UIButton *btn = (UIButton *)control;
        btn.selected = !btn.selected;
        if (btn.selected) {
            [weakSelf.player pause];
            [btn setTitle:@"resume" forState:UIControlStateNormal];
        }
        else {
            [weakSelf.player resume];
            [btn setTitle:@"pause" forState:UIControlStateNormal];
        }
    }];
    [talkBtn setTitle:@"pause" forState:UIControlStateNormal];
    talkBtn.titleLabel.font = [UIFont fontOfSize:15];
    [talkBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [talkBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    talkBtn.layer.masksToBounds = YES;
    talkBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:talkBtn];
    [talkBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(mutBtn.mas_right).offset(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap);
        make.size.mas_equalTo(btnSize);
    }];
    //record
    UIButton *recordBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    [recordBtn addActionHandler:^(UIControl *control) {
        UIButton *btn = (UIButton *)control;
        btn.selected = !btn.selected;
        if (btn.selected) {
            NSString *path = [NSHomeDirectory() stringByAppendingString:@"/Documents/"];
            path = [NSString stringWithFormat:@"%@_net_vod_vid_%d.mp4", path, (int)arc4random()];
            [weakSelf.player startFileRecording:path];
            [btn setTitle:@"record end" forState:UIControlStateNormal];
        }
        else {
            [weakSelf.player stopFileRecording];
            [btn setTitle:@"record start" forState:UIControlStateNormal];
        }
    }];
    [recordBtn setTitle:@"record start" forState:UIControlStateNormal];
    recordBtn.titleLabel.font = [UIFont fontOfSize:15];
    [recordBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [recordBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    recordBtn.layer.masksToBounds = YES;
    recordBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:recordBtn];
    [recordBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(talkBtn.mas_right).offset(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap);
        make.size.mas_equalTo(btnSize);
    }];
    //snapshot
    UIButton *snapshotBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    [snapshotBtn addActionHandler:^(UIControl *control) {
        NSString *path = [NSHomeDirectory() stringByAppendingString:@"/Documents/"];
        path = [NSString stringWithFormat:@"%@_net_vod_pic_%d.jpg", path, (int)arc4random()];
        [weakSelf.player snapshot:path];
    }];
    [snapshotBtn setTitle:@"snapshot" forState:UIControlStateNormal];
    snapshotBtn.titleLabel.font = [UIFont fontOfSize:15];
    [snapshotBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [snapshotBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    snapshotBtn.layer.masksToBounds = YES;
    snapshotBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:snapshotBtn];
    [snapshotBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap*2+btn_h);
        make.size.mas_equalTo(btnSize);
    }];
    //speed
    UIButton *speedBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    [speedBtn addActionHandler:^(UIControl *control) {
        UIButton *btn = (UIButton *)control;
        btn.selected = !btn.selected;
        if (++weakSelf.speedIdx == weakSelf.speedArr.count) {
            weakSelf.speedIdx = 0;
        }
        int speed = [weakSelf.speedArr[weakSelf.speedIdx] intValue];
        [weakSelf.player setPlaybackSpeed:speed];
        NSString *title = [NSString stringWithFormat:@"speed %dx", speed];
        [btn setTitle:title forState:UIControlStateNormal];
    }];
    [speedBtn setTitle:@"speed 1x" forState:UIControlStateNormal];
    speedBtn.titleLabel.font = [UIFont fontOfSize:15];
    [speedBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [speedBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    speedBtn.layer.masksToBounds = YES;
    speedBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:speedBtn];
    [speedBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(snapshotBtn.mas_right).offset(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap*2+btn_h);
        make.size.mas_equalTo(btnSize);
    }];

    //seek 到某一个时间点
    UIButton *seekBtn = [UIButton gradientViewWithSize:btnSize startColor:YJRGBHex(@"#FF8960") endColor:YJRGBHex(@"#FF62A5")];
    [seekBtn addActionHandler:^(UIControl *control) {
        UIButton *btn = (UIButton *)control;
        btn.selected = !btn.selected;
        NSString *time = @"2024-01-19 15:00:08";
        long seekTime = [[time dateFromStringWithFormatter:@"yyyy-MM-dd HH:mm:ss"] timeIntervalSince1970];
        [weakSelf.player seek:seekTime];
    }];
    [seekBtn setTitle:@"seek" forState:UIControlStateNormal];
    seekBtn.titleLabel.font = [UIFont fontOfSize:15];
    [seekBtn setTitleColor:YJRGBHex(@"#FFFFFF") forState:UIControlStateNormal];
    [seekBtn setTitleColor:YJRGBAHex(@"#FFFFFF", 0.6) forState:UIControlStateHighlighted];
    seekBtn.layer.masksToBounds = YES;
    seekBtn.layer.cornerRadius = btnSize.height/2;
    [pannel addSubview:seekBtn];
    [seekBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(speedBtn.mas_right).offset(btn_x_gap);
        make.top.mas_equalTo(btn_y_gap*2+btn_h);
        make.size.mas_equalTo(btnSize);
    }];

    //vod progress
    UILabel *pl = [[UILabel alloc] initWithFrame:CGRectZero];
    pl.backgroundColor = YJColorGreen;
    [self.view addSubview:pl];
    self.progressLabel = pl;
    [pl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.videoBaseView.mas_bottom);
//        make.left.right.mas_equalTo(self.view);
        make.left.mas_equalTo(self.view.mas_centerX);
        make.right.mas_equalTo(self.view);
        make.height.mas_equalTo(20);
    }];
}

#pragma mark - LoadingIndicator

- (UIActivityIndicatorView *)loadingIndicator {
    if (!_loadingIndicator) {
        UIActivityIndicatorViewStyle type = UIActivityIndicatorViewStyleWhiteLarge;
        if (@available(iOS 13.0, *)) {
            type = UIActivityIndicatorViewStyleLarge;
        }
        _loadingIndicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:type];
        _loadingIndicator.color = [UIColor greenColor];
        [self.videoBaseView addSubview:_loadingIndicator];
        [_loadingIndicator mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(self.videoBaseView);
        }];
    }
    return _loadingIndicator;
}

- (void)startLoading {
    WS(weakSelf);
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakSelf.loadingIndicator startAnimating];
    });
}

- (void)stopLoading {
    WS(weakSelf);
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakSelf.loadingIndicator stopAnimating];
    });
}

#pragma mark - RMPlayerDelegate

- (void)player:(id)player onBufferStateUpdate:(RMPlayerBufferState)state bufferDurationMillis:(NSInteger)bufferDurationMillis {
    NSLog(@"%s--%d", __FUNCTION__, __LINE__);
}

- (void)player:(id)player onError:(RMPlayerErrorType)type playErrorCode:(RMPlayerErrorCode)code playErrorDesc:(NSString *)desc {
    NSLog(@"%s--%d,, player=%@, type=%ld, code=%ld, desc=%@", __FUNCTION__, __LINE__, player, (long)type, (long)code, desc);

    NSString *tips = @"播放失败";
    NSString *message = [NSString stringWithFormat:@"type(%ld), code(%ld), %@", type, code, desc];
    UIAlertController *alertTips = [UIAlertController alertControllerWithTitle:tips message:message preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:alertTips animated:true completion:nil];
    WS(weakSelf);
    [alertTips addAction:[UIAlertAction actionWithTitle:@"重试" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        RMPNetLivePlayer *p = player;
        [p stop];
        [p start];
        [weakSelf startLoading];
    }]];
    [alertTips addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
}

- (void)player:(id)player onFileRecordingError:(NSString *)file recordErrorCode:(RMPlayerRecordingError)code recordErrorDesc:(NSString *)desc {
    NSLog(@"%s--%d,, player=%@, file=%@, code=%ld, desc=%@", __FUNCTION__, __LINE__, player, file, (long)code, desc);
    NSString *toast = [NSString stringWithFormat:@"code[%ld], %@", (long)code, desc];
    [YJToast showToast:toast];
}

- (void)player:(id)player onFileRecordingFinish:(NSString *)file {
    NSLog(@"%s--%d,, player=%@, file=%@", __FUNCTION__, __LINE__, player, file);
    NSString *toast = [NSString stringWithFormat:@"saved[%@]", file];
    [YJToast showToast:toast];
}

- (void)player:(id)player onFileRecordingStart:(NSString *)file {
    NSLog(@"%s--%d, , player=%@, file=%@", __FUNCTION__, __LINE__, player, file);
}

- (void)player:(id)player onFirstFrameRendered:(NSInteger)elapseMills {
    NSLog(@"%s--%d, player=%@, elapseMills=%ld", __FUNCTION__, __LINE__, player, elapseMills);
    [self stopLoading];
}

- (void)player:(id)player onPlaybackSpeedUpdate:(int)speed {
    NSLog(@"%s--%d", __FUNCTION__, __LINE__);
}

- (void)player:(id)player onPlayerStateChange:(RMPlayerState)state {
    NSLog(@"%s--%d", __FUNCTION__, __LINE__);
}

- (void)player:(id)player onSeekComplete:(BOOL)success {
    NSLog(@"%s--%d", __FUNCTION__, __LINE__);
}

- (void)player:(id)player onSnapshotResult:(NSString *)file snapErrorCode:(RMPlayerSnapshotResult)code snapErrorDesc:(NSString *)desc {
    NSLog(@"%s--%d, file=%@, code=%ld, desc=%@", __FUNCTION__, __LINE__, file, (long)code, desc);
}

- (void)player:(id)player onVideoSizeChanged:(CGSize)size {
    NSLog(@"%s--%d, player=%@, size=[%f x %f]", __FUNCTION__, __LINE__, player, size.width, size.height);
}

- (void)player:(id)player onVodPlayComplete:(BOOL)completed {
    NSLog(@"%s--%d, player=%@, completed=%d", __FUNCTION__, __LINE__, player, completed);
}

- (void)player:(id)player onVodPlayProgress:(NSInteger)millis {
    NSLog(@"%s--%d", __FUNCTION__, __LINE__);
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:millis/1000.0];
    self.progressLabel.text = [date stringWithFormatter:@"yyyy-MM-dd HH:mm:ss"];

}

- (void)player:(id)player onSeiData:(NSData *)data pts:(long)pts {
    NSLog(@"%s--%d, data=%@, pts=%ld", __FUNCTION__, __LINE__, data, pts);
}

@end
