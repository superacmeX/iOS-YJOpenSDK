//
//  LiveViewController.h
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2024/12/10.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LiveViewController : UIViewController

- (instancetype)initWithDeviceName:(NSString *)devName productKey:(NSString *)prodKey;

@end

NS_ASSUME_NONNULL_END
