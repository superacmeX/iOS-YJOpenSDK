//
//  RegisterView.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/25.
//

import UIKit

final class RegisterView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private(set) lazy var accountTextField = EntryBoxView()
    private(set) lazy var codeTextField = EntryBoxView()
    private(set) lazy var codeButton = UIButton()
    private(set) lazy var pwdTextField = EntryBoxView()
    private(set) lazy var registerButton = UIButton()
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        accountTextField.textField.resignFirstResponder()
        codeTextField.textField.resignFirstResponder()
        pwdTextField.textField.resignFirstResponder()
    }
}

extension RegisterView {
    func setup() {
        backgroundColor = .systemBackground
        accountTextField.textField.placeholder = "请输入账号"
        addSubview(accountTextField)
        accountTextField.snp.makeConstraints { make in
            make.left.right.equalTo(self).inset(24)
            make.height.equalTo(55)
            make.top.equalTo(safeAreaLayoutGuide.snp.top).inset(120)
        }
        
        codeTextField.textField.textContentType = .oneTimeCode
        codeTextField.textField.placeholder = "请输入验证码"
        codeTextField.textField.keyboardType = .numberPad
        addSubview(codeTextField)
        codeTextField.snp.makeConstraints { make in
            make.left.height.equalTo(accountTextField)
            make.right.equalTo(accountTextField).offset(-120)
            make.top.equalTo(accountTextField.snp.bottom).offset(30)
        }
        
        codeButton.setTitle("发送验证码", for: [])
        codeButton.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        codeButton.isEnabled = false
        addSubview(codeButton)
        codeButton.snp.makeConstraints { make in
            make.centerY.height.equalTo(codeTextField)
            make.right.equalTo(accountTextField)
            make.left.equalTo(codeTextField.snp.right).offset(2)
        }
        
        pwdTextField.textField.placeholder = "请输入密码"
        addSubview(pwdTextField)
        pwdTextField.snp.makeConstraints { make in
            make.size.centerX.equalTo(accountTextField)
            make.top.equalTo(codeTextField.snp.bottom).offset(30)
        }
        
        registerButton.setTitle("注册", for: [])
        registerButton.isEnabled = false
        addSubview(registerButton)
        registerButton.snp.makeConstraints { make in
            make.size.centerX.equalTo(accountTextField)
            make.top.equalTo(pwdTextField.snp.bottom).offset(50)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        codeButton.setBackgroundImage(UIImage(color: .theme, size: codeButton.bounds.size, cornerRadius: 12), for: .normal)
        codeButton.setBackgroundImage(UIImage(color: .gray, size: codeButton.bounds.size, cornerRadius: 12), for: .disabled)
        registerButton.setBackgroundImage(UIImage(color: .theme, size: registerButton.bounds.size, cornerRadius: 12), for: .normal)
        registerButton.setBackgroundImage(UIImage(color: .gray, size: registerButton.bounds.size, cornerRadius: 12), for: .disabled)
    }
}
