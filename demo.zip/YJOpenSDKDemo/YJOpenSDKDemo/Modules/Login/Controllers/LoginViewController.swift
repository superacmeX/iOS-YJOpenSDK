//
//  LoginViewController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import UIKit
import Combine
import CombineCocoa
import FJRouter
final class LoginViewController: UIViewController {
    private var loginView: LoginView {
        return view as! LoginView
    }
    private var viewModel: LoginViewModel!
    private var cancels: Set<AnyCancellable> = []
}

extension LoginViewController {
    override func loadView() {
        view = LoginView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        bind()
    }
}

private extension LoginViewController {
    func setup() {
        title = "登录"
        view.backgroundColor = .bgColor
        onlyDisplayBackBarItemImage()
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "注册", style: .plain, target: self, action: #selector(onTapRegister))
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(title: "注册", style: .plain, target: self, action: #selector(onTapRegister))
        ]
    }
    
    @IBAction func onTapRegister() {
        try? FJRouter.shared.goNamed("registerAccount")
    }
    
    func bind() {
        viewModel = LoginViewModel(account: loginView.accountTextField.textField.textPublisher, pwd: loginView.pwdTextField.textField.textPublisher)
        
        viewModel.loading.sink(receiveValue: { [weak self] loading in
            loading ? self?.view.showIndicator() : self?.view.hideIndicator()
        }).store(in: &cancels)
        
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.loginEnabled.sink(receiveValue: { [weak self] enabeld in
            self?.loginView.loginButton.isEnabled = enabeld
        }).store(in: &cancels)
        
        loginView.loginButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { [weak self] in
            self?.viewModel.prepareLogin()
        }).store(in: &cancels)
        
        viewModel.loginSuccess.sink(receiveValue: {
            try? FJRouter.shared.go(location: "/")
        }).store(in: &cancels)
    }
}
