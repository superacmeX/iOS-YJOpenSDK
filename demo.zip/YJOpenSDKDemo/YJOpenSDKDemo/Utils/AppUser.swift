//
//  AppUser.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import Foundation
import Combine
import FJRouter
import YJOpenSDK
final class AppUser {
    static let shared = AppUser()
    private var loginState = false
    private var cancels: Set<AnyCancellable> = []
    var hasLogin: Bool {
        loginState
    }
    
    private init() {
        NotificationCenter.default.publisher(for: .YJOpenAccountDidLogin).sink(receiveValue: { [weak self] _ in
            self?.loginState = true
            self?.goRootRoute()
        }).store(in: &cancels)
        
        NotificationCenter.default.publisher(for: .YJOpenAccountDidLogout).sink(receiveValue: { [weak self] _ in
            self?.loginState = false
            self?.goRootRoute()
        }).store(in: &cancels)
        
        NotificationCenter.default.publisher(for: .YJOpenAccountAuthorizationExpired).sink(receiveValue: { [weak self] _ in
            self?.loginState = false
            self?.goRootRoute()
        }).store(in: &cancels)
        
        NotificationCenter.default.publisher(for: .YJOpenAccountFinishedPrepare)
            .setFailureType(to: AppError.self)
            .timeout(.seconds(4), scheduler: OperationQueue.main, customError: {  AppError("自动登录超时") })
            .first()
            .sink(receiveCompletion: { comp in
                if case .failure = comp {
                    YJOpenSDKManager.default.accountService.logout()
                }
            }, receiveValue: { [weak self] _ in
                if YJOpenSDKManager.default.accountService.status == .logout {
                    self?.loginState = false
                    self?.goRootRoute()
                }
            }).store(in: &cancels)
    }
    
    private func goRootRoute() {
        _Concurrency.Task {
            await FJRouter.shared.go(location: "/")
        }
    }
    
    func enabled() {  }
}
