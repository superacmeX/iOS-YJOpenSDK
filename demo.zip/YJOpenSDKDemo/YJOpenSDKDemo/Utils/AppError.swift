//
//  AppError.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/25.
//

import Foundation
/// 通用错误类型
public struct AppError: Error {
    private let code: Int
    private let reason: String
    public init(_ reason: String, code: Int = -1) {
        self.reason = reason
        self.code = code
    }
}

extension AppError: CustomStringConvertible, CustomDebugStringConvertible {
   public var description: String {
        reason
    }
    
    public var debugDescription: String {
        description
    }
    
    public var localizedDescription: String {
        description
    }
    public var errorCode: Int {
        code
    }
}

extension AppError: LocalizedError {
    public var errorDescription: String? {
        description
    }
}
