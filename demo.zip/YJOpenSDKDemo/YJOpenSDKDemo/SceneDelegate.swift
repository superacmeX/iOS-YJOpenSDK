//
//  SceneDelegate.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import UIKit
import FJRouter
import YJOpenSDK
import IQKeyboardManagerSwift
import IQKeyboardToolbarManager
class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?
    private lazy var logger = AppLog()
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let ws = (scene as? UIWindowScene) else { return }
        window = UIWindow(windowScene: ws)
        window?.overrideUserInterfaceStyle = .light
        window?.backgroundColor = .white
        AppUser.shared.enabled()
        config()
        // 提示: 为什么这里不设置rootController, 观看`AppUser`内部逻辑
        window?.makeKeyAndVisible()
    }
}

private extension SceneDelegate {
    func config() {
        YJOpenSDKManager.default.countryCode = .CN
        YJOpenSDKManager.default.environment = .test
        YJOpenSDKManager.default.setup(YJVerifyInfo(appKey: "xxxxx", appSecret: "xxxxx")) { _ in
            
        }
        YJOpenSDKManager.default.logger = AppLog()
        IQKeyboardManager.shared.isEnabled = true
        IQKeyboardToolbarManager.shared.isEnabled = true
        _Concurrency.Task {
            try? await AppRouter.config()
        }
    }
}
