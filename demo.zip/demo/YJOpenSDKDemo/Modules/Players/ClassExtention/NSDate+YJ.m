//
//  NSDate+YJ.m
//  UITest
//
//  Created by leo.li on 16/7/26.
//  Copyright © 2016年 lujiongjian. All rights reserved.
//

#import "NSDate+YJ.h"

#define D_MINUTE	60
#define D_HOUR		3600
#define D_DAY		86400
#define D_WEEK		604800
#define D_YEAR		31556926

/**
 *  时间工具分类
 */
@implementation NSDate (YJ)

/**
 *  @brief 讲时间按照格式转化成字符串
 *
 *  @param formatter 格式
 *
 *  @return 字符串
 */
- (NSString *)stringWithFormatter:(NSString *)formatter {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:formatter];
    return [dateFormatter stringFromDate:self];
}

@end
