//
//  UIControl+YJ.h
//  UITest
//
//  Created by lujiongjian on 2020/5/21.
//  Copyright © 2020 lujiongjian. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/** 触摸事件响应 */
typedef void (^UIControlTouchedBlock)(UIControl *control);

@interface UIControl (YJ)

+ (UIControl *)gradientViewWithSize:(CGSize)size startColor:(UIColor *)startColor endColor:(UIColor *)endColor;

/**
 *  @brief 添加触摸事件，默认触摸方式：UIControlEventTouchUpInside
 *
 *  @param handler 事件响应
 */
- (void)addActionHandler:(UIControlTouchedBlock)handler;

@end

NS_ASSUME_NONNULL_END
