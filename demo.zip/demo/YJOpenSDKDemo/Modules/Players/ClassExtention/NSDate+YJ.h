//
//  NSDate+YJ.h
//  UITest
//
//  Created by leo.li on 16/7/26.
//  Copyright © 2016年 lujiongjian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (YJ)

- (NSString *)stringWithFormatter:(NSString *)formatter;

@end
