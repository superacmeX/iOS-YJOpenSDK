//
//  UIFont+YJ.h
//  UITest
//
//  Created by leo.li on 16/7/7.
//  Copyright © 2016年 lujiongjian. All rights reserved.
//

#import <UIKit/UIKit.h>

#define YJFont(x) [UIFont fontOfSize:(x)]
#define YJBoldFont(x) [UIFont boldFontOfSize:(x)]

#define YJTextFont YJFont(16)

/** 统一字体出口
 *
 */
@interface UIFont (YJ)

/**
*  @brief 根据字号创建字体(方便日后扩展，比如自定义字体)
*
*  @param size 字号 + 1
*
*  @return 字体
*/
+ (UIFont *)fontOfSizePlus:(CGFloat)size;

/**
*  @brief 根据字号创建粗体字体(方便日后扩展，比如自定义字体)
*
*  @param size 字号 + 1
*
*  @return 字体
*/
+ (UIFont *)boldFontOfSizePlus:(CGFloat)size;

/**
 *  @brief 根据字号创建字体(方便日后扩展，比如自定义字体)
 *
 *  @param size 字号
 *
 *  @return 字体
 */
+ (UIFont *)fontOfSize:(CGFloat)size;

/**
 *  @brief 根据字号创建粗体字体(方便日后扩展，比如自定义字体)
 *
 *  @param size 字号
 *
 *  @return 字体
 */
+ (UIFont *)boldFontOfSize:(CGFloat)size;

/**
 设置字体为斜体（中文）

 @param fontSize 字体大小
 @param angle 角度
 */
+ (UIFont *)italicSystemFontOfSize:(CGFloat)fontSize angle:(CGFloat)angle;

@end
