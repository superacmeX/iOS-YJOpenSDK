//
//  UIButton+YJ.m
//  UITest
//
//  Created by lujiongjian on 2020/5/21.
//  Copyright © 2020 lujiongjian. All rights reserved.
//

#import "UIButton+YJ.h"

@implementation UIButton (YJ)

+ (UIButton *)gradientViewWithSize:(CGSize)size startColor:(UIColor *)startColor endColor:(UIColor *)endColor {
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectZero];
    btn.backgroundColor = [UIColor clearColor];

    CAGradientLayer *gl = [CAGradientLayer layer];
    gl.frame = CGRectMake(0, 0, size.width, size.height);
    gl.startPoint = CGPointMake(0, 0);
    gl.endPoint = CGPointMake(1, 0);
    gl.colors = @[(__bridge id)startColor.CGColor,(__bridge id)endColor.CGColor];
    [btn.layer addSublayer:gl];

    return btn;
}

@end
