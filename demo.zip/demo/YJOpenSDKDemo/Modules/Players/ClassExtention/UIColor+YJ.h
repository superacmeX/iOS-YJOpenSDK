//
//  UIColor+YJ.h
//  UITest
//
//  Created by leo.li on 16/6/30.
//  Copyright © 2016年 lujiongjian. All rights reserved.
//

#import <UIKit/UIKit.h>

#define YJRGBHex(hexString) [UIColor colorWithHexString:hexString]
#define YJRGBAHex(hexString, alpha_) [UIColor colorWithHexString:(hexString) alpha:(alpha_)]

//TODO:BHZ:TEST:UGC：阿里颜色使用，后面更换，time T T
#define RGBToColor(R,G,B)  [UIColor colorWithRed:(R * 1.0) / 255.0 green:(G * 1.0) / 255.0 blue:(B * 1.0) / 255.0 alpha:1.0]
#define rgba(R,G,B,A)  [UIColor colorWithRed:(R * 1.0) / 255.0 green:(G * 1.0) / 255.0 blue:(B * 1.0) / 255.0 alpha:A]

#define YJColorBlack [[UIColor alloc] initWithWhite:0.0 alpha:1.0]
#define YJColorDarkGray [[UIColor alloc] initWithWhite:0.333 alpha:1.0]
#define YJColorLightGray [[UIColor alloc] initWithWhite:0.667 alpha:1.0]
#define YJColorWhite [[UIColor alloc] initWithWhite:1.0 alpha:1.0]
#define YJColorGray [[UIColor alloc] initWithWhite:0.5 alpha:1.0]
#define YJColorRed [[UIColor alloc] initWithRed:1.0 green:0.0 blue:0.0 alpha:1.0]
#define YJColorGreen [[UIColor alloc] initWithRed:0.0 green:1.0 blue:0.0 alpha:1.0]
#define YJColorBlue [[UIColor alloc] initWithRed:0.0 green:0.0 blue:1.0 alpha:1.0]
#define YJColorCyan [[UIColor alloc] initWithRed:0.0 green:1.0 blue:1.0 alpha:1.0]
#define YJColorYellow [[UIColor alloc] initWithRed:1.0 green:1.0 blue:0.0 alpha:1.0]
#define YJColorMagenta [[UIColor alloc] initWithRed:1.0 green:0.0 blue:1.0 alpha:1.0]
#define YJColorOrange [[UIColor alloc] initWithRed:1.0 green:0.5 blue:0.0 alpha:1.0]
#define YJColorPurple [[UIColor alloc] initWithRed:0.5 green:0.0 blue:0.5 alpha:1.0]
#define YJColorBrown [[UIColor alloc] initWithRed:0.6 green:0.4 blue:0.2 alpha:1.0]
#define YJColorClear [[UIColor alloc] initWithWhite:0.0 alpha:0.0]

/** 统一颜色出口
 *
 */
@interface UIColor (YJ)

/**
 *  @brief 将16进制颜色字符串转成UIColor对象
 *
 *  @param hexString4Color 6进制颜色字符串， 支持@“#123456”、 @“0X123456”、 @“123456”三种格式
 *
 *  @return 返回相应的UIColor对象
 */
+ (UIColor *)colorWithHexString:(NSString *)hexString4Color;

/**
 *  @brief 将16进制颜色字符串按照指定透明度转成UIColor对象
 *
 *  @param hexString4Color 16进制颜色字符串， 支持@“#123456”、 @“0X123456”、 @“123456”三种格式
 *  @param alpha           颜色的透明度
 *
 *  @return 返回相应的UIColor对象
 */
+ (UIColor *)colorWithHexString:(NSString *)hexString4Color alpha:(CGFloat)alpha;

/**
 *  @brief 判断两个颜色值是否相等
 *
 *  @param color 另外的颜色
 *
 *  @return YES：相等
 */
- (BOOL)isEqualWithColor:(UIColor *)color;

@end
