//
//  BaseDef.h
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2024/12/10.
//

#ifndef BaseDef_h
#define BaseDef_h

#import "Masonry.h"
#import "UIButton+YJ.h"
#import "UIColor+YJ.h"
#import "UIControl+YJ.h"
#import "UIFont+YJ.h"
#import "NSString+YJ.h"
#import "YJOpenSDKToast.h"
#import "NSObject+YJ.h"
#import "NSDate+YJ.h"

/** 防止循环引用 */
#define WS(weakSelf)                __weak __typeof(&*self) weakSelf = self;
#define SS(weakSelf)                __strong __typeof(weakSelf) strongSelf = weakSelf;

#define dispatch_main_sync_safe(block)\
if ([NSThread isMainThread]) {\
    block();\
} else {\
    dispatch_sync(dispatch_get_main_queue(), block);\
}

#define dispatch_main_async_safe(block)\
if ([NSThread isMainThread]) {\
    block();\
} else {\
    dispatch_async(dispatch_get_main_queue(), block);\
}

/** 设备屏幕大小 */
#define kMainScreenFrame [[UIScreen mainScreen] bounds]

/** 设备屏幕宽 */
#define kMainScreenWidth kMainScreenFrame.size.width

/** 设备屏幕高 */
#define kMainScreenHeight kMainScreenFrame.size.height

#define kEpsilon 0.02
#define k9x16ScreenRatio 0.56   //iPhone X 以前出的手机目前都是 9:16 的, 3:4 的手机太老旧不支持
#define k9x19ScreenRatio 0.46   //iPhone X 以后出的手机目前都是 9:19.5 的，按照苹果的习惯，后出的手机比例应该都是这个
#define kIsiPhoneX (fabs( ((kMainScreenWidth)/(kMainScreenHeight)) - k9x19ScreenRatio ) < kEpsilon )

#define IS_HAS_SAFE_AREA kIsiPhoneX
/** 导航栏高度 */
#define kNavigationBarHeight  (IS_HAS_SAFE_AREA?88.0f:64.0f)

#endif /* BaseDef_h */
