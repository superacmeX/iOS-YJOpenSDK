//
//  YJToast.h
//  UITest
//
//  Created by leo.li on 16/7/5.
//  Copyright © 2016年 lujiongjian. All rights reserved.
//

#import <UIKit/UIView.h>

/** 提示框
 *  仿安卓的Toast
 *  加载指示器
 */
@interface YJToast : NSObject

#pragma mark - Toast

/**
 *  @brief 在视根图上展示一个带文案的提示框，不卡界面交互
 *
 *  @param text 文案
 */
+ (void)showToast:(NSString *)text;

/**
 *  @brief 在视根图上展示一个带文案的提示框，不卡界面交互
 *
 *  @param text 文案
 *  @param delay 延迟多长时间后隐藏提示框
 */
+ (void)showToast:(NSString *)text hideAfterDelay:(NSTimeInterval)delay;

/**
 *  @brief 在指定view上展示一个带文案的提示框，不卡界面交互
 *
 *  @param text 文案
 *  @param view 指定的view
 */
+ (void)showToast:(NSString *)text inView:(UIView *)view;

/**
 *  @brief 在指定view上展示一个带文案的提示框，不卡界面交互
 *
 *  @param text 文案
 *  @param view 指定的view
 *  @param delay 延迟多长时间后隐藏提示框
 */
+ (void)showToast:(NSString *)text inView:(UIView *)view hideAfterDelay:(NSTimeInterval)delay;

/**
 *  @brief 在视根图上展示一个带文案的提示框，在文字消失前界面无法交互
 *
 *  @param text 文案
 */
+ (void)showToastWaiting:(NSString *)text;

#pragma mark - Progress

/**
 *  @brief 在根视图上添加加载指示器
 *
 *  @param text 文案
 */
+ (void)showProgress:(NSString *)text;

/**
 *  @brief 在指定view上添加家在指示器
 *
 *  @param text 文案
 *  @param view 指定的view
 */
+ (void)showProgress:(NSString *)text inView:(UIView *)view;

/**
 *  @brief 隐藏根视图的家在指示器
 */
+ (void)hideProgress;

/**
 *  @brief 隐藏指定view的加载指示器
 *
 *  @param view 指定view
 */
+ (void)hideProgressInView:(UIView *)view;

/**
 *  @brief 在指定view上添加家在指示器，不卡界面交互
 *
 *  @param text 文案
 *  @param view 指定的view
 */
+ (void)YJ_showProgress:(NSString *)text inView:(UIView *)view;

/**
 *  @brief 隐藏指定view的加载指示器
 *
 *  @param view 指定view
 */
+ (void)YJ_hideProgressInView:(UIView *)view;

/**
*  @brief 在视根图上展示一个带文案的提示框，用来显示debug信息
*
*  @param text 文案
*/
+ (void)showToast4Debug:(NSString *)text;

@end
