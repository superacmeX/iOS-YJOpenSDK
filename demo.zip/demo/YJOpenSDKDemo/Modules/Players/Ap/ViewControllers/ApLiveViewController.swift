//
//  ApLiveViewController.swift
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2025/3/1.
//

import UIKit
import YJOpenSDK

final class ApLiveViewController: UIViewController {
    private var kTag: String = ""
    private var player: YJRMPApLivePlayer?
    private var videoBaseView:      UIView? = nil
    private var playerVideoView:    YJRMPVideoView? = nil
    private var link:               YJRMPApLink? = nil

    init() {
        kTag = String(describing: type(of: self))
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        self.link?.disconnect(withResult: nil)
        self.link?.deInit()
        print("\(kTag).deinit")
    }

    private lazy var loadingIndicator: UIActivityIndicatorView = {
        var type: UIActivityIndicatorView.Style = .whiteLarge
        if #available(iOS 13.0, *) {
            type = .large
        }
        let indicator = UIActivityIndicatorView(style: type)
        indicator.color = UIColor.green
        self.videoBaseView?.addSubview(indicator)
        indicator.snp.makeConstraints { make in
            make.center.equalTo(self.videoBaseView!)
        }
        return indicator
    }()
}

extension ApLiveViewController {

    override func viewDidLoad() {
        setUpUI()
        setUpPlayer()
    }
}

// MARK: YJRMPlayerDelegate
extension ApLiveViewController: YJRMPlayerDelegate {

    func onBufferStateUpdate(player: Any?, state: YJRMPlayerBufferState, bufferDurationMillis: Int) {
        print("\(kTag).\(#function)--\(#line), state=\(state), bufferDurationMillis=\(bufferDurationMillis)")

        switch state {
        case .loading:
            startLoading()
        case .ready:
            stopLoading()
        default:
            break
        }
    }

    func onError(player: Any?, type: YJRMPlayerErrorType, code: YJRMPlayerErrorCode, description: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), type=\(type.rawValue), code=\(code.rawValue), desc=\(String(describing: description))")

        let tips = "播放失败"
        let message = "type(\(type.rawValue)), code(\(code.rawValue)), \(String(describing: description))"
        let alertTips = UIAlertController(title: tips, message: message, preferredStyle: .alert)
        self.present(alertTips, animated: true, completion: nil)

        // 获取弱引用 self
        weak var weakSelf = self
        alertTips.addAction(UIAlertAction(title: "重试", style: .default, handler: { action in
            self.link?.disconnect(withResult: nil)
            self.link?.connect(peerIP: "192.168.43.1", peerPort: 6684, withResult: nil)

            guard let p = player as? YJRMPApLivePlayer else { return }
            p.stop()
            p.start()
            weakSelf?.startLoading()
        }))
        alertTips.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
    }

    func onFileRecordingError(player: Any?, file: String?, code: YJRMPlayerRecordingError, description: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file)), code=\(code.rawValue), desc=\(String(describing: description))")
        let toast = "code[\(code)], \(String(describing: description))"
        YJOpenSDKToast.show(toast)
    }

    func onFileRecordingFinish(player: Any?, file: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file))")
        let toast = "saved[\(String(describing: file))]"
        YJOpenSDKToast.show(toast)
    }

    func onFileRecordingStart(player: Any?, file: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file))")
    }

    func onFirstFrameRendered(player: Any?, elapseMills: Int) {
        print("\(kTag).\(#function)--\(#line), elapseMills=\(elapseMills)")
        self.stopLoading()
    }

    func onPlayerStateChange(player: Any?, state: YJRMPlayerState) {
        print("\(kTag).\(#function)--\(#line), state=\(state.rawValue)")
    }

    func onSnapshotResult(player: Any?, file: String?, code: YJRMPlayerSnapshotResult, description: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), file=\(String(describing: file)), code=\(code.rawValue), desc=\(String(describing: description))")
        switch code {
        case .snapshotOk:
            let toast = "saved[\(String(describing: file))]"
            YJOpenSDKToast.show(toast)
        case .snapshotUnknown, .snapshotWriteFileError, .snapshotCompressError:
            let toast = "saved[\(String(describing: description))]"
            YJOpenSDKToast.show(toast)
        }
    }

    func onTalkStateChange(player: Any?, state: YJRMPlayerTalkState) {
        print("\(kTag).\(#function)--\(#line), talk_state=\(state.rawValue)")
    }

    func onVideoSizeChanged(player: Any?, size: CGSize) {
        print("\(kTag).\(#function)--\(#line), size=[\(size.width) x \(size.height)]")
    }
}

// MARK: YJRMPApLinkDelegate
extension ApLiveViewController: YJRMPApLinkDelegate {
    func onLinkStatusChanged(status: YJRMPAPLinkStatus) {
        print("\(kTag).\(#function)--\(#line), status=\(status.rawValue)")
    }

    func onLinkPropertyPost(payload: Data?) {
        print("\(kTag).\(#function)--\(#line), payload=\(String(describing: payload))")
    }

    func onLinkEventPost(eventId: Data?, payload: Data?) {
        print("\(kTag).\(#function)--\(#line), eventId=\(String(describing: eventId)), payload=\(String(describing: payload))")
    }

    func onMediaRecordResult(records: [YJRMPRecordItem]?, pageNo: Int32, pageTotal: Int32, queryId: UInt32) {
        print("\(kTag).\(#function)--\(#line), records=\(String(describing: records)), pageNo=\(pageNo), pageTotal=\(pageTotal), queryId=\(queryId)")
    }

    func onLinkLogFile(seq: Int32, totalSeq: Int32, payload: Data?) {
        print("\(kTag).\(#function)--\(#line), seq=\(seq), totalSeq=\(totalSeq), payload=\(String(describing: payload))")
    }
}

private extension ApLiveViewController {

    func setUpPlayer() {

        self.link = YJRMPApLink.sharedInstance
        self.link?.deInit()
        self.link?.initSDK(localIP: "0.0.0.0", mobileID: "uuid")
        self.link?.delegate = self
        self.link?.disconnect(withResult: nil)
        self.link?.connect(peerIP: "192.168.43.1", peerPort: 6684, withResult: { code in
            print("connect code=\(code)")
        })

        self.player = YJRMPApLivePlayer()
        self.player?.delegate = self
        self.playerVideoView = YJRMPVideoView(frame: CGRectZero)
        self.player?.setVideoView(self.playerVideoView)
        self.videoBaseView?.addSubview(self.playerVideoView!)
        self.playerVideoView?.snp.makeConstraints({ make in
            make.edges.equalTo(0);
        })
        self.playerVideoView?.backgroundColor = UIColor(white: 0.0, alpha: 1.0)
        self.player?.start()
        self.startLoading()
    }

    func setUpUI() {
        self.title = "热点直播"
        self.videoBaseView = UIView(frame: CGRectMake(0, DeviceHelper.navigationBarHeight + 20, DeviceHelper.mainScreenWidth, DeviceHelper.mainScreenWidth * 9 / 16))
        self.view.addSubview(self.videoBaseView!)

        //pannel
        let panel_w = DeviceHelper.mainScreenWidth
        let panel_h = DeviceHelper.mainScreenWidth * 9 / 32;
        //pannel
        let pannel = UIView.init(frame: CGRectZero)
        pannel.backgroundColor = UIColor(white: 0.667, alpha: 1.0)
        self.view.addSubview(pannel)
        pannel.snp.makeConstraints { make in
            make.bottom.equalTo(self.view).offset(-20)
            make.size.equalTo(CGSize(width: panel_w, height: panel_h))
        }

        // Button parameters
        let btn_x_gap: CGFloat = 10
        let btn_y_gap: CGFloat = 10
        let btn_w = (panel_w - btn_x_gap * 5) / 4
        let btn_h = (panel_h - btn_y_gap * 3) / 2
        let btnSize = CGSize(width: btn_w, height: btn_h)

        // Stop/Start Button
        let stopBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        stopBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                // 停止播放
                self?.player?.stop()
                btn.setTitle("start", for: .normal)
            } else {
                // 开始播放
                self?.player?.start()
                btn.setTitle("stop", for: .normal)
            }
        }
        initBtn(btn: stopBtn, title: "stop", size: btnSize)
        pannel.addSubview(stopBtn)
        stopBtn.snp.makeConstraints { make in
            make.left.equalTo(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        // Mute/Unmute Button
        let mutBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        mutBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                // 静音
                self?.player?.muteRemoteAudio(false)
                btn.setTitle("mute", for: .normal)
            } else {
                // 取消静音
                self?.player?.muteRemoteAudio(true)
                btn.setTitle("unmute", for: .normal)
            }
        }
        initBtn(btn: mutBtn, title: "unmute", size: btnSize)
        pannel.addSubview(mutBtn)
        mutBtn.snp.makeConstraints { make in
            make.left.equalTo(stopBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        // Talk Open/Close Button
        let talkBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        talkBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                // 开始交谈
                self?.player?.startTalk()
                btn.setTitle("talk close", for: .normal)
            } else {
                // 结束交谈
                self?.player?.stopTalk()
                btn.setTitle("talk open", for: .normal)
            }
        }
        initBtn(btn: talkBtn, title: "talk open", size: btnSize)
        pannel.addSubview(talkBtn)
        talkBtn.snp.makeConstraints { make in
            make.left.equalTo(mutBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        // Record Button
        let recordBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        recordBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                // 开始录制
                let path = "\(NSHomeDirectory())/Documents/_net_live_vid_\(Int.random(in: 0...9999)).mp4"
                self?.player?.startFileRecording(path)
                btn.setTitle("record end", for: .normal)
            } else {
                self?.player?.stopFileRecording()
                // 停止录制
                btn.setTitle("record start", for: .normal)
            }
        }
        initBtn(btn: recordBtn, title: "record start", size: btnSize)
        pannel.addSubview(recordBtn)
        recordBtn.snp.makeConstraints { make in
            make.left.equalTo(talkBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        // Snapshot Button
        let snapshotBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        snapshotBtn.addActionHandler { [weak self] control in
            let path = "\(NSHomeDirectory())/Documents/_net_live_pic_\(Int.random(in: 0...9999)).jpg"
            self?.player?.snapshot(path)
        }
        initBtn(btn: snapshotBtn, title: "snapshot", size: btnSize)
        pannel.addSubview(snapshotBtn)
        snapshotBtn.snp.makeConstraints { make in
            make.left.equalTo(btn_x_gap)
            make.top.equalTo(btn_y_gap * 2 + btn_h)
            make.size.equalTo(btnSize)
        }

        // get logfile Button
        let getLogBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        getLogBtn.addActionHandler { [weak self] control in
            let serviceId = "GetLogFile"
            let response = self?.link?.postService(serviceId: serviceId, payload: nil)
            print("\(self?.kTag).\(#function)--\(#line), \(String(describing: response?.response)) \(String(describing: response?.code))")
        }
        initBtn(btn: getLogBtn, title: "get log", size: btnSize)
        pannel.addSubview(getLogBtn)
        getLogBtn.snp.makeConstraints { make in
            make.left.equalTo(snapshotBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap * 2 + btn_h)
            make.size.equalTo(btnSize)
        }

        //link conn/disconn
        // get logfile Button
        let linkBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        linkBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                self?.link?.disconnect(withResult: {
                    print("\(self?.kTag).\(#function)--\(#line), link disconnect done")
                })
                btn.setTitle("link conn", for: .normal)
            } else {
                self?.link?.connect(peerIP: "192.168.43.1", peerPort: 6684, withResult: { code in
                    print("\(self?.kTag).\(#function)--\(#line), link conn done, code[\(code)]")
                })
                btn.setTitle("link discon", for: .normal)
            }
        }
        initBtn(btn: linkBtn, title: "link discon", size: btnSize)
        pannel.addSubview(linkBtn)
        linkBtn.snp.makeConstraints { make in
            make.left.equalTo(getLogBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap * 2 + btn_h)
            make.size.equalTo(btnSize)
        }
    }

    func initBtn(btn: UIButton, title: String, size: CGSize) {
        btn.setTitle(title, for: .normal)
        btn.titleLabel?.font = UIFont(ofSize: 15)
        btn.setTitleColor(UIColor(hexString: "#FFFFFF"), for: .normal)
        btn.setTitleColor(UIColor(hexString: "#FFFFFF", alpha: 0.6), for: .highlighted)
        btn.layer.masksToBounds = true
        btn.layer.cornerRadius = size.height / 2
    }

    // MARK: - LoadingIndicator
    func startLoading() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.loadingIndicator.startAnimating()
        }
    }

    func stopLoading() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.loadingIndicator.stopAnimating()
        }
    }
}
