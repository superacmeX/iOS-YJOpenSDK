//
//  BindDevicebyWifiViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/28.
//

import Foundation
import Combine
import YJOpenSDK
final class BindDevicebyWifiViewModel {
    private(set) lazy var loading = PassthroughSubject<Bool, Never>()
    private(set) lazy var tips = PassthroughSubject<String, Never>()
    private(set) lazy var bindEnabled = PassthroughSubject<(Bool), Never>()
    private(set) lazy var binging = PassthroughSubject<Bool, Never>()
    private(set) lazy var bindSuccess = PassthroughSubject<String, Never>()
    private var cancels: Set<AnyCancellable> = []
    private var wifi = ""
    private var pwd = ""
    private let productKey: String
    private let deviceName: String
    init(
        productKey: String,
        deviceName: String,
        wifi: AnyPublisher<String?, Never>,
        pwd: AnyPublisher<String?, Never>
    ) {
        self.productKey = productKey
        self.deviceName = deviceName
        wifi.sink(receiveValue: { [weak self] w in
            self?.wifi = w ?? ""
        }).store(in: &cancels)
        
        pwd.sink(receiveValue: { [weak self] p in
            self?.pwd = p ?? ""
        }).store(in: &cancels)
        
        loading.combineLatest(wifi, pwd).flatMap({ loading, w, p in
            if loading {
                return Just(false)
            }
            let enabled = ((w ?? "").count >= 3) && ((p ?? "").count >= 0)
            return Just(enabled)
        }).sink(receiveValue: { [weak self] v in
            self?.bindEnabled.send(v)
        }).store(in: &cancels)
        
        loading.send(false)
    }
    
    deinit {
        YJBindDeviceBySoftAP.clearup()
    }
}

extension BindDevicebyWifiViewModel {
    func prepareBind() {
        YJBindDeviceBySoftAP.configBindDevice(productKey: productKey, deviceName: deviceName)
        loading.send(true)
        binging.send(true)
        YJBindDeviceBySoftAP.bindDevice(wifiSSID: wifi, wifiPW: pwd) { step in
            
        } result: { [weak self] failStep, result, error in
            self?.loading.send(false)
            if let error {
                self?.binging.send(false)
                self?.tips.send("绑定失败: \(error.localizedDescription)")
                return
            }
            guard let result, let did = result["deviceId"] else {
                self?.tips.send("绑定失败")
                self?.binging.send(false)
                return
            }
            self?.tips.send("绑定成功")
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: {
                self?.binging.send(false)
                self?.bindSuccess.send(did)
            })
        }
    }
    
    func stopBind() {
        YJBindDeviceBySoftAP.stopBindDevice()
        YJBindDeviceBySoftAP.clearup()
    }
}
