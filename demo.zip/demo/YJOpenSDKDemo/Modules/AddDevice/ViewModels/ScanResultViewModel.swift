//
//  ScanResultViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/25.
//

import Foundation
import YJOpenSDK
import Combine
final class ScanResultViewModel {
    private(set) lazy var loading = PassthroughSubject<Bool, Never>()
    private(set) lazy var tips = PassthroughSubject<String, Never>()
    private(set) lazy var info = CurrentValueSubject<YJPrepareDeviceInfo?, Never>(nil)
    private var cancels: Set<AnyCancellable> = []
    let dn: String
    let pk: String
    init(qr: String) {
        let result = DeviceQRUtil.analyzeQR(qr)
        pk = result?.pk ?? ""
        dn = result?.dn ?? ""
    }
}

extension ScanResultViewModel {
    func loadInfo() {
        DispatchQueue.main.async {
            self.loading.send(true)
        }
        let dname = dn
        var isFirstRequest = true
        let request = Deferred(createPublisher: {
            return Just(()).setFailureType(to: AppError.self)
                .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global()).flatMap {
                    isFirstRequest = false
                    return Future<YJPrepareDeviceInfo, AppError>({ promise in
                        let bind = YJBindDevice()
                        bind.getPrepareDeviceInfo(deviceName: dname) { info, error in
                            if let error {
                                promise(.failure(AppError(error.localizedDescription, code: error.code)))
                                return
                            }
                            guard let info else {
                                promise(.failure(AppError("获取设备信息失败")))
                                return
                            }
                            promise(.success(info))
                        }
                    })
                }
        }).retry(2)
        
        request.receive(on: RunLoop.main).sink(receiveCompletion: { [weak self] comp in
            self?.loading.send(false)
            if case .failure(let failure) = comp {
                self?.tips.send(failure.description)
            }
        }, receiveValue: { [weak self] value in
            self?.info.send(value)
        }).store(in: &cancels)
    }
}
