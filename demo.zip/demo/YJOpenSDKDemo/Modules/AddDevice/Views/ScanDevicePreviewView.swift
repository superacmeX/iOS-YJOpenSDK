//
//  ScanDevicePreviewView.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/25.
//

import UIKit
import AVFoundation
final class ScanDevicePreviewView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }
    
    // 四周背景layer
    private let maskLayer = CAShapeLayer()
      
    private let regionOfInterestOutline = CAShapeLayer()
      
    private let topLeftControl = CAShapeLayer()
      
    private let topRightControl = CAShapeLayer()
      
    private let bottomLeftControl = CAShapeLayer()
      
    private let bottomRightControl = CAShapeLayer()

    private(set) var regionOfInterest = CGRect.null
    
    private lazy var promptLabel = UILabel()
}


extension ScanDevicePreviewView {
    var videoPreviewLayer: AVCaptureVideoPreviewLayer {
        guard let layer = layer as? AVCaptureVideoPreviewLayer else {
            fatalError("Expected `AVCaptureVideoPreviewLayer` type for layer. Check ScanPreviewView.layerClass implementation.")
        }
        return layer
    }
    
    var session: AVCaptureSession? {
        get {
            return videoPreviewLayer.session
        }
        set {
            videoPreviewLayer.session = newValue
        }
    }
    
    override class var layerClass: AnyClass {
        return AVCaptureVideoPreviewLayer.self
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        let path = UIBezierPath(rect: CGRect(x: 0, y: 0, width: frame.size.width, height: frame.size.height))
        path.append(UIBezierPath(rect: regionOfInterest))
        path.usesEvenOddFillRule = true
        maskLayer.path = path.cgPath
        
        regionOfInterestOutline.path = CGPath(rect: regionOfInterest, transform: nil)
        
        if regionOfInterest != CGRect.null {
            let line: CGFloat = 30
            
            let tlp = UIBezierPath()
            tlp.move(to: CGPoint(x: regionOfInterest.origin.x, y: regionOfInterest.origin.y + line))
            tlp.addLine(to: regionOfInterest.origin)
            tlp.addLine(to: CGPoint(x: regionOfInterest.origin.x + line, y: regionOfInterest.origin.y))
            topLeftControl.path = tlp.cgPath
            
            let trp = UIBezierPath()
            trp.move(to: CGPoint(x: regionOfInterest.maxX - line, y: regionOfInterest.origin.y))
            trp.addLine(to: CGPoint(x: regionOfInterest.maxX, y: regionOfInterest.origin.y))
            trp.addLine(to: CGPoint(x: regionOfInterest.maxX, y: regionOfInterest.origin.y + line))
            topRightControl.path = trp.cgPath
            
            let blp = UIBezierPath()
            blp.move(to: CGPoint(x: regionOfInterest.minX, y: regionOfInterest.maxY - line))
            blp.addLine(to: CGPoint(x: regionOfInterest.minX, y: regionOfInterest.maxY))
            blp.addLine(to: CGPoint(x: regionOfInterest.minX + line, y: regionOfInterest.maxY))
            bottomLeftControl.path = blp.cgPath
            
            let brp = UIBezierPath()
            brp.move(to: CGPoint(x: regionOfInterest.maxX - line, y: regionOfInterest.maxY))
            brp.addLine(to: CGPoint(x: regionOfInterest.maxX, y: regionOfInterest.maxY))
            brp.addLine(to: CGPoint(x: regionOfInterest.maxX, y: regionOfInterest.maxY - line))
            bottomRightControl.path = brp.cgPath
        }
        
        CATransaction.commit()
        
        promptLabel.jj.centerX = bounds.width * 0.5
        promptLabel.jj.top = regionOfInterest.maxY + 40
    }
}

extension ScanDevicePreviewView {
    private func commonInit() {
        backgroundColor = .black
        maskLayer.fillRule = .evenOdd
        maskLayer.fillColor = UIColor.black.cgColor
        maskLayer.opacity = 0.6
        layer.addSublayer(maskLayer)
        
        regionOfInterestOutline.path = UIBezierPath(rect: regionOfInterest).cgPath
        regionOfInterestOutline.fillColor = UIColor.clear.cgColor
        regionOfInterestOutline.strokeColor = UIColor.white.cgColor
        layer.addSublayer(regionOfInterestOutline)
        
        addBoxLine(topLeftControl)
        addBoxLine(topRightControl)
        addBoxLine(bottomLeftControl)
        addBoxLine(bottomRightControl)
        
        promptLabel.text = "将二维码放入扫描框中"
        promptLabel.textColor = .white
        promptLabel.font = UIFont.systemFont(ofSize: 18)
        promptLabel.sizeToFit()
        addSubview(promptLabel)
    }
    
    private func addBoxLine(_ line: CAShapeLayer) {
        line.lineWidth = 3
        line.fillColor = UIColor.clear.cgColor
        line.strokeColor = UIColor(hexString: "#5E72EB")?.cgColor
        layer.insertSublayer(line, above: regionOfInterestOutline)
    }
    
    func setRegionOfInterestWithProposedRegionOfInterest(_ proposedRegionOfInterest: CGRect) {
        let videoPreviewRect = videoPreviewLayer.layerRectConverted(fromMetadataOutputRect: CGRect(x: 0, y: 0, width: 1, height: 1)).standardized
        let visibleVideoPreviewRect = videoPreviewRect.intersection(frame)
        var newRegionOfInterest = proposedRegionOfInterest.standardized
        var xOffset: CGFloat = 0
        var yOffset: CGFloat = 0

        if !visibleVideoPreviewRect.contains(newRegionOfInterest.origin) {
            xOffset = max(visibleVideoPreviewRect.minX - newRegionOfInterest.minX, CGFloat(0))
            yOffset = max(visibleVideoPreviewRect.minY - newRegionOfInterest.minY, CGFloat(0))
        }

        if !visibleVideoPreviewRect.contains(CGPoint(x: visibleVideoPreviewRect.maxX, y: visibleVideoPreviewRect.maxY)) {
            xOffset = min(visibleVideoPreviewRect.maxX - newRegionOfInterest.maxX, xOffset)
            yOffset = min(visibleVideoPreviewRect.maxY - newRegionOfInterest.maxY, yOffset)
        }

        newRegionOfInterest = newRegionOfInterest.offsetBy(dx: xOffset, dy: yOffset)
        regionOfInterest = newRegionOfInterest
        setNeedsLayout()
    }
}
