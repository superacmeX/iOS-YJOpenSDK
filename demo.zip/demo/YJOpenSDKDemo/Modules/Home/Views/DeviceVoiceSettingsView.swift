//
//  DeviceVoiceSettingsView.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/5.
//

import UIKit

final class DeviceVoiceSettingsView: UIView {
    var currentVolume = 50 {
        didSet {
            currentVolumeLabel.text = "当前音量 \(currentVolume)"
            slider.value = Float(currentVolume)
        }
    }
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private lazy var currentVolumeLabel = UILabel()
    private(set) lazy var slider = UISlider()
}

extension DeviceVoiceSettingsView {
    private func setup() {
        backgroundColor = .bgColor
        let boxView = UIView()
        boxView.layer.cornerRadius = 8
        boxView.clipsToBounds = true
        boxView.backgroundColor = .white
        boxView.layer.shadowColor = UIColor.gray.cgColor
        boxView.layer.shadowOpacity = 0.3
        boxView.layer.shadowOffset = CGSize(width: 2, height: 2)
        addSubview(boxView)
        boxView.snp.makeConstraints { make in
            make.left.right.equalTo(self).inset(18)
            make.top.equalTo(safeAreaLayoutGuide.snp.top).offset(12)
            make.height.greaterThanOrEqualTo(60)
        }
        
        let titleLabel = UILabel()
        titleLabel.text = "通话音量设置"
        titleLabel.font = UIFont.systemFont(ofSize: 18)
        titleLabel.textColor = .black
        boxView.addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.left.top.equalTo(boxView).inset(12)
        }
        
        currentVolumeLabel.textAlignment = .right
        currentVolumeLabel.text = "当前音量 50"
        currentVolumeLabel.font = UIFont.systemFont(ofSize: 16)
        currentVolumeLabel.textColor = .red
        boxView.addSubview(currentVolumeLabel)
        currentVolumeLabel.snp.makeConstraints { make in
            make.right.equalTo(boxView).inset(12)
            make.centerY.equalTo(titleLabel)
        }
        
        let descLabel = UILabel()
        descLabel.text = "音量越大, 对方听到的声音越大"
        descLabel.numberOfLines = 0
        descLabel.font = UIFont.systemFont(ofSize: 13)
        descLabel.textColor = .gray
        boxView.addSubview(descLabel)
        descLabel.snp.makeConstraints { make in
            make.left.equalTo(titleLabel)
            make.right.lessThanOrEqualTo(boxView).offset(-12)
            make.top.equalTo(titleLabel.snp.bottom).offset(4)
        }
        
        let minLabel = UILabel()
        minLabel.text = "0"
        minLabel.font = UIFont.systemFont(ofSize: 11)
        minLabel.textColor = .gray
        boxView.addSubview(minLabel)
        minLabel.snp.makeConstraints { make in
            make.bottom.equalTo(boxView).inset(16)
            make.left.equalTo(titleLabel)
        }
        
        let maxLabel = UILabel()
        maxLabel.text = "100"
        maxLabel.font = UIFont.systemFont(ofSize: 11)
        maxLabel.textColor = .gray
        boxView.addSubview(maxLabel)
        maxLabel.snp.makeConstraints { make in
            make.bottom.equalTo(minLabel)
            make.right.equalTo(currentVolumeLabel)
        }
        
        slider.isContinuous = false
        slider.minimumValue = 0
        slider.maximumValue = 100
        slider.value = 50
        boxView.addSubview(slider)
        slider.snp.makeConstraints { make in
            make.left.equalTo(minLabel)
            make.right.equalTo(maxLabel)
            make.bottom.equalTo(minLabel.snp.top).offset(-30)
            make.top.equalTo(descLabel.snp.bottom).offset(40)
        }
    }
}
