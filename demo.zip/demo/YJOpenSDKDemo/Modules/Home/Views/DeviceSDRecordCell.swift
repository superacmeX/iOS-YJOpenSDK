//
//  DeviceSDRecordCell.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/10.
//

import UIKit

final class DeviceSDRecordCell: UICollectionViewCell {
    var beginDate = "" {
        didSet {
            beginLabel.text = "开始时间: \(beginDate)"
        }
    }
    
    var endDate = "" {
        didSet {
            endLabel.text = "结束时间: \(endDate)"
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    private lazy var beginLabel = UILabel()
    private lazy var endLabel = UILabel()
}

private extension DeviceSDRecordCell {
    func setup() {
        let boxView = UIView()
        boxView.backgroundColor = .white
        boxView.layer.cornerRadius = 12
        boxView.layer.shadowColor = UIColor.gray.cgColor
        boxView.layer.shadowOpacity = 0.3
        boxView.layer.shadowOffset = CGSize(width: 2, height: 2)
        contentView.addSubview(boxView)
        boxView.snp.makeConstraints { make in
            make.edges.equalTo(contentView).inset(2)
        }

        beginLabel.textColor = .theme
        beginLabel.font = .systemFont(ofSize: 16)
        beginLabel.numberOfLines = 3
        boxView.addSubview(beginLabel)
        beginLabel.snp.makeConstraints { make in
            make.left.top.right.equalTo(boxView).inset(12)
        }
        
        endLabel.textColor = .gray
        endLabel.font = .systemFont(ofSize: 16)
        endLabel.numberOfLines = 0
        boxView.addSubview(endLabel)
        endLabel.snp.makeConstraints { make in
            make.left.right.equalTo(beginLabel)
            make.bottom.equalTo(boxView).offset(-12)
        }
    }
}

