//
//  DeviceDayCloudRecordsViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/9.
//

import Foundation
import Combine
import YJOpenSDK
import Gzip
final class DeviceDayCloudRecordsViewModel {
    private(set) lazy var records = CurrentValueSubject<[DeviceCloudRecord], Never>([])
    private(set) lazy var tips = PassthroughSubject<String, Never>()
    private(set) lazy var endRefresh = PassthroughSubject<Void, Never>()
    private(set) var device: DeviceInfo?
    private let deviceId: String
    private lazy var request = PassthroughSubject<Void, Never>()
    private lazy var cancels: Set<AnyCancellable> = []
    let date: Date
    private let dateFormatter: DateFormatter
    init(deviceId: String, date: Date) {
        self.deviceId = deviceId
        self.date = date
        dateFormatter = DateFormatter()
        dateFormatter.locale = Locale.init(identifier: "zh_Hans_CN")
        dateFormatter.calendar = Calendar.init(identifier: .iso8601)
        dateFormatter.timeZone = TimeZone.autoupdatingCurrent
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        request.map({ [weak self] _ -> AnyPublisher<[DeviceCloudRecord], Never> in
            if let self {
                return self.dealLoadRecords().eraseToAnyPublisher()
            }
            return Just([]).eraseToAnyPublisher()
        }).switchToLatest()
        .sink(receiveValue: { [weak self] objs in
            self?.records.send(objs)
            self?.endRefresh.send(())
        }).store(in: &cancels)
    }
}

extension DeviceDayCloudRecordsViewModel {
    func updateDeviceInfo(_ device: DeviceInfo?) {
        self.device = device
    }
    
    func loadRecords() {
        request.send(())
    }
    
    private func dealLoadRecords() -> AnyPublisher<[DeviceCloudRecord], Never> {
        let params: [String: Any] = ["deviceId": deviceId, "eventDay": dateFormatter.string(from: date)]
        var isFirstRequest = true
        return Just(()).setFailureType(to: AppError.self)
        .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global())
        .flatMap({ _ in
            isFirstRequest = false
            return Deferred {
                return Future<String, AppError> { promise in
                    YJApiClient.request(apiPath: "/message/api/v1/event/alarm/video/file", param: params) { code, msg, data in
                        guard let data = data as? [AnyHashable: Any],
                              let encodedContent = data["encodedContent"] as? String else {
                            promise(.failure(AppError("数据解析失败")))
                            return
                        }
                        DispatchQueue.global().async {
                            promise(.success(encodedContent))
                        }
                    } fail: { error in
                        promise(.failure(AppError(error.localizedDescription)))
                    }
                }
            }
        })
        .retry(2)
        .compactMap({ content -> Data? in
            if let base64EncodedData = content.data(using: .utf8), let compressedData = Data(base64Encoded: base64EncodedData) {
                return try? compressedData.gunzipped()
            }
            return nil
        })
        .decode(type: [DeviceCloudRecord].self, decoder: JSONDecoder())
        .receive(on: RunLoop.main)
        .catch({ [weak self] error -> Just<[DeviceCloudRecord]> in
            self?.tips.send(error.localizedDescription)
            return Just([])
        })
        .eraseToAnyPublisher()
    }
}
