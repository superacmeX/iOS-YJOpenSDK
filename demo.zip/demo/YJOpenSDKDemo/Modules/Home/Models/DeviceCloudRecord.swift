//
//  DeviceCloudRecord.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/10.
//

import Foundation

struct DeviceCloudRecord {
    let alarmName: String
    let alarmType: Int
    let eventId: String
    let eventTime: String
    let picUrl: String
    let videoUrl: String
    let videoExt: VideoExt
}

extension DeviceCloudRecord {
    fileprivate struct Payload: Decodable {
        let Video: Video
    }
    fileprivate struct Video: Decodable {
        let Url: String
        let ext: VideoExt
        
        enum CodingKeys: CodingKey {
            case Url
            case Ext
        }
        
        init(from decoder: any Decoder) throws {
            let container: KeyedDecodingContainer<DeviceCloudRecord.Video.CodingKeys> = try decoder.container(keyedBy: DeviceCloudRecord.Video.CodingKeys.self)
            self.Url = try container.decode(String.self, forKey: DeviceCloudRecord.Video.CodingKeys.Url)
            let ext = try container.decode(String.self, forKey: .Ext)
            let edata = ext.data(using: .utf8)!
            var extInfo = try JSONDecoder().decode(VideoExt.self, from: edata)
            extInfo.update(metaString: ext)
            self.ext = extInfo
        }
    }
    
    struct VideoExt: Decodable {
        let first_gop_time: Int
        let has_preroll: Int
        let duration: Int
        let upload_ms: Int
        let vcodec: Int
        let acodec: Int
        let type: Int
        let success_duration: Int
        
        private(set) var metaString = ""
        var meta: [String: Any] {
            return [
                "first_gop_time": first_gop_time,
                "has_preroll": has_preroll,
                "duration": duration,
                "upload_ms": upload_ms,
                "vcodec": vcodec,
                "acodec": acodec,
                "type": type,
                "success_duration": success_duration,
            ]
        }
        
        mutating fileprivate func update(metaString: String) {
            self.metaString = metaString
        }
        
        enum CodingKeys: CodingKey {
            case first_gop_time
            case has_preroll
            case duration
            case upload_ms
            case vcodec
            case acodec
            case type
            case success_duration
        }
        
        init(from decoder: any Decoder) throws {
            let container: KeyedDecodingContainer<DeviceCloudRecord.VideoExt.CodingKeys> = try decoder.container(keyedBy: DeviceCloudRecord.VideoExt.CodingKeys.self)
            self.first_gop_time = try container.decode(Int.self, forKey: DeviceCloudRecord.VideoExt.CodingKeys.first_gop_time)
            self.has_preroll = try container.decode(Int.self, forKey: DeviceCloudRecord.VideoExt.CodingKeys.has_preroll)
            self.duration = try container.decode(Int.self, forKey: DeviceCloudRecord.VideoExt.CodingKeys.duration)
            self.upload_ms = try container.decode(Int.self, forKey: DeviceCloudRecord.VideoExt.CodingKeys.upload_ms)
            self.vcodec = try container.decode(Int.self, forKey: DeviceCloudRecord.VideoExt.CodingKeys.vcodec)
            self.acodec = try container.decode(Int.self, forKey: DeviceCloudRecord.VideoExt.CodingKeys.acodec)
            self.type = try container.decode(Int.self, forKey: DeviceCloudRecord.VideoExt.CodingKeys.type)
            self.success_duration = try container.decode(Int.self, forKey: DeviceCloudRecord.VideoExt.CodingKeys.success_duration)
            self.metaString = ""
        }
    }
}

extension DeviceCloudRecord: Decodable {
    fileprivate enum CodingKeys: String, CodingKey {
        case alarmName
        case alarmType
        case eventId
        case eventTime
        case picUrl
        case videoUrl
        case payload
    }
    
    init(from decoder: any Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.alarmName = try container.decode(String.self, forKey: .alarmName)
        self.alarmType = try container.decode(Int.self, forKey: .alarmType)
        self.eventId = try container.decode(String.self, forKey: .eventId)
        self.eventTime = try container.decode(String.self, forKey: .eventTime)
        self.picUrl = try container.decode(String.self, forKey: .picUrl)
        self.videoUrl = try container.decode(String.self, forKey: .videoUrl)
        let payload = try container.decode(String.self, forKey: .payload)
        let pdata = payload.data(using: .utf8)!
        let payloadInfo = try JSONDecoder().decode(Payload.self, from: pdata)
        self.videoExt = payloadInfo.Video.ext
    }
}

extension DeviceCloudRecord: Hashable {
    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.alarmName == rhs.alarmName
        && lhs.alarmType == rhs.alarmType
        && lhs.eventId == rhs.eventId
        && lhs.eventTime == rhs.eventTime
        && lhs.videoExt == rhs.videoExt
        && lhs.picUrl == rhs.picUrl
        && lhs.videoUrl == rhs.videoUrl
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(alarmName)
        hasher.combine(alarmType)
        hasher.combine(eventId)
        hasher.combine(eventTime)
        hasher.combine(videoExt)
        hasher.combine(picUrl)
        hasher.combine(videoUrl)
    }
}

extension DeviceCloudRecord.VideoExt: Hashable {
    static func == (lhs: Self, rhs: Self) -> Bool {
        return lhs.first_gop_time == rhs.first_gop_time
        && lhs.has_preroll == rhs.has_preroll
        && lhs.duration == rhs.duration
        && lhs.upload_ms == rhs.upload_ms
        && lhs.vcodec == rhs.vcodec
        && lhs.acodec == rhs.acodec
        && lhs.type == rhs.type
        && lhs.success_duration == rhs.success_duration
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(first_gop_time)
        hasher.combine(has_preroll)
        hasher.combine(duration)
        hasher.combine(upload_ms)
        hasher.combine(vcodec)
        hasher.combine(acodec)
        hasher.combine(type)
        hasher.combine(success_duration)
    }
}
