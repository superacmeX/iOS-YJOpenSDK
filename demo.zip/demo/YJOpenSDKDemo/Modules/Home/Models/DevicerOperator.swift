//
//  DevicerOperator.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/4.
//

import Foundation
import Combine
import YJOpenSDK
/// 设备操作
struct DevicerOperator {
    let id: String
    
    init(id: String) {
        self.id = id
    }
}

extension DevicerOperator {
    /// 获取设备的物模型属性
    /// - Parameter key: 对应的物模型key
    /// - Returns: 结果
    func getProperties(key: String) -> AnyPublisher<Any, AppError> {
        var isFirstRequest = true
        let params: [String: Any] = ["deviceId": id, "identifiers": [key]]
        return Just(()).setFailureType(to: AppError.self)
            .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global())
            .flatMap({ _ in
                isFirstRequest = false
                return Deferred {
                    return Future<Any, AppError> { promise in
                        YJApiClient.request(apiPath: "/operation/api/v1/unified/operation/property/get", param: params) { code, msg, data in
                            guard let json = data as? [AnyHashable: Any],
                                  let values = json["values"] as? [[AnyHashable: Any]],
                                  let fv = values.first?["statusValue"] else {
                                promise(.failure(AppError("获取物模型属性失败")))
                                return
                            }
                            promise(.success(fv))
                        } fail: { error in
                            promise(.failure(AppError(error.localizedDescription, code: error.code)))
                        }
                    }
                }
            })
            .retry(2)
            .eraseToAnyPublisher()
    }
    
    /// 同时获取设备的多个物模型属性
    /// - Parameter keys: 对应的物模型key数组
    /// - Returns: 结果
    func getProperties(keys: [String]) -> AnyPublisher<[AnyHashable: Any], AppError> {
        var isFirstRequest = true
        let params: [String: Any] = ["deviceId": id, "identifiers": keys]
        return Just(()).setFailureType(to: AppError.self)
            .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global())
            .flatMap({ _ in
                isFirstRequest = false
                return Deferred {
                    return Future<[AnyHashable: Any], AppError> { promise in
                        YJApiClient.request(apiPath: "/operation/api/v1/unified/operation/property/get", param: params) { code, msg, data in
                            guard let json = data as? [AnyHashable: Any],
                                  let values = json["values"] as? [[AnyHashable: Any]] else {
                                promise(.failure(AppError("获取物模型属性失败")))
                                return
                            }
                            var final: [AnyHashable: Any] = [:]
                            for value in values {
                                if let identifier = value["identifier"] as? String, let statusValue = value["statusValue"] {
                                    final.updateValue(statusValue, forKey: identifier)
                                }
                            }
                            promise(.success(final))
                        } fail: { error in
                            promise(.failure(AppError(error.localizedDescription, code: error.code)))
                        }
                    }
                }
            })
            .retry(2)
            .eraseToAnyPublisher()
    }
    
    /// 设置设备的物模型属性
    /// - Parameters:
    ///   - key: 对应的物模型key
    ///   - params: 参数
    /// - Returns: 结果
    func setProperties(key: String, params: Any) -> AnyPublisher<Void, AppError> {
        var isFirstRequest = true
        let params: [String: Any] = [
            "deviceId": id,
            "method": "thing.service.property.set",
            "identifier": key,
            "id": UUID().uuidString,
            "version": "1.0",
            "params": params
        ]
        return Just(()).setFailureType(to: AppError.self)
            .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global())
            .flatMap({ _ in
                isFirstRequest = false
                return Deferred {
                    return Future<Void, AppError> { promise in
                        YJApiClient.request(apiPath: "/operation/api/v1/unified/operation/down", param: params) { code, msg, data in
                            if code == 0 {
                                promise(.success(()))
                            } else {
                                promise(.failure(AppError("设置物模型属性失败")))
                            }
                        } fail: { error in
                            promise(.failure(AppError(error.localizedDescription, code: error.code)))
                        }
                    }
                }
            })
            .retry(2)
            .eraseToAnyPublisher()
    }
    
    /// 调用设备的服务
    /// - Parameters:
    ///   - identifier: 对应的服务key
    ///   - params: 参数
    /// - Returns: 结果
    func invokeService(key: String, params: Any) -> AnyPublisher<Any, AppError> {
        var isFirstRequest = true
        let params: [String: Any] = [
            "deviceId": id,
            "method": "thing.service.\(key)",
            "identifier": key,
            "id": UUID().uuidString,
            "version": "1.0",
            "params": params
        ]
        return Just(()).setFailureType(to: AppError.self)
            .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global())
            .flatMap({ _ in
                isFirstRequest = false
                return Deferred {
                    return Future<Any, AppError> { promise in
                        YJApiClient.request(apiPath: "/operation/api/v1/unified/operation/down", param: params) { code, msg, data in
                            if code == 0 {
                                if let data {
                                    promise(.success(data))
                                } else {
                                    promise(.success(()))
                                }
                            } else {
                                promise(.failure(AppError("设置物模型服务失败")))
                            }
                        } fail: { error in
                            promise(.failure(AppError(error.localizedDescription, code: error.code)))
                        }
                    }
                }
            })
            .retry(2)
            .eraseToAnyPublisher()
    }
}
