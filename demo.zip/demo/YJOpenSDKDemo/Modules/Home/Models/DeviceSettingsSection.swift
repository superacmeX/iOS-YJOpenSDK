//
//  DeviceSettingsSection.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/29.
//

import Foundation
import UIKit

struct DeviceSettingsSection {
    let section: Section
    let items: [DeviceSettingsSection.Item]
    
    init(section: Section, items: [DeviceSettingsSection.Item]) {
        self.section = section
        self.items = items
    }
}

extension DeviceSettingsSection {
    struct Section: Hashable {
        let title: String
        let itemHeight: CGFloat
        
        func hash(into hasher: inout Hasher) {
            hasher.combine(title)
            hasher.combine(itemHeight)
        }
    }
}

extension DeviceSettingsSection {
    enum Item {
        /// 设备信息
        case info(icon: String, name: String, dn: String, action: String, jump: String)
        /// 按钮
        case buttons(icon: UIImage?, title: NSAttributedString, action: String)
        /// 详情
        case detail(icon: UIImage?, title: String, jump: String)
    }
}

extension DeviceSettingsSection.Item {
    /// 点击事件
    var action: String? {
        switch self {
        case let .info(icon: _, name: _, dn: _, action: a, jump: _):
            return a.isEmpty ? nil : a
        case let .buttons(icon: _, title: _, action: a):
            return a.isEmpty ? nil : a
        case .detail:
            return nil
        }
    }
    
    /// 路由跳转
    var router: String? {
        switch self {
        case let .info(icon: _, name: _, dn: _, action: _, jump: j):
            return j.isEmpty ? nil : j
        case .buttons:
            return nil
        case .detail(icon: _, title: _, jump: let j):
            return j.isEmpty ? nil : j
        }
    }
}

extension DeviceSettingsSection.Item: Hashable {
    func hash(into hasher: inout Hasher) {
        switch self {
        case let .info(icon, name, dn, action: a, jump: j):
            hasher.combine(icon)
            hasher.combine(name)
            hasher.combine(dn)
            hasher.combine(a)
            hasher.combine(j)
        case let .buttons(icon: icon, title: t, action: a):
            hasher.combine(icon)
            hasher.combine(t)
            hasher.combine(a)
        case let .detail(icon: icon, title: t, jump: j):
            hasher.combine(icon)
            hasher.combine(t)
            hasher.combine(j)
        }
    }
    
    static func == (lhs: Self, rhs: Self) -> Bool {
        switch (lhs, rhs) {
        case let (.info(icon: li, name: ln, dn: ld, action: la, jump: lj), .info(icon: ri, name: rn, dn: rd, action: ra, jump: rj)):
            return li == ri && ln == rn && ld == rd && la == ra && lj == rj
        case let (.buttons(icon: li, title: lt, action: la), .buttons(icon: ri, title: rt, action: ra)):
            return li == ri && lt == rt && la == ra
        case let (.detail(icon: li, title: lt, jump: lj), .detail(icon: ri, title: rt, jump: rj)):
            return li == ri && lt == rt && lj == rj
        default:
            return false
        }
    }
}
