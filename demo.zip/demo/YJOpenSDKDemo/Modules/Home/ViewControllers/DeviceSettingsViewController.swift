//
//  DeviceSettingsViewController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/29.
//

import UIKit
import Combine
import FJRouter

final class DeviceSettingsViewController: UIViewController {
    init(deviceId: String) {
        viewModel = DeviceSettingsViewModel(deviceId: deviceId)
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private let viewModel: DeviceSettingsViewModel
    private var dataSource: UICollectionViewDiffableDataSource<DeviceSettingsSection.Section, DeviceSettingsSection.Item>!
    private lazy var cancels: Set<AnyCancellable> = []
    private var collectionView: UICollectionView {
        return view as! UICollectionView
    }
}

extension DeviceSettingsViewController {
    override func loadView() {
        view = generateCollectionView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        setupCollectionViewDataSource()
        bind()
        viewModel.loadInfo()
    }
}

extension DeviceSettingsViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let item = dataSource.itemIdentifier(for: indexPath) else {
            return
        }
        if let router = item.router {
            FJRouter.jump().go(.loc(router))
            return
        }
        if let action = item.action {
            perform(Selector(action), with: indexPath)
        }
    }
}

private extension DeviceSettingsViewController {
    func generateCollectionView() -> UICollectionView {
        let layout = UICollectionViewCompositionalLayout { [weak self] idx, environment -> NSCollectionLayoutSection? in
            guard let self else {
                return nil
            }
            var s: DeviceSettingsSection.Section?
            if #available(iOS 15.0, *) {
                s = self.dataSource.sectionIdentifier(for: idx)
            } else {
                s = self.viewModel.setctions.value[idx].section
            }
            guard let s else {
                return nil
            }
            let itemSize = NSCollectionLayoutSize(widthDimension: NSCollectionLayoutDimension.fractionalWidth(1), heightDimension: NSCollectionLayoutDimension.fractionalHeight(1))
            let item = NSCollectionLayoutItem(layoutSize: itemSize)
            let groupSize = NSCollectionLayoutSize(widthDimension: NSCollectionLayoutDimension.fractionalWidth(1), heightDimension: NSCollectionLayoutDimension.absolute(s.itemHeight))
            let group: NSCollectionLayoutGroup
            if #available(iOS 16.0, *) {
                group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, repeatingSubitem: item, count: 1)
            } else {
                group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
            }
            let section = NSCollectionLayoutSection(group: group)
            section.contentInsets = NSDirectionalEdgeInsets(top: 12, leading: 12, bottom: 12, trailing: 12)
            let decorationItem = NSCollectionLayoutDecorationItem.background(elementKind: "background")
            decorationItem.contentInsets = NSDirectionalEdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8)
            section.decorationItems = [decorationItem]
            return section
        }
        layout.register(DeviceSettingsListReusableView.self, forDecorationViewOfKind: "background")
        return UICollectionView(frame: .zero, collectionViewLayout: layout)
    }
    
    func setup() {
        title = "设置"
        view.backgroundColor = .bgColor
        onlyDisplayBackBarItemImage()
        collectionView.delegate = self
        collectionView.jj.registerCell(DeviceSettingsInfoCell.self)
        collectionView.jj.registerCell(DeviceSettingsButtonsCell.self)
        collectionView.jj.registerCell(DeviceSettingsDetailJumpCell.self)
    }
    
    func setupCollectionViewDataSource() {
        dataSource = UICollectionViewDiffableDataSource(collectionView: collectionView) { collectionView, indexPath, item in
            switch item {
            case let .info(icon: icon, name: name, dn: dn, action: _, jump: _):
                let cell: DeviceSettingsInfoCell = collectionView.jj.dequeueReusableCell(for: indexPath)
                cell.iconUrl = icon
                cell.nickName = name
                cell.deviceName = dn
                return cell
            case let .buttons(icon: icon, title: t, action: _):
                let cell: DeviceSettingsButtonsCell = collectionView.jj.dequeueReusableCell(for: indexPath)
                cell.icon = icon
                cell.title = t
                return cell
            case let .detail(icon: icon, title: title, jump: _):
                let cell: DeviceSettingsDetailJumpCell = collectionView.jj.dequeueReusableCell(for: indexPath)
                cell.icon = icon
                cell.title = title
                return cell
            }
        }
        dataSource.supplementaryViewProvider = { collectionView, elementKind, indexPath -> UICollectionReusableView in
            return UICollectionReusableView()
        }
    }
    
    func bind() {
        viewModel.loading.sink(receiveValue: { [weak self] loading in
            loading ? self?.view.showIndicator() : self?.view.hideIndicator()
        }).store(in: &cancels)
        
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.deleteSuccess.sink(receiveValue: { [weak self] in
            self?.navigationController?.popViewController(animated: true)
        }).store(in: &cancels)
        
        viewModel.setctions.receive(on: DispatchQueue.main).filter({ !$0.isEmpty }).sink(receiveValue: { [weak self] setctions in
            guard let self else {
                return
            }
            var snapshot = NSDiffableDataSourceSnapshot<DeviceSettingsSection.Section, DeviceSettingsSection.Item>()
            for section in setctions {
                snapshot.appendSections([section.section])
                snapshot.appendItems(section.items, toSection: section.section)
            }
            self.dataSource.apply(snapshot, animatingDifferences: true)
        }).store(in: &cancels)
    }
}

// MARK: - actions
private extension DeviceSettingsViewController {
    @IBAction func onTapReboot(_ indexPath: IndexPath) {
        viewModel.rebootDevice()
    }
    
    @IBAction func onTapDelete(_ indexPath: IndexPath) {
        let alertVC = UIAlertController(title: "是否确定删除设备", message: nil, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "取消", style: .cancel))
        alertVC.addAction(UIAlertAction(title: "确定", style: .destructive, handler: { [unowned self] _ in
            self.viewModel.deleteDevice()
        }))
        present(alertVC, animated: true)
    }
}
