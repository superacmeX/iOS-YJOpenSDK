//
//  DeviceListViewController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import UIKit
import Combine
import FJRouter
import YJOpenSDK
import YJSAIAssistant
final class DeviceListViewController: UIViewController {
    private lazy var viewModel = DeviceListViewModel()
    private var dataSource: UICollectionViewDiffableDataSource<String, DeviceInfo>!
    private lazy var cancels: Set<AnyCancellable> = []
    private var collectionView: UICollectionView {
        return view as! UICollectionView
    }
}

extension DeviceListViewController {
    override func loadView() {
        view = generateCollectionView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        preparePlayer()
        bind()
        beginRefresh()
        loadAIAssitant()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        beginRefresh()
    }
}

extension DeviceListViewController: DeviceListCellDelegate {
    func onTapSettings(at cell: DeviceListCell) {
        guard let idp = collectionView.indexPath(for: cell) else {
            return
        }
        let obj = viewModel.devices.value[idp.item]
        FJRouter.jump().go(.name("deviceSettings", params: ["deviceId": obj.id]))
    }
    
    func onTapLiving(at cell: DeviceListCell) {
        guard let idp = collectionView.indexPath(for: cell) else {
            return
        }
        let obj = viewModel.devices.value[idp.item]
        let vc = LiveViewController(deviceName: obj.deviceName, productKey: obj.productKey)
//        let vc = VideoCallViewController(deviceName: obj.deviceName, productKey: obj.productKey)
//        let vc = ApTCardVodViewController()
        vc.hidesBottomBarWhenPushed = true;
        navigationController?.pushViewController(vc, animated: true);
    }
    
    func onTapSDLiving(at cell: DeviceListCell) {
        guard let idp = collectionView.indexPath(for: cell) else {
            return
        }
        let obj = viewModel.devices.value[idp.item]
        FJRouter.jump().go(.name("deviceSDRecords", params: ["deviceId": obj.id]))
    }
    
    func onTapCloudLiving(at cell: DeviceListCell) {
        guard let idp = collectionView.indexPath(for: cell) else {
            return
        }
        let obj = viewModel.devices.value[idp.item]
        FJRouter.jump().go(.name("deviceCloudRecords", params: ["deviceId": obj.id]))
    }
}

private extension DeviceListViewController {
    func generateCollectionView() -> UICollectionView {
        let itemSize = NSCollectionLayoutSize(widthDimension: NSCollectionLayoutDimension.fractionalWidth(1), heightDimension: NSCollectionLayoutDimension.fractionalHeight(1))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        item.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 12, bottom: 12, trailing: 12)
        let groupSize = NSCollectionLayoutSize(widthDimension: NSCollectionLayoutDimension.fractionalWidth(1), heightDimension: NSCollectionLayoutDimension.absolute(150))
        let group: NSCollectionLayoutGroup
        if #available(iOS 16.0, *) {
            group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, repeatingSubitem: item, count: 1)
        } else {
            group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        }
        let section = NSCollectionLayoutSection(group: group)
        let layout = UICollectionViewCompositionalLayout(section: section)
        return UICollectionView(frame: .zero, collectionViewLayout: layout)
    }
    
    func setup() {
        view.backgroundColor = .bgColor
        onlyDisplayBackBarItemImage()
        navigationItem.title = "设备列表"
        navigationItem.backButtonDisplayMode = .minimal
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "qrcode.viewfinder"), style: .plain, target: self, action: #selector(goScan))
        
        collectionView.jj.registerCell(DeviceListCell.self)
        dataSource = UICollectionViewDiffableDataSource(collectionView: collectionView) { [weak self] collectionView, indexPath, itemIdentifier in
            let cell: DeviceListCell = collectionView.jj.dequeueReusableCell(for: indexPath)
            cell.iconUrl = itemIdentifier.iconUrl
            cell.deviceName = itemIdentifier.nickName
            cell.delegate = self
            return cell
        }
        
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = .theme
        refreshControl.addTarget(self, action: #selector(refresh), for: .valueChanged)
        collectionView.refreshControl = refreshControl
    }
    
    func beginRefresh() {
        if let ref = collectionView.refreshControl, !ref.isRefreshing {
            collectionView.refreshControl?.beginRefreshing()
            collectionView.refreshControl?.sendActions(for: .valueChanged)
        }
    }
    
    func preparePlayer() {
        YJRMPEngine.getDefault().initialized()
    }
    
    @IBAction func goScan() {
        FJRouter.jump().go(.name("scanDevice"))
    }
    
    @IBAction func refresh() {
        viewModel.loadDevices()
    }
    
    func bind() {
        viewModel.devices.receive(on: DispatchQueue.main).sink(receiveValue: { [weak self] devices in
            guard let self else {
                return
            }
            var snapshot = NSDiffableDataSourceSnapshot<String, DeviceInfo>()
            snapshot.appendSections(["list"])
            snapshot.appendItems(devices)
            self.dataSource.apply(snapshot, animatingDifferences: true)
        }).store(in: &cancels)
        
        viewModel.endRefresh.sink(receiveValue: { [weak self] in
            self?.collectionView.refreshControl?.endRefreshing()
        }).store(in: &cancels)
    }
}

extension DeviceListViewController {
    func loadAIAssitant() {
        /// 登入成功之后再初始化，这里简单处理下
        YJSAIAssistantSDK.default.setup()
        YJSAIAssistantSDK.default.delegate = APPAIAssistant()
        YJSAIAssistantSDK.default.setLogo(name: "M1管家", boudle: Bundle.main, imageName: "cinmo.gif")
        YJSAIAssistantSDK.default.setLanguage()
    }
}
