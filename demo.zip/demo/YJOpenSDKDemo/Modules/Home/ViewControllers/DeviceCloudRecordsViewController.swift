//
//  DeviceCloudRecordsViewController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/9.
//

import UIKit
import Combine
import FSCalendar
final class DeviceCloudRecordsViewController: UIViewController {
    init(deviceId: String) {
        viewModel = DeviceCloudRecordsViewModel(deviceId: deviceId)
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private let viewModel: DeviceCloudRecordsViewModel
    private lazy var cancels: Set<AnyCancellable> = []
    private var recordView: DeviceRecordsView!
    private(set) lazy var paegController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal)
}

extension DeviceCloudRecordsViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        bind()
        showDetailDateListController(date: Date())
        viewModel.prepareLoadMonthEventDot(for: Date())
    }
}

extension DeviceCloudRecordsViewController: FSCalendarDelegate, FSCalendarDataSource {
    func calendarCurrentPageDidChange(_ calendar: FSCalendar) {
        viewModel.prepareLoadMonthEventDot(for: calendar.currentPage)
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        showDetailDateListController(date: date)
    }
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {
        let hasEvent = viewModel.eventDots.value.contains { d in
            Calendar.current.isDate(date, inSameDayAs: d)
        }
        return hasEvent ? 1 : 0
    }
}

private extension DeviceCloudRecordsViewController {
    func setup() {
        title = "云录像"
        onlyDisplayBackBarItemImage()
        paegController.willMove(toParent: self)
        addChild(paegController)
        recordView = DeviceRecordsView(pageView: paegController.view)
        recordView.frame = view.bounds
        view.addSubview(recordView)
        paegController.didMove(toParent: self)
        recordView.calendarView.delegate = self
        recordView.calendarView.dataSource = self
    }
    
    func bind() {
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.eventDots.sink(receiveValue: { [weak self] _ in
            self?.recordView.calendarView.reloadData()
        }).store(in: &cancels)
        
        viewModel.device.filter({ $0 != nil }).sink(receiveValue: { [weak self] obj in
            if let vc = self?.paegController.viewControllers?.first as? DeviceDayCloudRecordsController {
                vc.updateDeviceInfo(obj)
            }
        }).store(in: &cancels)
    }
    
    func showDetailDateListController(date: Date) {
        guard let preListController = paegController.viewControllers?.first as? DeviceDayCloudRecordsController else {
            let vc = DeviceDayCloudRecordsController(deviceId: viewModel.deviceId, date: date)
            vc.updateDeviceInfo(viewModel.device.value)
            paegController.setViewControllers([vc], direction: .forward, animated: false)
            return
        }
        let preDate = preListController.date
        if preDate == date {
            return
        }
        let vc = DeviceDayCloudRecordsController(deviceId: viewModel.deviceId, date: date)
        vc.updateDeviceInfo(viewModel.device.value)
        paegController.setViewControllers([vc], direction: date > preDate ? .forward : .reverse, animated: true)
    }
}
