//
//  AppBackBarItemable.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import UIKit
@MainActor
protocol AppBackBarItemable {
    func onlyDisplayBackBarItemImage()
}

extension AppBackBarItemable where Self: UIViewController {
    func onlyDisplayBackBarItemImage() {
        navigationItem.backButtonDisplayMode = .minimal
    }
}

extension UIViewController: AppBackBarItemable {}
