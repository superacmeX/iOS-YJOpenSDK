//
//  AppLogger.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/29.
//

import Foundation
import YJOpenSDK
import OSLog
final class AppLog: NSObject {
    override init() {
        log = Logger(subsystem: "logger.sdkdemo.com", category: "main")
        super.init()
    }
    
    private let log: Logger
}

extension AppLog: YJLoggerDelegate {
    var logLevel: YJOpenSDK.YJLogLevel {
        .all
    }
    
    func error(msg: String) {
        log.error("\(msg)")
    }
    
    func warn(msg: String) {
        log.warning("\(msg)")
    }
    
    func info(msg: String) {
        log.info("\(msg)")
    }
    
    func debug(msg: String) {
        log.debug("\(msg)")
    }
}
