//
//  SceneDelegate.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import UIKit
import FJRouter
import YJOpenSDK
import IQKeyboardManagerSwift
import IQKeyboardToolbarManager
class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?
    private lazy var logger = AppLog()
    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let ws = (scene as? UIWindowScene) else { return }
        window = UIWindow(windowScene: ws)
        window?.overrideUserInterfaceStyle = .light
        window?.backgroundColor = .white
        config()
        window?.makeKeyAndVisible()
    }
}

private extension SceneDelegate {
    func config() {
        IQKeyboardManager.shared.isEnabled = true
        IQKeyboardToolbarManager.shared.isEnabled = true
        _Concurrency.Task {
            try? await AppRouter.config()
            AppUser.shared.enabled()
            // FIXME: - 谨记appKey, appSecret和env是配套使用的, 测试环境和生产环境的appKey, appSecret不一致
            // TODO: - appKey, appSecret的申请请和商务对接申请
            let sdkVerifyInfo: YJVerifyInfo
            let isTest = true
            if isTest {
                let appKey = "xxxx"
                let appSecret = "xxxxxxxxxxx"
                sdkVerifyInfo = YJVerifyInfo(appKey: appKey, appSecret: appSecret, env: .test, country: .CN)
            } else {
                let appKey = "xxxx"
                let appSecret = "xxxxxxxxxxx"
                sdkVerifyInfo = YJVerifyInfo(appKey: appKey, appSecret: appSecret, env: .production, country: .CN)
            }
            YJOpenSDKManager.default.setup(sdkVerifyInfo) { result in
                
            }
            YJOpenSDKManager.default.logger = AppLog()
        }
    }
}
