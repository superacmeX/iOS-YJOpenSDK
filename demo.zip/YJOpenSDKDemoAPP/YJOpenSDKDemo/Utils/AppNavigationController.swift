//
//  AppNavigationController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/26.
//

import UIKit

final class AppNavigationController: UINavigationController {
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationBar.titleTextAttributes = [.foregroundColor: UIColor.black]
    }
}
