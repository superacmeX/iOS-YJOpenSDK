//
//  HUDToastable.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import UIKit
import JJKit
/// 显示toast协议
@MainActor
protocol HUDToastable: NSObjectProtocol {
    func showIndicator()
    func hideIndicator()
    func hideAllToasts()
    func showMessage(_ message: String)
    func showMessage(_ message: String, duration: Double)
    func showMessage(_ message: String, duration: Double, then: @escaping () -> Void)
    func showMessage(_ message: String, duration: Double, cornerRadius: HUDCornerRadius)
    func showMessage(_ message: String, duration: Double, cornerRadius: HUDCornerRadius, then: @escaping () -> Void)
}

/// 圆角
public enum HUDCornerRadius {
    /// 固定大小
    case fix(CGFloat)
    /// 高度的一半: 大小随高度变化
    case halfHeight
}

extension HUDToastable where Self: UIViewController {
    func showIndicator() {
        if (view.jj.width > 0 && view.jj.height > 0) {
            view.jj.showActivityIndicator()
        }
    }
    
    func hideIndicator() {
        view.jj.dismissActivityIndicator(animated: true)
    }
    
    func showMessage(_ message: String) {
        showMessage(message, duration: 1)
    }
    
    func showMessage(_ message: String, duration: Double) {
        showMessage(message, duration: duration, then: { })
    }
    
    func showMessage(_ message: String, duration: Double, then: @escaping () -> Void) {
        showMessage(message, duration: duration, cornerRadius: .fix(8))
    }
    
    func showMessage(_ message: String, duration: Double, cornerRadius: HUDCornerRadius) {
        showMessage(message, duration: duration, cornerRadius: cornerRadius, then: { })
    }
    
    func showMessage(_ message: String, duration: Double, cornerRadius: HUDCornerRadius, then: @escaping () -> Void) {
        let msg = message.trimmingCharacters(in: .whitespacesAndNewlines)
        guard msg.count > 0 else {
            return
        }
        let corner: JJToastContainerOptions.CornerRadius
        switch cornerRadius {
        case .fix(let cGFloat):
            corner = .fix(cGFloat)
        case .halfHeight:
            corner = .halfHeight
        }
        view.jj.makeToast(JJTextToastItem(attributedString: NSAttributedString(string: message, attributes: [.font: UIFont.systemFont(ofSize: 13)])))
            .updateItem(options: { options in
                options.margin = UIEdgeInsets(top: 8, left: 15, bottom: 8, right: 15)
            })
            .duration(.seconds(duration))
            .position(.center)
            .cornerRadius(corner)
            .didDisappear { [weak self] in
                if self != nil {
                    then()
                }
            }
            .show()
    }
    
    func hideAllToasts() {
        view.jj.dismissAllToasts()
    }
}

extension HUDToastable where Self: UIView {
    func showIndicator() {
        if (jj.width > 0 && jj.height > 0) {
            jj.showActivityIndicator()
        }
    }
    
    func hideIndicator() {
        jj.dismissActivityIndicator(animated: true)
    }
    
    func showMessage(_ message: String) {
        showMessage(message, duration: 1.5)
    }
    
    func showMessage(_ message: String, duration: Double) {
        showMessage(message, duration: duration, then: { })
    }
    
    func showMessage(_ message: String, duration: Double, then: @escaping () -> Void) {
        showMessage(message, duration: duration, cornerRadius: .fix(8))
    }
    
    func showMessage(_ message: String, duration: Double, cornerRadius: HUDCornerRadius) {
        showMessage(message, duration: duration, cornerRadius: cornerRadius, then: { })
    }
    
    func showMessage(_ message: String, duration: Double, cornerRadius: HUDCornerRadius, then: @escaping () -> Void) {
        let msg = message.trimmingCharacters(in: .whitespacesAndNewlines)
        guard msg.count > 0 else {
            return
        }
        let corner: JJToastContainerOptions.CornerRadius
        switch cornerRadius {
        case .fix(let cGFloat):
            corner = .fix(cGFloat)
        case .halfHeight:
            corner = .halfHeight
        }
        jj.makeToast(JJTextToastItem(attributedString: NSAttributedString(string: message, attributes: [.font: UIFont.systemFont(ofSize: 13)])))
            .updateItem(options: { options in
                options.margin = UIEdgeInsets(top: 8, left: 15, bottom: 8, right: 15)
            })
            .duration(.seconds(duration))
            .position(.center)
            .cornerRadius(corner)
            .didDisappear { [weak self] in
                if self != nil {
                    then()
                }
            }
            .show()
    }
    
    func hideAllToasts() {
        jj.dismissAllToasts()
    }
}

extension UIView: HUDToastable {}
