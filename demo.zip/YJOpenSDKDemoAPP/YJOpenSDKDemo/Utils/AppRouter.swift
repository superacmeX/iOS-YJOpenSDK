//
//  AppRouter.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import Foundation
import FJRouter

struct AppRouter {}

extension AppRouter {
    static func config() async throws {
        try await FJRouter.shared.registerRoute(path: "/", name: "root", builder: nil, redirect: FJRouteCommonRedirector(redirect: { state in
            switch AppUser.shared.hasLogin {
            case true:
                if let app = await UIApplication.shared.versionkKeyWindow?.rootViewController, app is AppTabBarViewController {
                    return nil
                }
                return "/app"
            case false:
                if let app = await UIApplication.shared.versionkKeyWindow?.rootViewController, !(app is AppTabBarViewController) {
                    return nil
                }
                return try? await FJRouter.shared.convertLocationBy(name: "loginAccount")
            }
        }))
        
        /// 注册登录
        let loginRoute = try FJRoute(path: "/account", name: "account", builder: nil, redirect: FJRouteCommonRedirector(redirect: { _ in "/account/login" }), routes: [
            FJRoute(path: "login", name: "loginAccount", builder: { _ in LoginViewController() }, animator: { _ in FJRoute.AppRootControllerAnimator(navigationController: UINavigationController()) }),
            FJRoute(path: "register", name: "registerAccount", builder: { _ in RegisterViewController() })
        ])
        await FJRouter.shared.registerRoute(loginRoute)
        
        /// 首页
        let homeRoute = try FJRoute(path: "/app", name: "app", builder: { _ in
            AppTabBarViewController()
        }, animator: { _ in FJRoute.AppRootControllerAnimator() }, routes: [
            FJRoute(path: "device", name: "deviceList", builder: { _ in DeviceListViewController() }),
            FJRoute(path: "user", name: "User", builder: { _ in UserController() }),
        ])
        await FJRouter.shared.registerRoute(homeRoute)
        
        // 绑定设备
        let bindRoute = try FJRoute(path: "/bind", builder: nil, redirect: FJRouteCommonRedirector(redirect: { _ in "/bind/scan" }), routes: [
            FJRoute(path: "scan", name: "scanDevice", builder: { _ in ScanDeviceController() }, animator: { _ in FJRoute.SystemPushAnimator() }),
            FJRoute(path: "scan/result/:qr", name: "scanResult", builder: { info in
                ScanResultController(qr: info.matchState.pathParameters["qr"] ?? "")
            }),
            FJRoute(path: "wifi/:pk/:dn", name: "wifiBind", builder: { info in
                let pk = info.matchState.pathParameters["pk"] ?? ""
                let dn = info.matchState.pathParameters["dn"] ?? ""
                return BindDevicebyWifiController(productKey: pk, deviceName: dn)
            }),
        ])
        await FJRouter.shared.registerRoute(bindRoute)
        
        // 设备设置
        let deviceSettingsRoute = try FJRoute(path: "/device/:deviceId/settings", name: "deviceSettings", builder: { info in
            let id = info.matchState.pathParameters["deviceId"]
            return DeviceSettingsViewController(deviceId: id ?? "")
        }, animator: { _ in FJRoute.SystemPushAnimator() }, routes: [
            FJRoute(path: "voice", name: "deviceVoiceSettings", builder: { info in
                DeviceVoiceSettingsViewController(deviceId: info.matchState.pathParameters["deviceId"] ?? "")
            }),
        ])
        await FJRouter.shared.registerRoute(deviceSettingsRoute)
        
        // 录像
        let deviceCloudRoute = try FJRoute(path: "/device/:deviceId/record", name: "deviceRecord", builder: nil, redirect: FJRouteCommonRedirector(redirect: { state in
            try? await state.convertLocationBy(name: "deviceCloudRecords", params: state.pathParameters)
        }), routes: [
            FJRoute(path: "cloud/list", name: "deviceCloudRecords", builder: { info in
                let deviceId = info.matchState.pathParameters["deviceId"] ?? ""
                return DeviceCloudRecordsViewController(deviceId: deviceId)
            }, animator: { _ in FJRoute.SystemPushAnimator() }),
            FJRoute(path: "sd/list", name: "deviceSDRecords", builder: { info in
                let deviceId = info.matchState.pathParameters["deviceId"] ?? ""
                return DeviceSDRecordsViewController(deviceId: deviceId)
            }, animator: { _ in FJRoute.SystemPushAnimator() }),
        ])
        await FJRouter.shared.registerRoute(deviceCloudRoute)
    }
}
