//
//  CloudVodViewController.swift
//  YJOpenSDKDemo
//
//  Created by lujiongjian on 2025/2/20.
//

import UIKit
import YJOpenSDK
import RMPlayer

final class CloudVodViewController: UIViewController {
    private var kTag: String = ""
    private var player: YJRMPNetCloudVodPlayer?
    private var videoBaseView:      UIView = UIView()
    private var playerVideoView:    YJRMPVideoView? = nil
    private var progressLabel:      UILabel?
    private var deviceName: String = ""
    private var productKey: String = ""
    private var url:        String = ""
    private var meta:       String = ""

    init() {
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        print("\(kTag).deinit")
    }

    private lazy var loadingIndicator: UIActivityIndicatorView = {
        var type: UIActivityIndicatorView.Style = .whiteLarge
        if #available(iOS 13.0, *) {
            type = .large
        }
        let indicator = UIActivityIndicatorView(style: type)
        indicator.color = UIColor.green
        self.videoBaseView.addSubview(indicator)
        indicator.snp.makeConstraints { make in
            make.center.equalTo(self.videoBaseView)
        }
        return indicator
    }()
}

extension CloudVodViewController {
    convenience init(deviceName: String, productKey: String, url: String, meta: String) {
        self.init()

        self.deviceName = deviceName
        self.productKey = productKey
        self.url        = url
        self.meta       = meta

        kTag = String(describing: type(of: self))
    }

    override func viewDidLoad() {
        setUpUI()
        setUpPlayer()
    }
}

// MARK: YJRMPlayerDelegate
extension CloudVodViewController: YJRMPlayerDelegate {

    func onBufferStateUpdate(player: Any?, state: YJRMPlayerBufferState, bufferDurationMillis: Int) {
        print("\(kTag).\(#function)--\(#line), state=\(state), bufferDurationMillis=\(bufferDurationMillis)")

        switch state {
        case .loading:
            startLoading()
        case .ready:
            stopLoading()
        default:
            break
        }
    }

    func onError(player: Any?, type: YJRMPlayerErrorType, code: YJRMPlayerErrorCode, description: String?) {
        print("\(kTag).\(#function)--\(#line), player=\(String(describing: player)), type=\(type.rawValue), code=\(code.rawValue), desc=\(String(describing: description))")

        let tips = "播放失败"
        let message = "type(\(type.rawValue)), code(\(code.rawValue)), \(String(describing: description))"
        let alertTips = UIAlertController(title: tips, message: message, preferredStyle: .alert)
        self.present(alertTips, animated: true, completion: nil)

        // 获取弱引用 self
        weak var weakSelf = self
        alertTips.addAction(UIAlertAction(title: "重试", style: .default, handler: { action in
            guard let p = player as? YJRMPNetCloudVodPlayer else { return }
            p.stop()
            p.start()
            weakSelf?.startLoading()
        }))
        alertTips.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
    }

    func onFirstFrameRendered(player: Any?, elapseMills: Int) {
        print("\(kTag).\(#function)--\(#line), elapseMills=\(elapseMills)")
        self.stopLoading()
    }

    func onPlayerStateChange(player: Any?, state: YJRMPlayerState) {
        print("\(kTag).\(#function)--\(#line), state=\(state.rawValue)")
    }

    func onSeekComplete(player: Any?, success: Bool) {
        print("\(kTag).\(#function)--\(#line), success=\(success)")
    }

    func onVideoSizeChanged(player: Any?, size: CGSize) {
        print("\(kTag).\(#function)--\(#line), size=[\(size.width) x \(size.height)]")
    }

    func onVodPlayComplete(player: Any?) {
        print("\(kTag).\(#function)--\(#line)")
    }

    func onVodPlayProgress(player: Any?, millis: Int) {
//        print("\(kTag).\(#function)--\(#line), millis=\(millis)")
        self.progressLabel?.text = "\(millis / 1000) s"
    }
}

private extension CloudVodViewController {

    func setUpPlayer() {
        let config = YJRMPNetPlayerConfig()
        config.engine = RMPEngine.getDefault()
        config.deviceName = self.deviceName
        config.productKey = self.productKey

        self.player = YJRMPNetCloudVodPlayer.create(with: config)
        self.player?.delegate = self
        self.playerVideoView = YJRMPVideoView(frame: CGRectZero)
        self.player?.setVideoView(self.playerVideoView as? YJRMPVideoView)
        self.videoBaseView.addSubview(self.playerVideoView!)
        self.playerVideoView?.snp.makeConstraints({ make in
            make.edges.equalTo(0);
        })
        self.playerVideoView?.backgroundColor = UIColor(white: 0.0, alpha: 1.0)

        self.player?.setCloudSource(url: url, meta: meta, mode: .all)
        self.player?.start()
        self.startLoading()
    }

    func setUpUI() {
        self.title = "云录像"
        self.videoBaseView = UIView(frame: CGRectMake(0, DeviceHelper.navigationBarHeight + 20, DeviceHelper.mainScreenWidth, DeviceHelper.mainScreenWidth * 9 / 16))
        self.view.addSubview(self.videoBaseView)

        //pannel
        let panel_w = DeviceHelper.mainScreenWidth
        let panel_h = DeviceHelper.mainScreenWidth * 9 / 32;
        //pannel
        let pannel = UIView.init(frame: CGRectZero)
        pannel.backgroundColor = UIColor(white: 0.667, alpha: 1.0)
        self.view.addSubview(pannel)
        pannel.snp.makeConstraints { make in
            make.bottom.equalTo(self.view).offset(-20)
            make.size.equalTo(CGSize(width: panel_w, height: panel_h))
        }

        // Button parameters
        let btn_x_gap: CGFloat = 10
        let btn_y_gap: CGFloat = 10
        let btn_w = (panel_w - btn_x_gap * 5) / 4
        let btn_h = (panel_h - btn_y_gap * 3) / 2
        let btnSize = CGSize(width: btn_w, height: btn_h)

        // Stop/Start Button
        let stopBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        stopBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                // 停止播放
                self?.player?.stop()
                btn.setTitle("start", for: .normal)
            } else {
                // 开始播放
                self?.player?.setCloudSource(url: self?.url, meta: self?.meta, mode: .all)
                self?.player?.start()
                btn.setTitle("stop", for: .normal)
            }
        }
        initBtn(btn: stopBtn, title: "stop", size: btnSize)
        pannel.addSubview(stopBtn)
        stopBtn.snp.makeConstraints { make in
            make.left.equalTo(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        // Mute/Unmute Button
        let mutBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        mutBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                // 取消静音
                self?.player?.muteRemoteAudio(true)
                btn.setTitle("unmute", for: .normal)
            } else {
                // 静音
                self?.player?.muteRemoteAudio(false)
                btn.setTitle("mute", for: .normal)
            }
        }
        initBtn(btn: mutBtn, title: "mute", size: btnSize)
        pannel.addSubview(mutBtn)
        mutBtn.snp.makeConstraints { make in
            make.left.equalTo(stopBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        //pause/resume
        let pauseBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        pauseBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            if btn.isSelected {
                self?.player?.pause()
                btn.setTitle("resume", for: .normal)
            } else {
                self?.player?.resume()
                btn.setTitle("pause", for: .normal)
            }
        }
        initBtn(btn: pauseBtn, title: "pause", size: btnSize)
        pannel.addSubview(pauseBtn)
        pauseBtn.snp.makeConstraints { make in
            make.left.equalTo(mutBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        //seek到某个时间播放
        let seekBtn = UIButton.gradientView(with: btnSize, start: UIColor(hexString: "#FF8960"), end: UIColor(hexString: "#FF62A5"))
        seekBtn.addActionHandler { [weak self] control in
            guard let btn = control as? UIButton else { return }
            btn.isSelected.toggle()
            self?.player?.seek(6)
        }
        initBtn(btn: seekBtn, title: "seekto 6s", size: btnSize)
        pannel.addSubview(seekBtn)
        seekBtn.snp.makeConstraints { make in
            make.left.equalTo(pauseBtn.snp.right).offset(btn_x_gap)
            make.top.equalTo(btn_y_gap)
            make.size.equalTo(btnSize)
        }

        //vod progress
        let pl = UILabel()
        pl.backgroundColor = UIColor(red: 0.0, green: 1.0, blue: 0.0, alpha: 1.0)
        self.view.addSubview(pl)
        self.progressLabel = pl
        pl.snp.makeConstraints { make in
            make.top.equalTo(videoBaseView.snp.bottom)
            make.left.equalTo(self.view.snp.centerX)
            make.right.equalTo(self.view)
            make.height.equalTo(20)
        }
    }

    func initBtn(btn: UIButton, title: String, size: CGSize) {
        btn.setTitle(title, for: .normal)
        btn.titleLabel?.font = UIFont(ofSize: 15)
        btn.setTitleColor(UIColor(hexString: "#FFFFFF"), for: .normal)
        btn.setTitleColor(UIColor(hexString: "#FFFFFF", alpha: 0.6), for: .highlighted)
        btn.layer.masksToBounds = true
        btn.layer.cornerRadius = size.height / 2
    }

    // MARK: - LoadingIndicator
    func startLoading() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.loadingIndicator.startAnimating()
        }
    }

    func stopLoading() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.loadingIndicator.stopAnimating()
        }
    }
}
