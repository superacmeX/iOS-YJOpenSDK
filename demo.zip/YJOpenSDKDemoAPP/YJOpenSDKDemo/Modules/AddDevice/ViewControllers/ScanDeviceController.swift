//
//  ScanDeviceController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import UIKit
import AVFoundation
import FJRouter
/// 扫描二维码
final class ScanDeviceController: UIViewController {
    var scanResult: ((URL) -> ())?
    
    private enum SessionSetupResult {
        case success
        case notAuthorized
        case configurationFailed
    }
    
    private lazy var session = AVCaptureSession()

    private var isSessionRunning = false
    
    private lazy var sessionQueue = DispatchQueue(label: "session queue")
    
    private var setupResult: SessionSetupResult = .success
    
    private var videoDeviceInput: AVCaptureDeviceInput!
    
    private lazy var metadataOutput = AVCaptureMetadataOutput()
    
    private lazy var metadataObjectsQueue = DispatchQueue(label: "metadata objects queue", attributes: [], target: nil)
    
    private var keyValueObservations = [NSKeyValueObservation]()
    
    private lazy var metadataObjectsOverlayLayersDrawingSemaphore = DispatchSemaphore(value: 1)
    
    private lazy var previewView = ScanDevicePreviewView()
    
    private let viewBounds = UIApplication.shared.versionkKeyWindow!.bounds
}

extension ScanDeviceController {
    override func loadView() {
        view = previewView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "扫描二维码"
        setNavi()
        previewView.session = session
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            break
        case .notDetermined:
            sessionQueue.suspend()
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                if !granted {
                    self?.setupResult = .notAuthorized
                }
                self?.sessionQueue.resume()
            }
        default:
            setupResult = .notAuthorized
        }
        sessionQueue.asyncAfter(deadline: .now() + 0.3, execute: { [weak self] in
            self?.configureSession()
        })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        sessionQueue.async { [weak self] in
            guard let self else {
                return
            }
            switch self.setupResult {
            case .success:
                self.addObservers()
                self.session.startRunning()
                self.isSessionRunning = self.session.isRunning
            case .notAuthorized:
                DispatchQueue.main.async { [weak self] in
                    self?.showNotAuthorizedAlert()
                }
            case .configurationFailed:
                DispatchQueue.main.async { [weak self] in
                    self?.showConfigurationFailedAlert()
                }
            }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        sessionQueue.async { [weak self] in
            guard let self else {
                return
            }
            if self.setupResult == .success {
                self.session.stopRunning()
                self.isSessionRunning = self.session.isRunning
                self.removeObservers()
            }
        }
        super.viewWillDisappear(animated)
    }
}


private extension ScanDeviceController {
    func setNavi() {
        onlyDisplayBackBarItemImage()
    }
    
    func configureSession() {
        if setupResult != .success {
            return
        }
        session.beginConfiguration()
        do {
            let defaultVideoDevice: AVCaptureDevice?
            if let backCameraDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) {
                defaultVideoDevice = backCameraDevice
            } else if let frontCameraDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) {
                defaultVideoDevice = frontCameraDevice
            } else {
                defaultVideoDevice = nil
            }
            guard let videoDevice = defaultVideoDevice else {
                setupResult = .configurationFailed
                session.commitConfiguration()
                return
            }
            let videoDeviceInput = try AVCaptureDeviceInput(device: videoDevice)
            if session.canAddInput(videoDeviceInput) {
                session.addInput(videoDeviceInput)
                self.videoDeviceInput = videoDeviceInput
                
                DispatchQueue.main.async { [weak self] in
                    guard let self else {
                        return
                    }
                    let statusBarOrientation = UIApplication.shared.versionkKeyWindow?.windowScene?.interfaceOrientation ?? .portrait
                    var initialVideoOrientation: AVCaptureVideoOrientation = .portrait
                    if statusBarOrientation != .unknown {
                        if let videoOrientation = AVCaptureVideoOrientation(interfaceOrientation: statusBarOrientation) {
                            initialVideoOrientation = videoOrientation
                        }
                    }
                    self.previewView.videoPreviewLayer.connection!.videoOrientation = initialVideoOrientation
                }
            } else {
                setupResult = .configurationFailed
                session.commitConfiguration()
                return
            }
        } catch {
            setupResult = .configurationFailed
            session.commitConfiguration()
            return
        }
        
        if session.canAddOutput(metadataOutput) {
            session.addOutput(metadataOutput)
            
            metadataOutput.setMetadataObjectsDelegate(self, queue: metadataObjectsQueue)
            metadataOutput.metadataObjectTypes = [.qr]
            
            let width = 250.0 / self.viewBounds.height
            let height = 250.0 / self.viewBounds.width
            let x = (1.0 - width) / 2.0
            let y = (1.0 - height) / 2.0
            let initialRectOfInterest = CGRect(x: x, y: y, width: width, height: height)
            metadataOutput.rectOfInterest = initialRectOfInterest

            DispatchQueue.main.async { [weak self] in
                guard let self else {
                    return
                }
                let initialRegionOfInterest = self.previewView.videoPreviewLayer.layerRectConverted(fromMetadataOutputRect: initialRectOfInterest)
                self.previewView.setRegionOfInterestWithProposedRegionOfInterest(initialRegionOfInterest)
            }
        } else {
            setupResult = .configurationFailed
            session.commitConfiguration()
            return
        }
        session.commitConfiguration()
    }
    
    func addObservers() {
        var keyValueObservation: NSKeyValueObservation
        
        keyValueObservation = session.observe(\.isRunning, options: .new) { [weak self] _, change in
            guard let self else {
                return
            }
            guard let isSessionRunning = change.newValue else { return }
            
            DispatchQueue.main.async { [weak self] in
                guard let self else {
                    return
                }
                if !isSessionRunning {}
                if isSessionRunning {
                    self.previewView.setRegionOfInterestWithProposedRegionOfInterest(self.previewView.regionOfInterest)
                }
            }
        }
        keyValueObservations.append(keyValueObservation)
        
        let notificationCenter = NotificationCenter.default
        
        notificationCenter.addObserver(self, selector: #selector(sessionRuntimeError(_:)), name: .AVCaptureSessionRuntimeError, object: session)
    }
    
    func removeObservers() {
        NotificationCenter.default.removeObserver(self, name: .AVCaptureSessionRuntimeError, object: session)
        
        for keyValueObservation in keyValueObservations {
            keyValueObservation.invalidate()
        }
        keyValueObservations.removeAll()
    }
    
    func showNotAuthorizedAlert() {
        let alertController = UIAlertController(title: "相机权限受限", message: "该功能需要授权访问您的相机", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "下次", style: .cancel, handler: nil))
        alertController.addAction(UIAlertAction(title: "前往设置",
                                                                         style: .`default`, handler: { _ in
                                                                            UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!, options: [:], completionHandler: nil)
        }))
        
        present(alertController, animated: true, completion: nil)
    }
    
    func showConfigurationFailedAlert() {
        let alertController = UIAlertController(title: "温馨提示", message: "无法获取摄像头信息", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "确定", style: .cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func sessionRuntimeError(_ noti: Notification) {
        guard let error = noti.userInfo?[AVCaptureSessionErrorKey] as? AVError else { return }
        if error.code == .mediaServicesWereReset {
            sessionQueue.async { [weak self] in
                guard let self else {
                    return
                }
                if self.isSessionRunning {
                    self.session.startRunning()
                    self.isSessionRunning = self.session.isRunning
                }
            }
        }
    }
}

extension ScanDeviceController: AVCaptureMetadataOutputObjectsDelegate {
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        if metadataObjectsOverlayLayersDrawingSemaphore.wait(timeout: .now()) == .success {
            DispatchQueue.main.async { [weak self] in
                guard let self else {
                    return
                }
                for obj in metadataObjects {
                    self.handleMetadataObject(obj)
                }
                self.metadataObjectsOverlayLayersDrawingSemaphore.signal()
            }
        }
    }
    
    private func handleMetadataObject(_ metadataObject: AVMetadataObject) {
        let transformedMetadataObject = previewView.videoPreviewLayer.transformedMetadataObject(for: metadataObject)
        guard let barcodeMetadataObject = transformedMetadataObject as? AVMetadataMachineReadableCodeObject else {
            return
        }
        guard let stringValue = barcodeMetadataObject.stringValue, !stringValue.isEmpty else {
            return
        }
        guard let _ = DeviceQRUtil.analyzeQR(stringValue) else {
            return
        }
        sessionQueue.async { [weak self] in
            self?.session.stopRunning()
        }
        try? FJRouter.shared.goNamed("scanResult", params: ["qr": stringValue])
    }
}

extension AVCaptureVideoOrientation {
    init?(deviceOrientation: UIDeviceOrientation) {
        switch deviceOrientation {
            case .portrait: self = .portrait
            case .portraitUpsideDown: self = .portraitUpsideDown
            case .landscapeLeft: self = .landscapeRight
            case .landscapeRight: self = .landscapeLeft
            default: return nil
        }
    }
    
    init?(interfaceOrientation: UIInterfaceOrientation) {
        switch interfaceOrientation {
            case .portrait: self = .portrait
            case .portraitUpsideDown: self = .portraitUpsideDown
            case .landscapeLeft: self = .landscapeLeft
            case .landscapeRight: self = .landscapeRight
            default: return nil
        }
    }
}
