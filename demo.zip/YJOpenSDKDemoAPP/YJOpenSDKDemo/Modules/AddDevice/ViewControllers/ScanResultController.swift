//
//  ScanResultController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/25.
//

import UIKit
import Combine
import FJRouter
final class ScanResultController: UIViewController {
    init(qr: String) {
        viewModel = ScanResultViewModel(qr: qr)
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private let viewModel: ScanResultViewModel
    private var cancels: Set<AnyCancellable> = []
    private var resultView: ScanResultView {
        return view as! ScanResultView
    }
}

extension ScanResultController {
    override func loadView() {
        view = ScanResultView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        bind()
        viewModel.loadInfo()
    }
}

private extension ScanResultController {
    func setup() {
        onlyDisplayBackBarItemImage()
        view.backgroundColor = .bgColor
        title = "重置设备"
    }
    
    func bind() {
        viewModel.loading.sink(receiveValue: { [weak self] loading in
            loading ? self?.view.showIndicator() : self?.view.hideIndicator()
        }).store(in: &cancels)
        
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.info.sink(receiveValue: { [weak self] info in
            self?.resultView.nextButton.isEnabled = true
        }).store(in: &cancels)
        
        resultView.nextButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { [weak self] in
            if let self {
                self.dealBindMethod()
            }
        }).store(in: &cancels)
    }
    
    func dealBindMethod() {
        guard let info = viewModel.info.value else {
            return
        }
        let binds = info.configNetType ?? [1]
        if binds.isEmpty {
            return
        }
        if binds.count == 1 {
            goBind(by: binds[0])
            return
        }
        showChooseBindAlert(binds: binds)
    }
    
    func showChooseBindAlert(binds: [Int]) {
        let alertVC = UIAlertController(title: nil, message: "请选择绑定方式", preferredStyle: .actionSheet)
        let cancel = UIAlertAction(title: "取消", style: .cancel)
        alertVC.addAction(cancel)
        for bind in binds {
            var title = "WiFi绑定"
            switch bind {
            case 1: // wifi
                title = "WiFi绑定"
            case 2: // 蓝牙
                title = "蓝牙绑定"
            case 3:// 设备扫码
                title = "扫码绑定"
            case 4: // 4g
                title = "4G绑定"
            default:
                return
            }
            let action = UIAlertAction(title: title, style: .default) { [weak self] _ in
                self?.goBind(by: bind)
            }
            alertVC.addAction(action)
        }
        present(alertVC, animated: true)
    }
    
    func goBind(by bind: Int) {
        switch bind {
        case 1: // wifi
            FJRouter.jump().go(.name("wifiBind", params: ["pk": viewModel.pk, "dn": viewModel.dn]), from: self)
        case 2: // 蓝牙
            FJRouter.jump().go(.name("searchBluetooth", params: ["pk": viewModel.pk, "dn": viewModel.dn]), from: self)
        case 3:// 设备扫码
            return
        case 4: // 4g
            FJRouter.jump().go(.name("4gBind", params: ["pk": viewModel.pk, "dn": viewModel.dn]), from: self)
        default:
            return
        }
    }
}
