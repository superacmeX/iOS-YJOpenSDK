//
//  BindDevicebyBluetoothController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2025/2/27.
//

import UIKit
import Combine
import YJOpenSDK
final class BindDevicebyBluetoothController: UIViewController {
    init(productKey: String, deviceName: String, info: YJBLEScanDeviceInfo) {
        self.productKey = productKey
        self.deviceName = deviceName
        self.info = info
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private let productKey: String
    private let deviceName: String
    private let info: YJBLEScanDeviceInfo
    private var cancels: Set<AnyCancellable> = []
    private var backItem: UIBarButtonItem!
    private var viewModel: BindDevicebyBluetoothViewModel!
    private var bindView: BindDevicebyWifiView {
        return view as! BindDevicebyWifiView
    }
}

extension BindDevicebyBluetoothController {
    override func loadView() {
        view = BindDevicebyWifiView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        bind()
    }
}

private extension BindDevicebyBluetoothController {
    func setup() {
        title = "蓝牙绑定"
        backItem = UIBarButtonItem(image: UIImage(systemName: "chevron.left"), style: .plain, target: self, action: #selector(self.onBack))
    }
    
    @IBAction func onBack() {
        let alertVC = UIAlertController(title: "确定停止绑定设备吗?", message: nil, preferredStyle: .alert)
        let cancel = UIAlertAction(title: "继续", style: .default)
        let ok = UIAlertAction(title: "停止", style: .destructive) { [weak self] _ in
            self?.viewModel.stopBind()
            self?.navigationController?.popToRootViewController(animated: true)
        }
        alertVC.addAction(cancel)
        alertVC.addAction(ok)
        present(alertVC, animated: true)
    }
    
    func bind() {
        viewModel = BindDevicebyBluetoothViewModel(
            productKey: productKey,
            deviceName: deviceName,
            info: info,
            wifi: bindView.wifissidTextField.textField.textPublisher,
            pwd: bindView.wifipwdTextField.textField.textPublisher
        )
        
        viewModel.loading.sink(receiveValue: { [weak self] loading in
            loading ? self?.view.showIndicator() : self?.view.hideIndicator()
        }).store(in: &cancels)
        
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.binging.sink(receiveValue: { [weak self] binging in
            self?.navigationItem.leftBarButtonItem = binging ? self?.backItem : nil
        }).store(in: &cancels)
        
        viewModel.bindSuccess.sink(receiveValue: { [weak self] did in
            self?.navigationController?.popToRootViewController(animated: true)
        }).store(in: &cancels)
        
        viewModel.bindEnabled.sink(receiveValue: { [weak self] e in
            self?.bindView.bindButton.isEnabled = e
        }).store(in: &cancels)
        
        bindView.bindButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { [weak self] in
            self?.connectDeviceWifi()
        }).store(in: &cancels)
    }
    
    func connectDeviceWifi() {
        AppLocalNetworkManager.default.requestAuthorization { [weak self] granted in
            guard let self else {
                return
            }
            switch granted {
            case .allow, .unknown: // 已有本地网络权限
                self.viewModel.prepareBind()
            case .denied:
                AppLocalNetworkManager.default.showNoOpenLocalNetAlert(title: nil, source: self)
            }
        }
    }
}
