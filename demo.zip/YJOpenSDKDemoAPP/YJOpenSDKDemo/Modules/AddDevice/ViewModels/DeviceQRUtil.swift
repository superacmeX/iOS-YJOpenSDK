//
//  DeviceQR.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/25.
//

import Foundation

struct DeviceQRUtil {
    
}

extension DeviceQRUtil {
    /// 解析二维码
    /// - Parameter qr: 二维码
    /// - Returns: 解析后的数据
    static func analyzeQR(_ qr: String) -> (pk: String, dn: String)? {
        let fqr = qr.trimmingCharacters(in: .whitespacesAndNewlines)
        if fqr.isEmpty {
            return nil
        }
        let splits = fqr.split(separator: "\n")
        if splits.count >= 3 {
            let pk = String(describing: splits[1])
            let dn = String(describing: splits[2])
            return (pk, dn)
        }
        guard let cop = URLComponents(string: fqr),
              let items = cop.queryItems,
              let pk = items.first(where: { $0.name == "pk" })?.value,
              let dn = items.first(where: { $0.name == "dn" })?.value else {
            return nil
        }
        return (pk, dn)
    }
}
