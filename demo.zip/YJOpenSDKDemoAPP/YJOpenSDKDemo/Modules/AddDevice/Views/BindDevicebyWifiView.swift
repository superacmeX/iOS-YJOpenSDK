//
//  BindDevicebyWifiView.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/27.
//

import UIKit

final class BindDevicebyWifiView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private(set) lazy var wifissidTextField = EntryBoxView()
    private(set) lazy var wifipwdTextField = EntryBoxView()
    private(set) lazy var bindButton = UIButton()
    
}

extension BindDevicebyWifiView {
    private func setup() {
        backgroundColor = .bgColor
        do {
            let descLabel = UILabel()
            descLabel.text = "请输入WiFi信息"
            descLabel.textColor = .black
            descLabel.font = UIFont.systemFont(ofSize: 14)
            addSubview(descLabel)
            descLabel.snp.makeConstraints { make in
                make.left.right.equalTo(self).inset(24)
                make.top.equalTo(safeAreaLayoutGuide.snp.top).offset(24)
            }
            
            wifissidTextField.textField.text = "SuperACME_Product_Test"
            wifissidTextField.textField.placeholder = "请输入WIFI名称"
            addSubview(wifissidTextField)
            wifissidTextField.snp.makeConstraints { make in
                make.width.centerX.equalTo(descLabel)
                make.top.equalTo(descLabel.snp.bottom).offset(10)
                make.height.equalTo(50)
            }
            
            wifipwdTextField.textField.text = "SUpro@com18"
            wifipwdTextField.textField.placeholder = "请输入WIFI密码"
            addSubview(wifipwdTextField)
            wifipwdTextField.snp.makeConstraints { make in
                make.size.centerX.equalTo(wifissidTextField)
                make.top.equalTo(wifissidTextField.snp.bottom).offset(20)
            }
            
            bindButton.setAttributedTitle(NSAttributedString(string: "开始绑定", attributes: [.font: UIFont.systemFont(ofSize: 14), .foregroundColor: UIColor.white]), for: [])
            bindButton.isEnabled = false
            addSubview(bindButton)
            bindButton.snp.makeConstraints { make in
                make.left.right.equalTo(self).inset(24)
                make.bottom.equalTo(safeAreaLayoutGuide.snp.bottom).inset(24)
                make.height.equalTo(50)
            }
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        bindButton.setBackgroundImage(UIImage(color: .theme, size: bindButton.bounds.size, cornerRadius: 12), for: .normal)
        bindButton.setBackgroundImage(UIImage(color: .gray, size: bindButton.bounds.size, cornerRadius: 12), for: .disabled)
    }
}
