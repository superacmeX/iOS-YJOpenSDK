//
//  DeviceSettingsListReusableView.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/29.
//

import UIKit

final class DeviceSettingsListReusableView: UICollectionReusableView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    private func setup() {
        let boxView = UIView()
        boxView.layer.cornerRadius = 8
        boxView.clipsToBounds = true
        boxView.backgroundColor = .white
        boxView.layer.shadowColor = UIColor.gray.cgColor
        boxView.layer.shadowOpacity = 0.3
        boxView.layer.shadowOffset = CGSize(width: 2, height: 2)
        addSubview(boxView)
        boxView.snp.makeConstraints { make in
            make.edges.equalTo(self)
        }
    }
}
