//
//  DeviceRecordsView.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/9.
//

import UIKit
import FSCalendar
final class DeviceRecordsView: UIView {
    init(pageView: UIView) {
        self.pageView = pageView
        super.init(frame: .zero)
        setup()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private unowned var pageView: UIView
    private(set) lazy var calendarView = FSCalendar()
}

extension DeviceRecordsView {
    private func setup() {
        backgroundColor = .bgColor
        calendarView.appearance.eventDefaultColor = UIColor(hexString: "#5F2AD1")
        calendarView.appearance.selectionColor = .theme
        addSubview(calendarView)
        calendarView.snp.makeConstraints { make in
            make.left.right.equalTo(self)
            make.top.equalTo(safeAreaLayoutGuide.snp.top)
            make.height.equalTo(200)
        }
        
        addSubview(pageView)
        pageView.snp.makeConstraints { make in
            make.left.bottom.right.equalTo(self)
            make.top.equalTo(calendarView.snp.bottom)
        }
    }
    
    private func generateCollectionView() -> UICollectionView {
        let itemSize = NSCollectionLayoutSize(widthDimension: NSCollectionLayoutDimension.fractionalWidth(1), heightDimension: NSCollectionLayoutDimension.fractionalHeight(1))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        item.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 12, bottom: 12, trailing: 12)
        let groupSize = NSCollectionLayoutSize(widthDimension: NSCollectionLayoutDimension.fractionalWidth(1), heightDimension: NSCollectionLayoutDimension.absolute(150))
        let group: NSCollectionLayoutGroup
        if #available(iOS 16.0, *) {
            group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, repeatingSubitem: item, count: 1)
        } else {
            group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        }
        let section = NSCollectionLayoutSection(group: group)
        let layout = UICollectionViewCompositionalLayout(section: section)
        return UICollectionView(frame: .zero, collectionViewLayout: layout)
    }
}
