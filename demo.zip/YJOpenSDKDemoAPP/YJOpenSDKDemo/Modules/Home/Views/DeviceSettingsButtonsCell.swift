//
//  DeviceSettingsButtonsCell.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/4.
//

import UIKit

final class DeviceSettingsButtonsCell: UICollectionViewCell {
    var icon: UIImage? {
        didSet {
            iconView.image = icon
            iconView.isHidden = icon == nil
        }
    }
    var title = NSAttributedString(string: "") {
        didSet {
            configTitle()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    private lazy var iconView = UIImageView()
    private lazy var titleLabel = UILabel()
}

extension DeviceSettingsButtonsCell {
    private func setup() {
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.spacing = 12
        stackView.alignment = .center
        stackView.distribution = .fill
        contentView.addSubview(stackView)
        stackView.snp.makeConstraints { make in
            make.center.equalTo(contentView)
        }
        
        iconView.isHidden = true
        stackView.addArrangedSubview(iconView)
        stackView.addArrangedSubview(titleLabel)
    }
    
    private func configTitle() {
        let str = title.string
        let r = (str as NSString).range(of: str)
        var hasFont = false
        title.enumerateAttribute(.font, in: r) { attrs, range, stop in
            if attrs != nil {
                hasFont = true
                stop.pointee = true
            }
        }
        if hasFont {
            titleLabel.attributedText = title
            return
        }
        let att = NSMutableAttributedString(attributedString: title)
        att.addAttributes([.font: UIFont.systemFont(ofSize: 16)], range: r)
        titleLabel.attributedText = att
    }
}
