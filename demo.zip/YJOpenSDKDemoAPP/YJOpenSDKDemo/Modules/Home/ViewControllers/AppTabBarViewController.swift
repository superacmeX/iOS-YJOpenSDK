//
//  AppTabBarViewController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import UIKit
import FJRouter
final class AppTabBarViewController: UITabBarController {
    
}

extension AppTabBarViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
}

private extension AppTabBarViewController {
    func setup() {
        view.backgroundColor = .bgColor
        Task {
            async let listVc = try? FJRouter.shared.viewController(forName: "deviceList")
            async let userVc = try? FJRouter.shared.viewController(forName: "User")
            let (lvc, uvc) = await (listVc, userVc)
            var vcs: [UIViewController] = []
            if let lvc {
                let listNavi = AppNavigationController(rootViewController: lvc)
                listNavi.tabBarItem.title = "首页"
                listNavi.tabBarItem.image = UIImage(systemName: "house.circle")
                vcs.append(listNavi)
            }
            if let uvc {
                let userNavi = AppNavigationController(rootViewController: uvc)
                userNavi.tabBarItem.title = "我的"
                userNavi.tabBarItem.image = UIImage(systemName: "person.circle")
                vcs.append(userNavi)
            }
            viewControllers = vcs
        }
    }
}
