//
//  DeviceVoiceSettingsViewController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/5.
//

import UIKit
import Combine

final class DeviceVoiceSettingsViewController: UIViewController {
    init(deviceId: String) {
        viewModel = DeviceVoiceSettingsViewModel(deviceId: deviceId)
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private let viewModel: DeviceVoiceSettingsViewModel
    private var settingsView: DeviceVoiceSettingsView {
        return view as! DeviceVoiceSettingsView
    }
    private lazy var cancels: Set<AnyCancellable> = []
}

extension DeviceVoiceSettingsViewController {
    override func loadView() {
        view = DeviceVoiceSettingsView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "声音设置"
        onlyDisplayBackBarItemImage()
        bind()
    }
    
    override func viewIsAppearing(_ animated: Bool) {
        super.viewIsAppearing(animated)
        viewModel.loadInfo()
    }
}

private extension DeviceVoiceSettingsViewController {
    func bind() {
        viewModel.loading.removeDuplicates().sink(receiveValue: { [weak self] loading in
            loading ? self?.view.showIndicator() : self?.view.hideIndicator()
        }).store(in: &cancels)
        
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.currentVolume.sink(receiveValue: { [weak self] value in
            self?.settingsView.currentVolume = value
        }).store(in: &cancels)
        
        settingsView.slider.valuePublisher.dropFirst().sink(receiveValue: { [weak self] v in
            self?.viewModel.prepareChangeVolume(v)
        }).store(in: &cancels)
    }
}
