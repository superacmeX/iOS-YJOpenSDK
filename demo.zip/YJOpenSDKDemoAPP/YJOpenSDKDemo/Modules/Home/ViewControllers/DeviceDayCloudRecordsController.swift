//
//  DeviceDayCloudRecordsController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/9.
//

import UIKit
import Combine

final class DeviceDayCloudRecordsController: UIViewController {
    var date: Date {
        viewModel.date
    }
    init(deviceId: String, date: Date) {
        viewModel = DeviceDayCloudRecordsViewModel(deviceId: deviceId, date: date)
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private let viewModel: DeviceDayCloudRecordsViewModel
    private lazy var cancels: Set<AnyCancellable> = []
    private var dataSource: UICollectionViewDiffableDataSource<String, DeviceCloudRecord>!
    private var collectionView: UICollectionView {
        return view as! UICollectionView
    }
}

extension DeviceDayCloudRecordsController {
    override func loadView() {
        view = generateCollectionView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        bind()
        viewModel.loadRecords()
    }
    
    func updateDeviceInfo(_ device: DeviceInfo?) {
        viewModel.updateDeviceInfo(device)
    }
}

extension DeviceDayCloudRecordsController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let obj = viewModel.records.value[indexPath.item]
        let url = obj.videoUrl
        let pk = viewModel.device?.productKey ?? ""
        let dn = viewModel.device?.deviceName ?? ""
        let meta = obj.videoExt.meta
        let metastring = obj.videoExt.metaString
        print(pk, dn, url, meta, metastring)
        let vc = CloudVodViewController(deviceName: dn, productKey: pk, url: url, meta: metastring);
        vc.hidesBottomBarWhenPushed = true;
        navigationController?.pushViewController(vc, animated: true);
    }
}

private extension DeviceDayCloudRecordsController {
    func generateCollectionView() -> UICollectionView {
        let itemSize = NSCollectionLayoutSize(widthDimension: NSCollectionLayoutDimension.fractionalWidth(1), heightDimension: NSCollectionLayoutDimension.fractionalHeight(1))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        item.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 12, bottom: 6, trailing: 12)
        let groupSize = NSCollectionLayoutSize(widthDimension: NSCollectionLayoutDimension.fractionalWidth(1), heightDimension: NSCollectionLayoutDimension.absolute(150))
        let group: NSCollectionLayoutGroup
        if #available(iOS 16.0, *) {
            group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, repeatingSubitem: item, count: 1)
        } else {
            group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
        }
        let section = NSCollectionLayoutSection(group: group)
        let layout = UICollectionViewCompositionalLayout(section: section)
        return UICollectionView(frame: .zero, collectionViewLayout: layout)
    }
    
    func setup() {
        view.backgroundColor = .bgColor
        collectionView.delegate = self
        collectionView.jj.registerCell(DeviceCloudRecordCell.self)
        dataSource = UICollectionViewDiffableDataSource(collectionView: collectionView) { collectionView, indexPath, itemIdentifier in
            let cell: DeviceCloudRecordCell = collectionView.jj.dequeueReusableCell(for: indexPath)
            cell.name = itemIdentifier.alarmName
            cell.picUrl = itemIdentifier.picUrl
            cell.time = itemIdentifier.eventTime
            cell.duration = itemIdentifier.videoExt.duration
            return cell
        }
        
        let refreshControl = UIRefreshControl()
        refreshControl.tintColor = .theme
        refreshControl.addTarget(self, action: #selector(refresh), for: .valueChanged)
        collectionView.refreshControl = refreshControl
    }
    
    @IBAction func refresh() {
        viewModel.loadRecords()
    }
    
    func bind() {
        viewModel.tips.sink(receiveValue: { [weak self] tips in
            self?.view.showMessage(tips)
        }).store(in: &cancels)
        
        viewModel.endRefresh.sink(receiveValue: { [weak self] in
            self?.collectionView.refreshControl?.endRefreshing()
        }).store(in: &cancels)
        
        viewModel.records.sink(receiveValue: { [weak self] records in
            guard let self else {
                return
            }
            var snapshot = NSDiffableDataSourceSnapshot<String, DeviceCloudRecord>()
            snapshot.appendSections(["list"])
            snapshot.appendItems(records)
            self.dataSource.apply(snapshot, animatingDifferences: true)
        }).store(in: &cancels)
    }
}
