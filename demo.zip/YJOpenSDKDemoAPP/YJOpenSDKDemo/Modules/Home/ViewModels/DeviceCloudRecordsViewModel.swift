//
//  DeviceCloudRecordsViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/12/9.
//

import Foundation
import Combine
import YJOpenSDK

final class DeviceCloudRecordsViewModel {
    /// 打点信息
    private(set) lazy var eventDots = CurrentValueSubject<[Date], Never>([])
    private(set) lazy var device = CurrentValueSubject<DeviceInfo?, Never>(nil)
    private(set) lazy var tips = PassthroughSubject<String, Never>()
    private lazy var envetRequest = PassthroughSubject<(start: String, end: String), Never>()
    let deviceId: String
    private let dateFormatter: DateFormatter
    private lazy var cancels: Set<AnyCancellable> = []
    init(deviceId: String) {
        self.deviceId = deviceId
        dateFormatter = DateFormatter()
        dateFormatter.locale = Locale.init(identifier: "zh_Hans_CN")
        dateFormatter.calendar = Calendar.init(identifier: .iso8601)
        dateFormatter.timeZone = TimeZone.autoupdatingCurrent
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        envetRequest.removeDuplicates(by: { $0.start == $1.start && $0.end == $1.end })
            .map({ [weak self] pairs -> AnyPublisher<[Date], Never> in
            if let self {
                return self.requestMonthEvent(startDate: pairs.start, endDate: pairs.end)
            }
            return Just([]).eraseToAnyPublisher()
        })
        .switchToLatest()
        .sink(receiveValue: { [weak self] values in
            self?.eventDots.send(values)
        }).store(in: &cancels)
        
        DeviceInfo.load(id: deviceId).receive(on: RunLoop.main)
        .sink(receiveCompletion: { _ in
            
        }, receiveValue: { [weak self] obj in
            self?.device.send(obj)
        }).store(in: &cancels)
    }
}

extension DeviceCloudRecordsViewModel {
    /// 查询月打点
    func prepareLoadMonthEventDot(for date: Date) {
        let hasSearchMonth = eventDots.value.contains { d in
            Calendar.current.isDate(date, equalTo: d, toGranularity: .month)
        }
        if hasSearchMonth {
            return
        }
        let days = getFirstAndLastDayOfMonth(date: date)
        let start = dateFormatter.string(from: days.firstDay)
        let end = dateFormatter.string(from: days.lastDay)
        envetRequest.send((start, end))
    }
    
    private func getFirstAndLastDayOfMonth(date: Date) -> (firstDay: Date, lastDay: Date) {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.year, .month], from: date)
        
        guard let startOfMonth = calendar.date(from: components),
              let endOfMonth = calendar.date(byAdding: DateComponents(month: 1, day: -1), to: startOfMonth) else {
            return (Date(), Date())
        }
        let startOfDay = calendar.startOfDay(for: startOfMonth)
        let endOfDay = calendar.startOfDay(for: endOfMonth)
        return (startOfDay, endOfDay)
    }
    
    private func requestMonthEvent(startDate: String, endDate: String) -> AnyPublisher<[Date], Never> {
        let params: [String: Any] = ["deviceIds": [deviceId], "startDate": startDate, "endDate": endDate, "blnContainVideo": true]
        var isFirstRequest = true
        return Just(()).setFailureType(to: AppError.self)
        .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global())
        .flatMap({ _ in
            isFirstRequest = false
            return Deferred {
                return Future<[String], AppError> { promise in
                    YJApiClient.request(apiPath: "/message/api/v1/event/alarm/date", param: params) { code, msg, data in
                        guard let data = data as? [AnyHashable: Any],
                              let dateList = data["dateList"] as? [String] else {
                            promise(.failure(AppError("数据解析失败")))
                            return
                        }
                        promise(.success(dateList))
                    } fail: { error in
                        promise(.failure(AppError(error.localizedDescription)))
                    }
                }
            }
        })
        .retry(2)
        .compactMap({ [weak self] dateList in
            return dateList.compactMap({ self?.dateFormatter.date(from: $0) })
        })
        .replaceError(with: [])
        .eraseToAnyPublisher()
    }
}
