//
//  DeviceListViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/26.
//

import Combine
import Foundation
import YJOpenSDK

final class DeviceListViewModel {
    private(set) lazy var devices = CurrentValueSubject<[DeviceInfo], Never>([])
    private(set) lazy var endRefresh = PassthroughSubject<Void, Never>()
    private lazy var cancels: Set<AnyCancellable> = []
    private lazy var requestList = PassthroughSubject<Void, Never>()
    init() {
        requestList.map({ [weak self] _ -> AnyPublisher<[DeviceInfo], Never> in
            guard let self else {
                return Just([]).eraseToAnyPublisher()
            }
            return self.dealRequest()
        })
        .switchToLatest()
        .receive(on: DispatchQueue.main)
        .sink(receiveCompletion: { comp in
            self.endRefresh.send(())
        }, receiveValue: { [weak self] value in
            self?.endRefresh.send(())
            self?.devices.send(value)
        }).store(in: &cancels)
    }
}

extension DeviceListViewModel {
    func loadDevices() {
        requestList.send(())
    }
    
    private func dealRequest() -> AnyPublisher<[DeviceInfo], Never> {
        var isFirstRequest = true
        return Just(()).setFailureType(to: AppError.self)
        .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global())
        .flatMap({ _ in
            isFirstRequest = false
            return Deferred {
                return Future<[[AnyHashable: Any]], AppError> { promise in
                    YJApiClient.request(apiPath: "/user/api/v2/allGroupDeviceList", param: [:]) { code, msg, data in
                        guard let data = data as? [[AnyHashable: Any]],
                            let flist =  data.first,
                        let deviceList = flist["deviceList"] as? [[AnyHashable: Any]] else {
                            promise(.failure(AppError("获取列表失败")))
                            return
                        }
                        promise(.success(deviceList))
                    } fail: { error in
                        promise(.failure(AppError(error.localizedDescription, code: error.code)))
                    }
                }
            }
        })
        .retry(2)
        .flatMap { json -> AnyPublisher<Data, AppError> in
            do {
                let data = try JSONSerialization.data(withJSONObject: json, options: [])
                return Just(data).setFailureType(to: AppError.self).eraseToAnyPublisher()
            } catch {
                return Fail(error: AppError("数据解析失败")).eraseToAnyPublisher()
            }
        }
        .decode(type: [DeviceInfo].self, decoder: JSONDecoder())
        .replaceError(with: [])
        .eraseToAnyPublisher()
    }
}
