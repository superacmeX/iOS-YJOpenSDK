//
//  DeviceStatus.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/29.
//

import Foundation
import Combine
import YJOpenSDK
struct DeviceStatus {
    /// 设备序列号
    let deviceName: String
    /// 设备状态--SLEEP：休眠 OFFLINE：离线 DEPLETED：电量耗尽 NORMAL：正常 UNKNOWN：未知
    let status: String
    /// 设备休眠状态：1：关机休眠 0：非关机休眠
    let sleepSwitch: Int
    /// 剩余电量
    let remainingBattery: Int
    /// 充电状态 0 -未充电 1-充电中
    let chargeStatus: Int
    /// 0 - 弱 1 - 中 2 - 强
    let wiFiRSSI: Int?
    /// 4G信号强度 0-1格信号 1-2格信号 2-3格信号 3-4格信号
    let fourGSignalStrength: Int?
}

extension DeviceStatus {
    private static var statusParams: [String: Any] = [
        "propertyList": [
            ["propertyName": "displayStatus", "propertyType": "1"],
            ["propertyName": "ChargeStatus", "propertyType": "0"],
            ["propertyName": "RemainingBattery", "propertyType": "0"],
            ["propertyName": "WiFiRSSI", "propertyType": "0"],
            ["propertyName": "FourGSignalStrength", "propertyType": "0"],
            ["propertyName": "DeviceSleepSwitch", "propertyType": "0"],
        ]
    ]
    
    /// 获取最新设备状态
    /// - Parameter id: 设备id
    static func loadLatest(id: String) -> AnyPublisher<DeviceStatus, AppError> {
        var isFirstRequest = true
        var params = statusParams
        params.updateValue(id, forKey: "deviceId")
        return Just(()).setFailureType(to: AppError.self)
            .delay(for: .milliseconds(isFirstRequest ? 0 : 350), scheduler: DispatchQueue.global())
            .flatMap({ _ in
                isFirstRequest = false
                return Deferred {
                    return Future<[AnyHashable: Any], AppError> { promise in
                        YJApiClient.request(apiPath: "/user/api/v1/user/devicePropertyList", param: ["devicePropertyList": [params]]) { code, msg, data in
                            if let json = data as? [[AnyHashable: Any]], let fs = json.first {
                                promise(.success(fs))
                            } else {
                                promise(.failure(AppError("失败")))
                            }
                        } fail: { error in
                            promise(.failure(AppError(error.localizedDescription, code: error.code)))
                        }
                    }
                }
            })
            .retry(2)
            .flatMap { json -> AnyPublisher<DeviceStatus, AppError> in
                guard let dn = json["deviceName"] as? String,
                      let propertyDatas = json["propertyData"] as? [[String: AnyHashable]] else {
                    return Fail(error: AppError("数据解析失败")).eraseToAnyPublisher()
                }
                let numberFormatter = NumberFormatter()
                var status: String?
                var wiFiRSSI: Int?
                var chargeStatus: Int?
                var sleepSwitch: Int?
                var remainingBattery: Int?
                var fourGSignalStrength: Int?
                for pjson in propertyDatas {
                    guard let pname = pjson["propertyName"] as? String,
                          let pvalue = pjson["propertyValue"] as? String else {
                        continue
                    }
                    switch pname {
                    case "displayStatus":
                        status = pvalue
                    case "WiFiRSSI":
                        wiFiRSSI = numberFormatter.number(from: pvalue)?.intValue ?? 0
                    case "ChargeStatus":
                        chargeStatus = numberFormatter.number(from: pvalue)?.intValue ?? 0
                    case "DeviceSleepSwitch":
                        sleepSwitch = numberFormatter.number(from: pvalue)?.intValue ?? 0
                    case "RemainingBattery":
                        remainingBattery =  numberFormatter.number(from: pvalue)?.intValue
                    case "FourGSignalStrength":
                        fourGSignalStrength =  numberFormatter.number(from: pvalue)?.intValue
                    default:
                        continue
                    }
                }
                guard let status, let sleepSwitch, let remainingBattery, let chargeStatus else {
                    return Fail(error: AppError("数据解析失败")).eraseToAnyPublisher()
                }
                let obj = DeviceStatus(deviceName: dn, status: status, sleepSwitch: sleepSwitch, remainingBattery: remainingBattery, chargeStatus: chargeStatus, wiFiRSSI: wiFiRSSI, fourGSignalStrength: fourGSignalStrength)
                return Just(obj).setFailureType(to: AppError.self).eraseToAnyPublisher()
            }
            .eraseToAnyPublisher()
    }
}
