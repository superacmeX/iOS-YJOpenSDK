//
//  UserController.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/26.
//

import UIKit
import Combine
import YJOpenSDK
import FJRouter

private var cancels: Set<AnyCancellable> = []
final class UserController: UIViewController {
    
}

extension UserController {
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "用户中心"
        
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(title: "重置密码", style: .plain, target: self, action: #selector(onResetPasswordTapped))
        ]
        
        setup()
    }
    
    @objc private func onResetPasswordTapped() {
        FJRouter.jump().go(.name("forgotPassword"))
    }
}

private extension UserController {
    func setup() {
        let logoutButton = UIButton()
        logoutButton.setAttributedTitle(NSAttributedString(string: "Logout", attributes: [.font: UIFont.systemFont(ofSize: 17), .foregroundColor: UIColor.white]), for: [])
        logoutButton.layer.cornerRadius = 12
        logoutButton.backgroundColor = .theme
        view.addSubview(logoutButton)
        logoutButton.snp.makeConstraints { make in
            make.left.right.equalTo(view).inset(20)
            make.centerY.equalTo(view)
            make.height.equalTo(50)
        }
        
        logoutButton.controlEventPublisher(for: .primaryActionTriggered).sink(receiveValue: { _ in
            YJOpenSDKManager.default.accountService.logout()
        }).store(in: &cancels)
    }
}
