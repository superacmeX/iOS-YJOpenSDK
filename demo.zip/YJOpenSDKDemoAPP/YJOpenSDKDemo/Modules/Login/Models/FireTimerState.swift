//
//  FireTimerState.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/25.
//

import Foundation

enum FireTimerState {
    case initialize
    case reset(total: Int)
    case timer(total: Int, current: Int)
}
