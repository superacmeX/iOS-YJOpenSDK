//
//  LoginViewModel.swift
//  YJOpenSDKDemo
//
//  Created by zgjff on 2024/11/22.
//

import Foundation
import Combine
import YJOpenSDK
final class LoginViewModel {
    private(set) lazy var loading = PassthroughSubject<Bool, Never>()
    private(set) lazy var tips = PassthroughSubject<String, Never>()
    private(set) lazy var loginEnabled = PassthroughSubject<Bool, Never>()
    private(set) lazy var loginSuccess = PassthroughSubject<Void, Never>()
    private var cancels: Set<AnyCancellable> = []
    private var account = ""
    private var pwd = ""
    init(account: AnyPublisher<String?, Never>, pwd: AnyPublisher<String?, Never>) {
        account.combineLatest(pwd).sink(receiveValue: { [weak self] (acc, pwd) in
            self?.account = acc ?? ""
            self?.pwd = pwd ?? ""
        }).store(in: &cancels)
        
        loading.combineLatest(account, pwd).sink(receiveValue: { [weak self] (loading, acc, pwd) in
            if loading {
                self?.loginEnabled.send(false)
                return
            }
            let enabled = (acc ?? "").count >= 8 && (pwd ?? "").count >= 6
            self?.loginEnabled.send(enabled)
        }).store(in: &cancels)
        
        loading.send(false)
    }
}

extension LoginViewModel {
    func prepareLogin() {
        guard case let .success(task) = YJOpenSDKManager.default.accountService.passwordLoginTask() else {
            return
        }
        loading.send(true)
        task.login(with: account, password: pwd) { [weak self] error in
            self?.loading.send(false)
            if let error {
                self?.tips.send(error.rawValue)
                return
            }
            self?.loginSuccess.send(())
        }
    }
}
