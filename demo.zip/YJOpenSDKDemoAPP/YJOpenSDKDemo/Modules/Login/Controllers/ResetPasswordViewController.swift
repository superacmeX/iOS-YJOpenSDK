//
//  ResetPasswordViewController.swift
//  YJOpenSDKDemo
//
//  Created by wzy on 2025/11/4.
//

import UIKit
import YJOpenSDK

class ResetPasswordViewController: UIViewController {
    @IBOutlet weak var createResetBtn: UIButton!
    @IBOutlet weak var createResetTaskStateLabel: UILabel!
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var sendAuthBtn: UIButton!
    
    @IBOutlet weak var authcodeTextField: UITextField!
    @IBOutlet weak var checkAuthcodeBtn: UIButton!
    @IBOutlet weak var resetPwdTextField: UITextField!
    @IBOutlet weak var resetPwdBtn: UIButton!
    
    
    @IBOutlet weak var oldPwdTextField: UITextField!
    @IBOutlet weak var newPwdTextField: UITextField!
    @IBOutlet weak var changePwdBtn: UIButton!
    
    private var task: YJOpenAccountForgotPasswordTask?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createResetBtn.addTarget(self, action: #selector(createResetBtnTapped), for: .touchUpInside)
        sendAuthBtn.addTarget(self, action: #selector(sendAuthBtnTapped), for: .touchUpInside)
        checkAuthcodeBtn.addTarget(self, action: #selector(checkAuthcodeBtnTapped), for: .touchUpInside)
        resetPwdBtn.addTarget(self, action: #selector(resetPwdBtnTapped), for: .touchUpInside)
        changePwdBtn.addTarget(self, action: #selector(changePwdBtnTapped), for: .touchUpInside)
    }
    
    @objc private func createResetBtnTapped() {
        guard case let .success(task) = YJOpenSDKManager.default.accountService.forgotPasswordTask() else {
            createResetTaskStateLabel.text = "Failed"
            return
        }
        
        self.task = task
        createResetTaskStateLabel.text = "Success"
    }
    
    @objc private func sendAuthBtnTapped() {
        guard let _ = task else {
            YJToast.show("请先创建流程")
            return
        }
        
        task?.sendAuthcode(userName: usernameTextField.text ?? "", completion: { error in
            guard let error = error else {
                YJToast.show("发送成功")
                return
            }
            
            YJToast.show("\(error)")
        })
    }
    
    @objc private func checkAuthcodeBtnTapped() {
        guard let _ = task else {
            YJToast.show("请先创建流程")
            return
        }
        
        task?.verifiedAuthcode(authcode: authcodeTextField.text ?? "", completion: { error in
            guard let error = error else {
                YJToast.show("检查AuthCode成功")
                return
            }
            
            YJToast.show("\(error)")
        })
    }
    
    @objc private func resetPwdBtnTapped() {
        guard let _ = task else {
            YJToast.show("请先创建流程")
            return
        }
        
        task?.resetPassword(password: resetPwdTextField.text ?? "", completion: { error in
            guard let error = error else {
                YJToast.show("重置密码成功")
                return
            }
            
            YJToast.show("\(error)")
        })
    }
    
    @objc private func changePwdBtnTapped() {
        YJOpenSDKManager.default.accountService.resetPassword(oldPassword: oldPwdTextField.text ?? "", newPassword: newPwdTextField.text ?? "") { error in
            if let error = error {
                YJToast.show("\(error)")
            } else {
                YJToast.show("修改成功")
            }
        }
    }
}
