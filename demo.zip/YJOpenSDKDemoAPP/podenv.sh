#!/bin/bash

# sh podenv.sh dev
# sh podenv.sh prod


if [ "$1" == "dev" ]; then
    PODFILE_BACKUP="Podfile.temp"
    rm -f "$PODFILE_BACKUP"
    cp Podfile "$PODFILE_BACKUP"
    ln -sf Podfile.dev Podfile 
    ls -l Podfile
    pod install
    ln -sf Podfile Podfile 
    mv "$PODFILE_BACKUP" Podfile
    rm -f "$PODFILE_BACKUP"
elif [ "$1" == "prod" ]; then
    pod install
else
    echo "Usage: $0 [dev|prod]"
    exit 1
fi


ls -l Podfile



