#ifndef CMARK_GFM_TAGFILTER_H
#define CMARK_GFM_TAGFILTER_H

#include "cmark-gfm-core-extensions.h"

CMARK_GFM_NO_EXPORT
cmark_syntax_extension *create_tagfilter_extension(void);

#endif
