//
//  RMPNetDeviceParams.h
//  rmplayer
//
//  Created by lujiongjian on 2025/9/3.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>

RTC_OBJC_EXPORT
@interface RMPNetDeviceParams : NSObject

/*!
 @abstract 是否开启MP4录像保留H264 SEI，默认NO
*/
@property (nonatomic, assign) BOOL standardH264SEI;

@end

