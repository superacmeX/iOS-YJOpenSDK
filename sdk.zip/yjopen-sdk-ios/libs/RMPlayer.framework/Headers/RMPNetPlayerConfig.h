//
//  RMPNetPlayerConfig.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/15.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPNetDeviceParams.h"

@class RMPEngine;
RTC_OBJC_EXPORT
@interface RMPNetConfig : NSObject

/// 设备名
@property(nonatomic, copy) NSString *deviceName;

/// 产品识别码
@property(nonatomic, copy) NSString *productKey;

/// 播放器创建所需引擎，不能为`nil`
@property(nonatomic, strong) RMPEngine *engine;

@property(nonatomic, strong) RMPNetDeviceParams *params;

@end

RTC_OBJC_EXPORT
@interface RMPNetPlayerConfig : RMPNetConfig
@end
