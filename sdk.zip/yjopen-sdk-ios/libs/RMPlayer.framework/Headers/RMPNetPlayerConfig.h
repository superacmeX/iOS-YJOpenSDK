//
//  RMPNetPlayerConfig.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/15.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>


RTC_OBJC_EXPORT
@interface RMPNetConfig : NSObject

/// 设备名
@property(nonatomic, copy) NSString *deviceName;

/// 产品识别码
@property(nonatomic, copy) NSString *productKey;

/*!
 @abstract 设置要播放的通道画面。channelId  通道号。1 普通摄像头画面或多目相机摄像头1的画面；2 多目相机摄像头2的画面；N 多目相机摄像头N的画面
           多目摄像头需要调用。不设置默认为 1
*/
@property(nonatomic, assign) int channelId;

@end

RTC_OBJC_EXPORT
@interface RMPNetPlayerConfig : RMPNetConfig
@end
