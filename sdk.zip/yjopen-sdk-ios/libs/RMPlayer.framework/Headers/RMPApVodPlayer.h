//
//  RMPApVodPlayer.h
//  rmplayer
//
//  Created by jelin on 2023/9/19.
//

#import <UIKit/UIKit.h>
#import "RMPlayerDelegate.h"
#import <RMPlayer/RTCVideoRenderer.h>

RTC_OBJC_EXPORT
@interface RMPApVodPlayer : NSObject

@property(nonatomic, weak) id<RMPlayerDelegate> delegate;

- (UIView *)playerView;

/*!
 @abstract 设置渲染远端摄像头视频的窗口
*/
- (void)setVideoView:(id<RTC_OBJC_TYPE(RTCVideoRenderer)>)view;

- (BOOL)setRangeStartSec:(long)startSec endSec:(long)endSec;

- (BOOL)muteRemoteAudio:(BOOL)mute;

- (BOOL)start;

- (void)stop;

- (BOOL)snapshot:(NSString *)path;

- (BOOL)startFileRecording:(NSString *)path;

- (BOOL)stopFileRecording;

- (long)getFileRecordingDuration;

- (void)pause;

- (void)resume;

- (void)seek:(long)offsetSec;

- (void)setPlaybackSpeed:(int)speed;

@end
