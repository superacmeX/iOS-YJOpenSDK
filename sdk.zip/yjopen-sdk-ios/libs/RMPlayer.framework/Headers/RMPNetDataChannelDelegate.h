//
//  RMPNetDataChannelDelegate.h
//  rmplayer
//
//  Created by lujiongjian on 2024/7/16.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@protocol RMPNetDataChannelDelegate <NSObject>
@optional

/*!
 @abstract 监听设备上报的属性
*/
- (void)onProperty:(NSString *)property;

/*!
 @abstract 监听设备上报的事件
*/
- (void)onEvent:(NSString *)event;

@end
