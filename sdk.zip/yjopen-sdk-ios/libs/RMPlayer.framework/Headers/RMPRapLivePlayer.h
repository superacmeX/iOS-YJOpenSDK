//
//  RMPRapLivePlayer.h
//  rmplayer
//
//  Created by lujiongjian on 2025/10/2.
//

#import <UIKit/UIKit.h>
#import "RMPlayerStats.h"
#import "RMPlayerDelegate.h"
#import <RMPlayer/RTCVideoSink.h>
#import "LivePlayConfig.h"
#import <RMPlayer/RTCVideoRenderer.h>

RTC_OBJC_EXPORT
@interface RMPRapLivePlayer : NSObject

@property(nonatomic, weak) id<RMPlayerDelegate> _Nullable delegate;

+ (instancetype _Nullable)createWithConfig:(RMPRapPlayerConfig * _Nonnull)config;

/*!
 @abstract 设置渲染远端摄像头视频的窗口
*/
- (void)setVideoView:(id<RTC_OBJC_TYPE(RTCVideoRenderer)> _Nullable)view;

/*!
 @abstract 设置渲染本地摄像头视频的窗口
*/
- (void)setLocalVideoView:(id<RTC_OBJC_TYPE(RTCVideoRenderer)> _Nullable)view;

/*!
 @abstract 通话模式需要配置，直播模式可省略
*/
- (BOOL)configLivePlay:(LivePlayConfig * _Nonnull)config;

/*!
 @abstract 开启本地视频的采集预览画面，使用该接口前需通过configLivePlay 设置 config.audioSend=YES, config.videoSend=YES
 @param position 摄像头方向类型，前置、后置、其他。
*/
- (BOOL)startLocalPreview:(RMPCameraPosition)position;

/*!
 @abstract 停止本地视频采集及预览
*/
- (void)stopLocalPreview;

/*!
 @abstract 切换摄像头
*/
- (BOOL)switchCamera:(RMPCameraPosition)position;

/*!
 @abstract 音频流发送开关
 @param mute YES 暂停， NO 恢复
*/
- (BOOL)muteLocalAudio:(BOOL)mute;

/*!
 @abstract 视频流发送开关
 @param mute YES 暂停， NO 恢复
*/
- (BOOL)muteLocalVideo:(BOOL)mute;

/*!
 @abstract 设置接收视频帧数据的接收器
*/
- (void)setVideoSink:(id<RTC_OBJC_TYPE(RTCVideoSink)> _Nullable)sink;

/*!
 @abstract 远端音频播放的开关
 @param mute YES 暂停， NO 恢复
*/
- (BOOL)muteRemoteAudio:(BOOL)mute;

/*!
 @abstract 开始播放
*/
- (BOOL)start;

/*!
 @abstract 停止播放
*/
- (void)stop;

/*!
 @abstract 获取收发码率、帧率统计
*/
- (RMPlayerStats * _Nullable)getStats;

/*!
 @abstract 截图
 @param path 截图保存的文件，示例：/save/snapshot.jpg
*/
- (BOOL)snapshot:(NSString * _Nonnull)path;

/*!
 @abstract 开始录制本地视频流
 @param path 录制保存的文件，示例：/save/record.mp4
*/
- (BOOL)startFileRecording:(NSString * _Nonnull)path;

/*!
 @abstract 结束录制本地视频流
*/
- (BOOL)stopFileRecording;

/*!
 @abstract 设置获取SEI数据的回调
*/
- (void)setSeiDataCallback:(id<RMPSEIDataDelegate> _Nullable)callback;

/*!
 @abstract 获取录制时长，单位 ms
*/
- (long)getFileRecordingDuration;

/*!
@abstract 开启对讲
*/
- (BOOL)startTalk;

/*!
@abstract 结束对讲
*/
- (void)stopTalk;

/*!
@abstract 对讲状态
*/
- (BOOL)isTalking;

/*!
@abstract 获取播放会话
*/
- (NSString * _Nonnull)getPlaySession;

@end
