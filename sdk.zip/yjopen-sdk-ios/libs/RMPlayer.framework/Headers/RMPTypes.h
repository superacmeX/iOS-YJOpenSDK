//
//  RMPTypes.h
//  rmplayer
//
//  Created by jelin on 2023/10/4.
//

#ifndef RMPTypes_H
#define RMPTypes_H

#import "RMPNetPlayerConfig.h"
#import "RMPRapConfig.h"

#pragma mark - ap link

typedef NS_ENUM(NSInteger, RMPAPLinkStatus) {
    /// 已断开
    RMPAPLinkStatus_Disconnected = 0,
    /// 已连接
    RMPAPLinkStatus_Connected,
    /// 准备
    RMPAPLinkStatus_Standby,
    /// 未知
    RMPAPLinkStatus_Unknow
};

typedef NS_ENUM(NSInteger, RMPAPLinkRecordType) {
    /// 计划记录
    RMPAPLinkRecord_TypePlanRecord = 1,
    /// 报警记录
    RMPAPLinkRecord_TypeAlarmRecord,
    /// 所有记录
    RMPAPLinkRecord_TypeAllRecord,
};


#pragma mark - 日志级别

typedef NS_ENUM(NSInteger, RMPLogLevel) {
    RMPLogLevel_Verbose  = 1,    //详细级别
    RMPLogLevel_Debug    = 2,    //调试级别
    RMPLogLevel_Info     = 3,    //提示级别
    RMPLogLevel_Warn     = 4,    //告警级别
    RMPLogLevel_Error    = 5,    //错误级别
};


#pragma mark - 播放器回调

typedef NS_ENUM(NSInteger, RMPlayerErrorType) {
    RMPlayerErrorType_NoError = 0,
    /// 流错误
    RMPlayerErrorType_StreamError,
    /// 鉴权错误
    RMPlayerErrorType_AuthError,
    /// 解码器错误
    RMPlayerErrorType_DecoderError,
    /// 播放器内部错误
    RMPlayerErrorType_InternalError,
};

typedef NS_ENUM(NSInteger, RMPlayerErrorCode) {
    RMPlayerErrorCode_Success = 0,
    //stream code
    /// 播放流连接错误
    RMPlayerErrorCode_PlayStreamConnectError = 1,
    /// 播放流断开连接
    RMPlayerErrorCode_PlayStreamDisconnect,
    /// 对讲流连接错误
    RMPlayerErrorCode_TalkStreamConnectError,
    /// 对讲流断开连接
    RMPlayerErrorCode_TalkStreamDisconnect,
    /// oss下载错误
    RMPlayerErrorCode_OssDownloadError,
    /// 设备响应播放失败
    RMPlayerErrorCode_DevicePlayRespError,
    /// 设备响应播放超时
    RMPlayerErrorCode_DevicePlayTimeout,
    /// 设备离线
    RMPlayerErrorCode_DeviceOfflineError,
    /// token错误
    RMPlayerErrorCode_AppTokenError,
    /// 请求设备播放错误
    RMPlayerErrorCode_DevicePlayReqError,
    /// 设备无TF卡
    RMPlayerErrorCode_DeviceNoTFCard,
    /// 设备在微信通话中
    RMPlayerErrorCode_DeviceInWeChatCall,
    /// 设备卡录像不存在
    RMPlayerErrorCode_DeviceNoRecord,

    //decoder code
    /// 解码器未初始化
    RMPlayerErrorCode_DecoderNotInitialized = 100,
    /// 解码器参数错误
    RMPlayerErrorCode_DecoderParamError,
    /// 解码器解码错误
    RMPlayerErrorCode_DecoderDecodeError,
    /// 解码器回退到软解码
    RMPlayerErrorCode_DecoderFallbackSoftware,
    /// 创建sdp错误
    RMPlayerErrorCode_CreateSdpError = 200,
    /// 设置sdp错误
    RMPlayerErrorCode_SetSdpError,
};

typedef NS_ENUM(NSInteger, RMPlayerState) {
    /// 已初始化
    RMPlayerState_PlayerInited      = 1,
    /// 已开始
    RMPlayerState_PlayerStarted,
    /// 已暂停
    RMPlayerState_PlayerPaused,
    /// 已停止
    RMPlayerState_PlayerStoped,
    /// 已释放
    RMPlayerState_PlayerReleased,

    /// 内部出错
    RMPlayerState_PlayerErrored     = 8,
    /// 启动中
    RMPlayerState_PlayerStarting    = 9,
    /// 缓冲中
    RMPlayerState_PlayerBuffering   = 10,
};

typedef NS_ENUM(NSInteger, RMPlayerRecordingError) {
    /// Muxer初始化错误
    RMPlayerRecordingError_RecordingMuxerInitError = 1, //recording failed
    /// Muxer结束错误
    RMPlayerRecordingError_RecordingMuxerFinishError,   //recording failed
    /// Muxer写数据包错误
    RMPlayerRecordingError_RecordingWritePacketError,
};

typedef NS_ENUM(NSInteger, RMPlayerSnapshotResult) {
    /// 未知状态
    RMPlayerSnapshotResult_SnapshotUnknown = 0,
    /// 截图成功
    RMPlayerSnapshotResult_SnapshotOk,
    /// 写文件错误
    RMPlayerSnapshotResult_SnapshotWriteFileError,
    /// 压缩jpg错误
    RMPlayerSnapshotResult_SnapshotCompressError,
};

typedef NS_ENUM(NSInteger, RMPlayerTalkState) {
    /// 设备占线
    RMPlayerTalkState_FailDeviceInTalking = -100,
    /// 设备响应错误
    RMPlayerTalkState_FailDeviceRespError,
    /// 请求设备超时
    RMPlayerTalkState_FailRequestTimeout,
    /// 与设备断开
    RMPlayerTalkState_FailDisconnect,

    /// 未知状态
    RMPlayerTalkState_Unknown = 0,
    /// 对讲开始
    RMPlayerTalkState_Started,
    /// 对讲结束
    RMPlayerTalkState_Ended,

    /// 等待接听
    RMPlayerTalkState_DeviceWaitingAnswer,
    /// 超时未接听
    RMPlayerTalkState_DeviceNoAnswer,
    /// 拒绝接听
    RMPlayerTalkState_DeviceRefuseAnswer,
    /// 挂断
    RMPlayerTalkState_DeviceHangUp,
    /// 设备已接听
    RMPlayerTalkState_DeviceAnswered,
    /// 设备打开摄像头通知
    RMPlayerTalkState_DeviceUnmuteVideo,
    /// 设备关闭摄像头通知
    RMPlayerTalkState_DeviceMuteVideo,
};

typedef NS_ENUM(NSInteger, RMPlayerBufferState) {
    /// 加载中
    RMPlayerBufferState_Loading = 1,
    /// 加载完成
    RMPlayerBufferState_Ready,
};


#pragma mark - 云存播放模式

typedef NS_ENUM(NSInteger, RMPNetCloudVodPlayMode) {
    /// 播放所有视频，包括前卷和普通视频
    RMPNetCloudVodPlayMode_All      = 0,
    /// 只播放普通视频
    RMPNetCloudVodPlayMode_Normal,
    /// 只播放前卷视频
    RMPNetCloudVodPlayMode_Preroll,
};


#pragma mark - 区域/环境(deprecated)

typedef NS_ENUM(NSInteger, RMPConfigRegion) {
    RMPConfigRegion_cn = 0,
    RMPConfigRegion_us,
    RMPConfigRegion_us_aws,
    RMPConfigRegion_jp_aws,
    RMPConfigRegion_us_sensforge,
    RMPConfigRegion_max,
};

typedef NS_ENUM(NSInteger, RMPConfigEnv) {
    RMPConfigEnv_dev = 0,
    RMPConfigEnv_test,
    RMPConfigEnv_pre,
    RMPConfigEnv_prod,
    RMPConfigEnv_max,
};

#pragma mark - 区域/环境

typedef NS_ENUM(NSInteger, RMPRegion) {
    RMPRegion_Unknown = 0,
    RMPRegion_CN,
    RMPRegion_US,
    RMPRegion_Max,
};

typedef NS_ENUM(NSInteger, RMPEnv) {
    RMPEnv_Unknown = 0,
    RMPEnv_Dev,
    RMPEnv_Test,
    RMPEnv_Pre,
    RMPEnv_Prod,
    RMPEnv_Max,
};

#pragma mark - 云存下载

typedef NS_ENUM(NSInteger, RMPNetCloudVodDownloaderError) {
    /// 下载超时
    RMPNetCloudVodDownloader_Timeout = 1,
    /// 下载失败
    RMPNetCloudVodDownloader_Failed,
    /// 加载资源失败
    RMPNetCloudVodDownloader_LoadSourceError,
    /// token失效
    RMPNetCloudVodDownloader_InvalidToken,
};

#pragma mark - 通用下载

typedef NS_ENUM(NSInteger, RMPMonoDownloadErrorCode) {
  //mapping to source error
  RMPMonoDownloadErrorCode_None         = 0,
  RMPMonoDownloadErrorCode_Param        = 1,
  RMPMonoDownloadErrorCode_Connect      = 2,
  RMPMonoDownloadErrorCode_Disconnect   = 3,
  RMPMonoDownloadErrorCode_Timeout      = 4,
  RMPMonoDownloadErrorCode_Token        = 5,

  RMPMonoDownloadErrorCode_Unknown      = 20,

  //error when writing mp4
  RMPMonoDownloadErrorCode_MuxError     = 21,
  RMPMonoDownloadErrorCode_StateError   = 22,
};

#pragma mark - 文件下载

typedef NS_ENUM(NSInteger, RMPDownloadState) {
    /// 等待中
    RMPDownloadState_Pending        = 0,
    /// 下载中
    RMPDownloadState_Downloading,
    /// 已暂停
    RMPDownloadState_Paused,
    /// 已完成
    RMPDownloadState_Completed,
    /// 失败
    RMPDownloadState_Failed,
};

#pragma mark - net 数据通道(废弃)

typedef NS_ENUM(NSInteger, RMPNetDataChannelError) {
    /// 请求超时
    RMPNetDataChannelError_Timeout = 1,
};

/// 返回数据通道请求成功响应的内容
typedef void (^RMPNetResponse)(NSString * _Nonnull payload);

/// 返回数据通道请求错误状态
typedef void (^RMPNetRequestStatus)(RMPNetDataChannelError code, NSString * _Nonnull desc);

#pragma mark - 公共 数据通道

typedef NS_ENUM(NSInteger, RMPDataChannelState) {
    /// 请求失败
    RMPDataChannelState_RequestFailed = -1,
    /// 响应超时
    RMPDataChannelState_ResponseTimeout = 1,
    /// 响应成功
    RMPDataChannelState_ResponseOk = 200,
};

/// 返回数据通道请求成功响应的内容
typedef void (^RMPResponse)(NSString * _Nullable payload, RMPDataChannelState code, NSString * _Nonnull desc);

#pragma mark - 手机摄像头方向

typedef NS_ENUM(NSInteger, RMPCameraPosition) {
    /// 后置
    RMPCameraPositionBack        = 1, //后置
    /// 前置
    RMPCameraPositionFront       = 2, //前置
};

#pragma mark - 多通道

typedef NS_ENUM(int, RMPMultiChl) {
    /// 默认通道 id
    RMPMultiChl_DefaultChannelId = -1,
};

#pragma mark - 录像场景

typedef NS_ENUM(NSInteger, RMPVodScenario) {
    RMPVodScenario_Default              = 0,
    RMPVodScenario_ScenarioVlog,
    RMPVodScenario_ScenarioMonitor,
    RMPVodScenario_ScenarioMax,
};

#pragma mark - Link type

typedef NS_ENUM(int, RMPLinkType) {
    RMPLinkType_Unknown      = 0,
    RMPLinkType_Rap,
};

typedef void (^RMPLinkTypeResult)(RMPLinkType type);

#endif //RMPTypes_H
