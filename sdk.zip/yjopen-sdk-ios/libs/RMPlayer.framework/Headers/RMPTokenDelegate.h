//
//  RMPTokenDelegate.h
//  rmplayer
//
//  Created by lujiongjian on 2024/11/28.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"
#import "RMPTokenError.h"

RTC_OBJC_EXPORT
@protocol RMPTokenDelegate <NSObject>
@optional

/*!
 @abstract token异常会回调此接口
*/
- (void)onTokenInvalid:(RMPTokenError *)error;

@end
