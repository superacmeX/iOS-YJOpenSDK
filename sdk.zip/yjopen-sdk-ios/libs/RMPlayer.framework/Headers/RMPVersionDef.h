//
//  RMPVersionDef.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/01.
//

#ifndef RMP_VERSION_DEF_H
#define RMP_VERSION_DEF_H

#define RMPLAYER_VERSION            @"v2.5.0-kcp_file_download.1_release"

#define RMPLAYER_GIT_SHORT_HEAD     @"11da6d86"

#define RMPLAYER_BUILD_TIME         @"20260106"

#endif //RMP_VERSION_DEF_H
