//
//  RMPConfig.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/29.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@interface RMPConfig : NSObject

/*!
 @abstract 设置区域/环境类型接口
 @param region 区域
 @param env 环境
*/
+ (int)setBootConfigRegion:(RMPConfigRegion)region configEnv:(RMPConfigEnv)env;

/*!
 @abstract 获取区域类型
*/
+ (RMPConfigRegion)getRegion;

/*!
 @abstract 获取环境类型
*/
+ (RMPConfigEnv)getEnv;

@end
