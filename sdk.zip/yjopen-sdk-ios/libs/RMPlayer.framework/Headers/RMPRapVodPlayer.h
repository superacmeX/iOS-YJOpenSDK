//
//  RMPRapVodPlayer.h
//  rmplayer
//
//  Created by lujiongjian on 2025/10/2.
//

#import <UIKit/UIKit.h>
#import "RMPlayerStats.h"
#import "RMPlayerDelegate.h"
#import <RMPlayer/RTCVideoRenderer.h>

RTC_OBJC_EXPORT
@interface RMPRapVodPlayer : NSObject

@property(nonatomic, weak) id<RMPlayerDelegate> _Nullable delegate;

+ (instancetype _Nullable)createWithConfig:(RMPRapPlayerConfig * _Nonnull)config;

/*!
 @abstract 设置渲染远端摄像头视频的窗口
*/
- (void)setVideoView:(id<RTC_OBJC_TYPE(RTCVideoRenderer)> _Nullable)view;

- (BOOL)setRangeStartSec:(long)startSec endSec:(long)endSec seekSec:(long)seekSec;

- (BOOL)muteRemoteAudio:(BOOL)mute;

- (BOOL)start;

- (void)stop;

- (RMPlayerStats * _Nullable)getStats;

- (BOOL)snapshot:(NSString * _Nonnull)path;

- (BOOL)startFileRecording:(NSString * _Nonnull)path;

- (BOOL)stopFileRecording;

- (void)setSeiDataCallback:(id<RMPSEIDataDelegate> _Nullable)callback;

- (long)getFileRecordingDuration;

- (void)pause;

- (void)resume;

- (void)seek:(long)offsetSec;

- (void)setPlaybackSpeed:(int)speed;

/*!
 @abstract 根据录像类型播放，参数均透传给设备
 @param startSec 起始时间
 @param type 录像类型
 @param seekSec 偏移时间
*/
- (BOOL)setRecordStartSec:(long)startSec type:(int)type seekSec:(long)seekSec;

/*!
 @abstract 使用setRecordStartSec后，可通过该接口获取录像时长，设备未返回duration时，该接口返回默认值-1
*/
- (long)getTotalDuration;

/*!
@abstract 获取播放会话
*/
- (NSString * _Nonnull)getPlaySession;

- (BOOL)setRecordFile:(NSString * _Nonnull)file seekSec:(long)seekSec;

@end
