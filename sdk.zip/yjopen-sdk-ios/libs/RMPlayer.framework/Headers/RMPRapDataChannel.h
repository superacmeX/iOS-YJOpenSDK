//
//  RMPRapDataChannel.h
//  rmplayer
//
//  Created by lujiongjian on 2025/10/16.
//

#import <Foundation/Foundation.h>
#import "RMPTypes.h"
#import "RMPRequest.h"
#import "RMPDataChannelDelegate.h"

RTC_OBJC_EXPORT
@interface RMPRapDataChannel : NSObject

@property(nonatomic, weak) id<RMPDataChannelDelegate> _Nullable delegate;

/*!
 @abstract 创建一个通道实例，非单例
*/
+ (instancetype _Nullable)createWithConfig:(RMPRapConfig * _Nonnull)config;

/*!
 @abstract 返回链接状态
*/
- (BOOL)isConnected;

/*!
 @abstract 发送请求，接收响应。结果通过 RMPResponse 返回。
*/
- (void)sendRequest:(RMPRequest * _Nonnull)request
         onResponse:(RMPResponse _Nullable)response;

/*!
 @abstract 订阅所有属性
*/
- (BOOL)subscribeProperty;

/*!
 @abstract 取消订阅所有属性
*/
- (BOOL)unsubscribeProperty;

/*!
 @abstract 订阅事件
 @param eventIds 事件id数组
*/
- (BOOL)subscribeEvents:(NSArray<NSString * > * _Nonnull)eventIds;

/*!
 @abstract 取消订阅事件
 @param eventIds 事件id数组
*/
- (BOOL)unsubscribeEvents:(NSArray<NSString *> * _Nonnull)eventIds;

/*!
 @abstract 订阅所有事件
*/
- (BOOL)subscribeAllEvents;

/*!
 @abstract 取消订阅所有事件
*/
- (BOOL)unsubscribeAllEvents;

@end
