//
//  RMPNetVodSource.h
//  rmplayer
//
//  Created by lujiongjian on 2025/7/1.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPMediaSource.h"
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@interface RMPNetVodSource : RMPMediaSource

+ (instancetype)createWithConfig:(RMPNetConfig *)config;

- (void)setChannelId:(int)channelId;

- (void)setRangeStartSec:(long)startSec endSec:(long)endSec;

@end
