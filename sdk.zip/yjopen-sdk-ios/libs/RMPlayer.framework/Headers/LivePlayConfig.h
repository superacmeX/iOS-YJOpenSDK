//
//  LivePlayConfig.h
//  rmplayer
//
//  Created by lujiongjian on 2024/7/29.
//

#import <Foundation/Foundation.h>
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@interface LivePlayConfig : NSObject

/*!
 @abstract 是否发送视频，默认NO
*/
@property (nonatomic, assign) BOOL videoSend;

/*!
 @abstract 是否接收视频，默认YES
*/
@property (nonatomic, assign) BOOL videoRecv;

/*!
 @abstract 是否发送音频，默认NO
*/
@property (nonatomic, assign) BOOL audioSend;

/*!
 @abstract 是否接收音频，默认YES
*/
@property (nonatomic, assign) BOOL audioRecv;

/*!
 @abstract 采集分辨率，默认640x480
*/
@property (nonatomic, assign) CGSize videoCaptureResolution;

/*!
 @abstract 采集帧率，默认10fps
*/
@property (nonatomic, assign) int videoCaptureFps;

/*!
 @abstract 发送分辨率，默认240x320
*/
@property (nonatomic, assign) CGSize videoSendResolution;

/*!
 @abstract 是否走直播模式，默认NO
*/
@property (nonatomic, assign) BOOL liveMode;

/*!
 @abstract 用户id，默认空字符串
*/
@property (nonatomic, copy) NSString *userId;

/*!
 @abstract 输出属性内容
*/
- (NSString *)toString;

@end
