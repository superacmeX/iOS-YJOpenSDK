//
//  RMPApVodSource.h
//  rmplayer
//
//  Created by lujiongjian on 2025/8/15.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPMediaSource.h"
#import "RMPTypes.h"
#import "RMPApConfig.h"

RTC_OBJC_EXPORT
@interface RMPApVodSource : RMPMediaSource

+ (instancetype)createWithConfig:(RMPApConfig *)config;

- (void)setRangeStartSec:(long)startSec endSec:(long)endSec;

@end
