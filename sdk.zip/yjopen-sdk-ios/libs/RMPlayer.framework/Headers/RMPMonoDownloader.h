//
//  RMPMonoDownloader.h
//  rmplayer
//
//  Created by lujiongjian on 2025/7/1.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPMediaSource.h"
#import "RMPMonoDownloadProgress.h"
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@protocol RMPMonoDownloaderDelegate <NSObject>
@optional
- (void)downloader:(id)downloader onError:(RMPMonoDownloadErrorCode)error desc:(NSString *)desc;

- (void)downloader:(id)downloader onProgress:(RMPMonoDownloadProgress *)progress;

- (void)downloader:(id)downloader onFinish:(NSArray<NSString *> *)files;

@end

RTC_OBJC_EXPORT
@interface RMPMonoDownloader : NSObject

+ (instancetype)createWithMediaSource:(RMPMediaSource *)mediaSource delegate:(id<RMPMonoDownloaderDelegate>)delegate;

- (BOOL)setOutputFile:(NSString *)file;

- (BOOL)start;

- (void)stop;

@end
