//
//  RMPEngine.h
//  rmplayer
//
//  Created by lujiongjian on 2024/11/28.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"
#import "RMPTokenDelegate.h"

RTC_OBJC_EXPORT
@interface RMPEngine : NSObject

/*!
 @abstract 设置token回调
*/
@property(nonatomic, weak) id<RMPTokenDelegate> delegate;

/*!
 @abstract 获取单例
*/
+ (instancetype)instance;

- (instancetype)init NS_UNAVAILABLE;

/*!
 @abstract 更新token
*/
- (void)updateToken:(NSString *)token;

@end
