//
//  RMPlayerDelegate.h
//  rmplayer
//
//  Created by lujiongjian on 2024/01/18.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@protocol RMPSEIDataDelegate <NSObject>
@optional
/*!
 @abstract 单目播放器 RMPNetLivePlayer/RMPNetVodPlayer 时，channelId 的值未定义
           多目播放器 RMPNetMultiChlLivePlayer/RMPNetMultiChlVodPlayer 时，channelId 的值为设备对应摄像头的id
*/
- (void)player:(id)player onSeiData:(NSData *)data pts:(long)pts channelId:(int)channelId;
@end

RTC_OBJC_EXPORT
@protocol RMPlayerDelegate <NSObject>
@optional
- (void)player:(id)player onError:(RMPlayerErrorType)type playErrorCode:(RMPlayerErrorCode)code playErrorDesc:(NSString *)desc;

- (void)player:(id)player onPlayerStateChange:(RMPlayerState)state;

- (void)player:(id)player onTalkStateChange:(RMPlayerTalkState)state;

- (void)player:(id)player onPlaybackSpeedUpdate:(int)speed;

- (void)player:(id)player onSeekComplete:(BOOL)success;

/*!
 @abstract buffer状态改变回调。超过 3s 无帧播放, 回调 Loading 状态, 恢复回调 Ready 状态
 @param state RMPlayerBufferState
 @param bufferDurationMillis 状态改变的时间点的buffer长度，单位毫秒。 返回 -1 表示buffer长度未知，因为可能未拿到数据。
*/
- (void)player:(id)player onBufferStateUpdate:(RMPlayerBufferState)state bufferDurationMillis:(NSInteger)bufferDurationMillis;

/*!
 @abstract 使用 setVideoView 的方式设置渲染view到播放器，渲染首帧时会触发该接口回调
*/
- (void)player:(id)player onFirstFrameRendered:(NSInteger)elapseMills;

/*!
 @abstract 单目播放器 RMPNetLivePlayer/RMPNetVodPlayer 时，channelId 的值未定义
           多目播放器 RMPNetMultiChlLivePlayer/RMPNetMultiChlVodPlayer 时，channelId 的值为设备对应摄像头的id
*/
- (void)player:(id)player onVideoSizeChanged:(CGSize)size channelId:(int)channelId;

- (void)player:(id)player onFileRecordingStart:(NSString *)file;

- (void)player:(id)player onFileRecordingError:(NSString *)file recordErrorCode:(RMPlayerRecordingError)code recordErrorDesc:(NSString *)desc;

- (void)player:(id)player onFileRecordingFinish:(NSString *)file;

- (void)player:(id)player onSnapshotResult:(NSString *)file snapErrorCode:(RMPlayerSnapshotResult)code snapErrorDesc:(NSString *)desc;

- (void)player:(id)player onVodPlayProgress:(NSInteger)millis;

- (void)player:(id)player onVodPlayComplete:(BOOL)completed;

@end
