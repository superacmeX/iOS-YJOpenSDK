//
//  RMPRapVodSource.h
//  rmplayer
//
//  Created by lujiongjian on 2025/10/2.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPMediaSource.h"
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@interface RMPRapVodSource : RMPMediaSource

+ (instancetype _Nullable)createWithConfig:(RMPRapConfig * _Nonnull)config;

- (void)setChannelId:(int)channelId;

- (void)setRangeStartSec:(long)startSec endSec:(long)endSec;

@end
