//
//  YJBLEReceiveDataUtil.h
//  YJOpenSDK
//
//  Created by zhu shuaishuai on 2024/11/8.
//  蓝牙接收数据助手

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YJBLEReceiveDataUtil : NSObject

/// 转换收到的数据
/// - Parameter data: 转换后的json数据
- (nullable NSDictionary *)transformReceiveData: (NSData *)data;

@end

NS_ASSUME_NONNULL_END
