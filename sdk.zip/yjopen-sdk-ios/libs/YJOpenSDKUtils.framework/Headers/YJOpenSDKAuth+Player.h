//
//  YJOpenSDKAuth+Player.h
//  YJOpenSDK
//
//  Created by wzy on 2024/12/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YJOpenSDKAuth_Player : NSObject

@property (nonatomic, copy) void (^onError)(void);

+ (YJOpenSDKAuth_Player *)sharedInstance;

- (void)setup;

- (void)updateToken:(NSString * _Nullable)token;

@end

NS_ASSUME_NONNULL_END
