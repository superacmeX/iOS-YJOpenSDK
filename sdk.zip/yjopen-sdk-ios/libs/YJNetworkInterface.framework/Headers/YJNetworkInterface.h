//
//  YJNetworkInterface.h
//  YJNetworkInterface
//
//  Created by wzy on 2025/1/22.
//

#import <Foundation/Foundation.h>

//! Project version number for YJNetworkInterface.
FOUNDATION_EXPORT double YJNetworkInterfaceVersionNumber;

//! Project version string for YJNetworkInterface.
FOUNDATION_EXPORT const unsigned char YJNetworkInterfaceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YJNetworkInterface/PublicHeader.h>


