//
//  YJPermissions.h
//  YJPermissions
//
//  Created by wzy on 2025/4/17.
//

#import <Foundation/Foundation.h>

//! Project version number for YJPermissions.
FOUNDATION_EXPORT double YJPermissionsVersionNumber;

//! Project version string for YJPermissions.
FOUNDATION_EXPORT const unsigned char YJPermissionsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YJPermissions/PublicHeader.h>


