//
//  YJOpenSDKAuth+Player.h
//  YJOpenSDK
//
//  Created by wzy on 2024/12/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, YJOpenSDKAuthPlayerEnv) {
    YJOpenSDKAuthPlayerEnvTest = 1,
    YJOpenSDKAuthPlayerEnvProduct = 3,
    YJOpenSDKAuthPlayerEnvMax
};

typedef NS_ENUM(NSInteger, YJOpenSDKAuthPlayerRegion) {
    YJOpenSDKAuthPlayerRegionCN = 0,
    YJOpenSDKAuthPlayerRegionUS = 1,
    YJOpenSDKAuthPlayerRegionUSAWS = 2,
    YJOpenSDKAuthPlayerRegionJPAWS = 3,
    YJOpenSDKAuthPlayerRegionMax
};

@interface YJOpenSDKAuth_Player : NSObject
@property YJOpenSDKAuthPlayerRegion region;
@property YJOpenSDKAuthPlayerEnv playerEnv;

@property (nonatomic, copy) void (^onError)(void);

+ (YJOpenSDKAuth_Player *)sharedInstance;

- (void)setup:(YJOpenSDKAuthPlayerEnv)env;

- (void)updateToken:(NSString * _Nullable)token;

@end

NS_ASSUME_NONNULL_END
