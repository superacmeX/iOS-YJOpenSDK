//
//  RMPNetworkManager.h
//  rmplayer
//
//  Created by lujiongjian on 2025/12/1.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>

typedef void (^RMPNetworkResult)(NSError * _Nullable error);

RTC_OBJC_EXPORT
@interface RMPNetworkManager : NSObject

/*!
 @abstract 获取单例
*/
+ (RMPNetworkManager * _Nonnull)sharedInstance;

/*!
 @abstract 检测设备Wi-Fi是否可用
 @param timeoutMs 设置超时时间，单位毫秒
 @param result 结果回调
 @return 成功返回 0
*/
- (int)checkWiFiReady:(int)timeoutMs withResult:(RMPNetworkResult _Nullable)result;

@end
