//
//  RMPApLivePlayer.h
//  rmplayer
//
//  Created by jelin on 2023/9/16.
//

#import <UIKit/UIKit.h>
#import "RMPlayerDelegate.h"
#import <RMPlayer/RTCVideoRenderer.h>

RTC_OBJC_EXPORT
@interface RMPApLivePlayer : NSObject

@property(nonatomic, weak) id<RMPlayerDelegate> delegate;

- (UIView *)playerView;

/*!
 @abstract 设置渲染远端摄像头视频的窗口
*/
- (void)setVideoView:(id<RTC_OBJC_TYPE(RTCVideoRenderer)>)view;

- (BOOL)muteRemoteAudio:(BOOL)mute;

- (BOOL)start;

- (void)stop;

- (BOOL)snapshot:(NSString *)path;

- (BOOL)startFileRecording:(NSString *)path;

- (BOOL)stopFileRecording;

- (long)getFileRecordingDuration;

- (BOOL)startTalk;

- (void)stopTalk;

/*!
 @abstract 设置获取SEI数据的回调
*/
- (void)setSeiDataCallback:(id<RMPSEIDataDelegate>)callback;

@end
