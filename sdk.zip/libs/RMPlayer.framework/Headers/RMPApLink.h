//
//  RMPApLink.h
//  rmplayer
//
//  Created by jelin on 2023/9/16.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"
#import "RMPRecordItem.h"
#import "RMPApLinkResponse.h"
#import "RMPEngine.h"

typedef void (^RMPApLinkConnectedResultBlock)(int code);
typedef void (^RMPApLinkDisconnectedResultBlock)(void);

@class RMPApLink;

RTC_OBJC_EXPORT
@protocol RMPApLinkDelegate <NSObject>
@required
- (void)linkState:(RMPAPLinkStatus)status;
- (void)propertyPost:(NSData *)payload;
- (void)eventPost:(NSData *)eventId payload:(NSData *)payload;
- (void)recordPost:(NSArray *)record pageNo:(int)pageNo pageTotal:(int)pageTotal queryId:(uint32_t)queryId;
@optional
- (void)logFile:(int)seq totalSeq:(int)totalSeq payload:(NSData *)payload;

@end

RTC_OBJC_EXPORT
@interface RMPApLink : NSObject

@property (nonatomic, weak) id<RMPApLinkDelegate> delegate;

@property (nonatomic, strong) RMPEngine *engine;

+ (instancetype)sharedInstance;
/*
 *@breif init link sdk ,only call once
 *@param[in] localIP-0.0.0.0 or detail ip;mobileID-uuid
 *@return 0-ok ;<0-failure
 */
- (int)initSDK:(NSString *)localIP mobileID:(NSString *)mobileID;

/*!
 @abstract 检测Link类型，异步接口
 @param timeout 超时时间，单位秒
 @param result 检测结果返回
 @return 接口调用成功返回 0
*/
- (int)checkLinkType:(long)timeout withResult:(RMPLinkTypeResult)result;

/*!
 @abstract connect device接口，异步
 @param peerIP 设备ip, default ip is 192.168.43.1
 @param peerPort 设备port, default peerPort-6684
 @param block 接口结果返回, 0-ok;  <0-failure
*/
- (void)connect:(NSString *)peerIP peerPort:(int)peerPort withResult:(RMPApLinkConnectedResultBlock)block;
/*!
 @abstract disconnect device接口，异步
 @param block 接口执行结束会回调block
*/
- (void)disconnectWithResult:(RMPApLinkDisconnectedResultBlock)block;
/*
 *@brief destroy link sdk resource;only call once
 */
- (void)finiSDK;

- (int)queryRecord:(int)startSec endSec:(int)endSec type:(RMPAPLinkRecordType)type pageNo:(int)pageNo pageSize:(int)pageSize;

- (int)postService:(char *)serviceId serviceLen:(int)serviceLen payload:(char *)payload payloadLen:(int)payloadLen response:(char *)response responseLen:(int *)responseLen;

- (RMPApLinkResponse *)postService:(NSString *)serviceId payload:(NSString *)payload;

- (int)setProperty:(char *)payload payloadLen:(int)payloadLen;

- (int)setProperty:(NSString *)payload;
/**
 *@brief queryrecord by month
 *@param[in] month-eg:202310
 *@return RMPApLinkResponse- response char数组，长度为31,每项值 0 - 无录像，1 - 有录像
 */
- (RMPApLinkResponse *)queryRecordWith:(NSString *)month;

@end
