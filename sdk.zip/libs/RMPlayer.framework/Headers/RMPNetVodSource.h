//
//  RMPNetVodSource.h
//  rmplayer
//
//  Created by lujiongjian on 2025/7/1.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPMediaSource.h"
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@interface RMPNetVodSource : RMPMediaSource

+ (instancetype _Nullable)createWithConfig:(RMPNetConfig  * _Nonnull )config;

/// 多目摄像头设置需要下载录像的通道
- (void)setChannelId:(int)channelId;

/// 设置卡录像时间范围，单位秒
- (void)setRangeStartSec:(long)startSec endSec:(long)endSec;

@end
