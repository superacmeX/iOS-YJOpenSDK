//
//  RMPRequest.h
//  rmplayer
//
//  Created by lujiongjian on 2025/10/16.
//

#import <Foundation/Foundation.h>
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@interface RMPRequest : NSObject

/*!
 @abstract 通道号，不填默认0
*/
@property (nonatomic, assign) int channelId;

/*!
 @abstract 发送请求的内容，json字符串
*/
@property (nonatomic, copy) NSString * _Nullable payload;

/*!
 @abstract 单位毫秒，不设置默认超时15,000 ms
*/
@property (nonatomic, assign) NSInteger timeoutMillis;

@end

RTC_OBJC_EXPORT
@interface RMPPostService : RMPRequest

/*!
 @abstract 例如: PTZ
*/
@property (nonatomic, copy) NSString * _Nullable serviceId;

@end

RTC_OBJC_EXPORT
@interface RMPGetProperty : RMPRequest

@property (nonatomic, copy) NSString * _Nullable propertyId;

@end

RTC_OBJC_EXPORT
@interface RMPSetProperty : RMPRequest
@end
