//
//  RMPNetRequest.h
//  rmplayer
//
//  Created by lujiongjian on 2024/7/16.
//

#import <Foundation/Foundation.h>
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@interface RMPNetRequest : NSObject

/*!
 @abstract 发送请求的内容
*/
@property (nonatomic, copy) NSString *payload;

/*!
 @abstract 例如: PTZ
*/
@property (nonatomic, copy) NSString *serviceId;

/*!
 @abstract 单位毫秒，不设置默认超时15,000 ms
*/
@property (nonatomic, assign) NSInteger timeoutMillis;

@end
