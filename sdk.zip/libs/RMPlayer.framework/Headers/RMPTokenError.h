//
//  RMPTokenError.h
//  rmplayer
//
//  Created by lujiongjian on 2024/11/28.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@interface RMPTokenError : NSObject

/*!
 @abstract 错误码
*/
@property (nonatomic, assign) int code;

/*!
 @abstract 失效的token
*/
@property (nonatomic, copy) NSString *token;

/*!
 @abstract 产品类型
*/
@property (nonatomic, copy) NSString *productKey;

/*!
 @abstract 设备名
*/
@property (nonatomic, copy) NSString *deviceName;

/*!
 @abstract 输出属性内容
*/
- (NSString *)toString;

@end
