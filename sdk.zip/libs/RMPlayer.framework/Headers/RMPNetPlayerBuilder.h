//
//  RMPNetPlayerBuilder.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/29.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@interface RMPNetPlayerBuilder : NSObject

/*!
 @abstract 播放器预加载，需要保证在设置环境后，即 [RMPConfig setBootConfigRegion: configEnv:] 后调用
*/
+ (void)preload:(RMPNetConfig *)config;

@end
