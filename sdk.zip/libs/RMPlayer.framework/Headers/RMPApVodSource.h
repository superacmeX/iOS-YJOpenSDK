//
//  RMPApVodSource.h
//  rmplayer
//
//  Created by lujiongjian on 2025/8/15.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPMediaSource.h"
#import "RMPTypes.h"
#import "RMPApConfig.h"

RTC_OBJC_EXPORT
@interface RMPApVodSource : RMPMediaSource

+ (instancetype _Nullable)createWithConfig:(RMPApConfig  * _Nonnull )config;

/// 设置卡录像时间范围，单位秒
- (void)setRangeStartSec:(long)startSec endSec:(long)endSec;

@end
