//
//  RMPRapConfig.h
//  rmplayer
//
//  Created by lujiongjian on 2025/10/2.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPRapDeviceParams.h"

@class RMPEngine;
RTC_OBJC_EXPORT
@interface RMPRapConfig : NSObject

/// 设备名
@property(nonatomic, copy) NSString * _Nullable deviceName;

/// 产品识别码
@property(nonatomic, copy) NSString * _Nullable productKey;

/// 设备热点 ip，默认192.168.43.1
@property(nonatomic, copy) NSString * _Nonnull ip;

/// 设备热点端口，默认1883
@property(nonatomic, assign) int port;

/// 播放器创建所需引擎，外部必须赋值
@property(nonatomic, strong) RMPEngine * _Nullable engine;

@property(nonatomic, strong) RMPRapDeviceParams * _Nullable params;

@end

RTC_OBJC_EXPORT
@interface RMPRapPlayerConfig : RMPRapConfig

/// 多目摄像头需要设置，单目不需要设置
@property(nonatomic, strong) NSArray<NSNumber *> * _Nullable channelIds;

@end
