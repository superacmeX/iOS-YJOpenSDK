//
//  RMPVersion.h
//  rmplayer
//
//  Created by jelin on 2023/10/21.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>

RTC_OBJC_EXPORT
@interface RMPVersionMgr : NSObject

+ (NSString*)playerSDKVersion;

+ (NSString*)linkSDKVersion;

@end
