//
//  RMPNetCloudVodPlayer.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/9.
//

#import <UIKit/UIKit.h>
#import "RMPlayerStats.h"
#import "RMPlayerDelegate.h"
#import <RMPlayer/RTCVideoRenderer.h>

RTC_OBJC_EXPORT
@interface RMPNetCloudVodPlayer : NSObject

@property(nonatomic, weak) id<RMPlayerDelegate> delegate;

+ (instancetype)createWithConfig:(RMPNetPlayerConfig *)config;

- (UIView *)playerView;

/*!
 @abstract 设置渲染远端摄像头视频的窗口
*/
- (void)setVideoView:(id<RTC_OBJC_TYPE(RTCVideoRenderer)>)view;

- (BOOL)setCloudSource:(NSString *)url meta:(NSString *)meta mode:(RMPNetCloudVodPlayMode)mode;

- (BOOL)appendCouldPlaylist:(NSString *)url meta:(NSString *)meta;

- (long)getTotalDuration;

- (BOOL)muteRemoteAudio:(BOOL)mute;

- (BOOL)start;

- (void)stop;

- (void)pause;

- (void)resume;

- (void)seek:(long)offsetSec;

/*!
@abstract 获取播放会话
*/
- (NSString *)getPlaySession;

@end
