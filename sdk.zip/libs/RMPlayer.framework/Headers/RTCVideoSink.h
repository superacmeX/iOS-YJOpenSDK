/*
 * RTCVideoSink.h
 *
 *  Created on: Jul 24, 2024
 *      Author: ljj
 */

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>

NS_ASSUME_NONNULL_BEGIN

@class RTC_OBJC_TYPE(RTCVideoFrame);

RTC_OBJC_EXPORT
@protocol RTC_OBJC_TYPE
(RTCVideoSink)<NSObject>

/** The frame to be received. */
- (void)onFrame:(nullable RTC_OBJC_TYPE(RTCVideoFrame) *)frame;

@end

NS_ASSUME_NONNULL_END
