//
//  RMPEngine.h
//  rmplayer
//
//  Created by lujiongjian on 2024/11/28.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"
#import "RMPTokenDelegate.h"

RTC_OBJC_EXPORT
@interface RMPEngine : NSObject

/*!
 @abstract 设置token回调
*/
@property(nonatomic, weak) id<RMPTokenDelegate> delegate;

/*!
 @abstract 获取默认engine
*/
+ (instancetype)getDefault;

- (instancetype)init NS_UNAVAILABLE;

/*!
 @abstract 设置初始化引擎必要参数
 @param host 基础服务api域名
 @param region 区域
 @param env 环境
 @param businessTag 业务区分，比如填appKey
*/
- (void)setAPIHost:(NSString *)host region:(RMPRegion)region env:(RMPEnv)env businessTag:(NSString *)appKey;

/*!
 @abstract 执行引擎初始化，调用该接口前，必须设置初始化引擎必要参数及设置delegate
 */
- (BOOL)initialized;

/*!
 @abstract 查看引擎状态
 */
- (BOOL)isInited;

/*!
 @abstract 更新token
*/
- (void)updateToken:(NSString *)token;

@end
