//
//  RMPApConfig.h
//  rmplayer
//
//  Created by lujiongjian on 2025/8/15.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>

@class RMPApLink;
RTC_OBJC_EXPORT
@interface RMPApConfig : NSObject

@property(nonatomic, strong) RMPApLink *link;

@end
