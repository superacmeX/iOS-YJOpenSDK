//
//  RMPlayerStats.h
//  rmplayer
//
//  Created by lujiongjian on 2023/12/22.
//


#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>

RTC_OBJC_EXPORT
@interface RMPlayerStats : NSObject

/*!
 @abstract 帧率
*/
@property (nonatomic, assign) int fps;

/*!
 @abstract 每秒接收字节数
*/
@property (nonatomic, assign) int recv_bytes_per_sec;

/*!
 @abstract 每秒发送字节数
*/
@property (nonatomic, assign) int send_bytes_per_sec;

@end
