//
//  RMPNetDeviceParams.h
//  rmplayer
//
//  Created by lujiongjian on 2025/9/3.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@interface RMPNetDeviceParams : NSObject

/*!
 @abstract 是否开启MP4录像保留H264 SEI，默认NO
 */
@property (nonatomic, assign) BOOL standardH264SEI;

/*!
 @abstract 码流类型，0 主码流，1子码流，可选，如果不设置，设备侧默认1
 */
@property (nonatomic, assign) int encodeStreamType;

/*!
 @abstract 设置录像场景，可选，如果不设置，设备侧默认Default（即所有录像）
 */
@property (nonatomic, assign) RMPVodScenario scenario;

@end

