//
//  RMPDownloadManager.h
//  rmplayer
//
//  Created by lujiongjian on 2025/9/22.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"
#import "RMPApLink.h"

RTC_OBJC_EXPORT
@interface RMPDownloadTaskInfo : NSObject

@property (nonatomic, copy)     NSString * _Nonnull taskId;           // 任务ID
@property (nonatomic, copy)     NSString * _Nonnull remoteFile;       // 远程文件路径
@property (nonatomic, copy)     NSString * _Nonnull localFile;        // 本地存储路径
@property (nonatomic, assign)   RMPDownloadState state;     // 任务状态
@property (nonatomic, assign)   long downloadedBytes;       // 已下载字节数
@property (nonatomic, assign)   long totalBytes;            // 总字节数
@property (nonatomic, copy)     NSString * _Nonnull errorMessage;     // 错误信息
@property (nonatomic, assign)   BOOL allowResume;           // 是否允许恢复（当前版本未实现）
@property (nonatomic, assign)   RMPMonoDownloadErrorCode errorCode;

@end

RTC_OBJC_EXPORT
@interface RMPDownloadConfig : NSObject

@property (nonatomic, assign) int maxConcurrentDownloads;       // 最大并发下载数（当前版本仅支持单任务）
@property (nonatomic, assign) BOOL autoResumeOnStart;           // 启动时自动恢复（当前版本未实现）
@property (nonatomic, assign) BOOL persistTasks;                // 持久化任务（当前版本未实现）
@property (nonatomic, assign) NSString * _Nonnull cacheFilePath;          // 缓存文件路径（空则使用默认路径）
@property (nonatomic, assign) BOOL enableCrcValidation;

@end

RTC_OBJC_EXPORT
@protocol RMPDownloadManagerDelegate <NSObject>
@optional
/// 任务下载状态回调
- (void)downloader:(id _Nullable)downloader onTaskStateChanged:(RMPDownloadState)state taskId:(NSString * _Nonnull)taskId;

/// 任务下载进度回调
- (void)downloader:(id _Nullable)downloader onTaskProgress:(int)progress downloadedBytes:(long)downloadedBytes totalBytes:(long)totalBytes taskId:(NSString * _Nonnull)taskId;

/// 任务下载完成回调
- (void)downloader:(id _Nullable)downloader onTaskCompleted:(NSString * _Nonnull)filePath taskId:(NSString * _Nonnull)taskId;

/// 任务下载失败回调
- (void)downloader:(id _Nullable)downloader onTaskFailed:(RMPMonoDownloadErrorCode)errorCode error:(NSString * _Nonnull)error taskId:(NSString * _Nonnull)taskId;

@end

RTC_OBJC_EXPORT
@interface RMPDownloadManager : NSObject

/// 使用默认配置创建实例
+ (instancetype _Nullable)createWithApLink:(RMPApLink * _Nonnull)aplink
                          config:(RMPDownloadConfig * _Nonnull)config
                        delegate:(id<RMPDownloadManagerDelegate> _Nullable)delegate;

/// 初始化下载管理器
- (void)initialize;

/// 关闭下载管理器
- (void)shutdown;

/// 添加下载任务（可选择是否自动开始）
/// 失败返回 nil
- (NSString * _Nullable)addTaskWithRemoteFile:(NSString * _Nonnull)remoteFile localFile:(NSString * _Nonnull)localFile autoStart:(BOOL)autoStart;

/// 开始任务
- (void)startTask:(NSString * _Nonnull)taskId;

/// 暂停任务（暂不支持）
- (void)pauseTask:(NSString * _Nonnull)taskId;

/// 恢复任务（暂不支持）
- (void)resumeTask:(NSString * _Nonnull)taskId;

/// 取消任务（删除任务和临时文件）
- (void)cancelTask:(NSString * _Nonnull)taskId;

/// 开始所有任务（暂不支持）
- (void)startAll;

/// 暂停所有任务（暂不支持）
- (void)pauseAll;

/// 恢复所有任务（暂不支持）
- (void)resumeAll;

/// 取消所有任务（暂不支持）
- (void)cancelAll;

/// 获取任务信息
- (RMPDownloadTaskInfo * _Nullable)getTask:(NSString * _Nonnull)taskId;

/// 获取所有任务列表
- (NSArray<RMPDownloadTaskInfo*> * _Nonnull)getAllTasks;

/// 获取活跃任务列表
- (NSArray<RMPDownloadTaskInfo*> * _Nonnull)getActiveTasks;

/// 获取任务数量
- (int)getTaskCount;

@end
