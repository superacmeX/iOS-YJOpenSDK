//
//  RMPNetMultiChlVodPlayer.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/9.
//

#import <UIKit/UIKit.h>
#import "RMPlayerStats.h"
#import "RMPlayerDelegate.h"
#import <RMPlayer/RTCVideoSink.h>
#import <RMPlayer/RTCVideoRenderer.h>

RTC_OBJC_EXPORT
@interface RMPNetMultiChlVodPlayer : NSObject

@property(nonatomic, weak) id<RMPlayerDelegate> delegate;

+ (instancetype)createWithConfig:(RMPNetPlayerConfig *)config channelIds:(NSArray<NSNumber *> *)channelIds;

- (BOOL)setRangeStartSec:(long)startSec endSec:(long)endSec seekSec:(long)seekSec;

- (BOOL)muteRemoteAudio:(BOOL)mute;

- (BOOL)start;

- (void)stop;

- (RMPlayerStats *)getStats;

- (BOOL)snapshot:(NSString *)path channelId:(int)channelId;

- (BOOL)startFileRecording:(NSString *)path channelId:(int)channelId;

- (BOOL)stopFileRecording:(int)channelId;

- (void)setSeiDataCallback:(id<RMPSEIDataDelegate>)callback;

- (long)getFileRecordingDuration:(int)channelId;

- (void)pause;

- (void)resume;

- (void)seek:(long)offsetSec;

- (void)setPlaybackSpeed:(int)speed;

/*!
 @abstract 设置接收视频帧数据的接收器
*/
- (void)setVideoSink:(id<RTC_OBJC_TYPE(RTCVideoSink)>)sink;

/*!
 @abstract 根据录像类型播放，参数均透传给设备
 @param startSec 起始时间
 @param type 录像类型
 @param seekSec 偏移时间
*/
- (BOOL)setRecordStartSec:(long)startSec type:(int)type seekSec:(long)seekSec;

/*!
 @abstract 使用setRecordStartSec后，可通过该接口获取录像时长，设备未返回duration时，该接口返回默认值-1
*/
- (long)getTotalDuration;

/*!
@abstract 获取播放会话
*/
- (NSString *)getPlaySession;

- (BOOL)setRecordFile:(NSString *)file seekSec:(long)seekSec;

@end
