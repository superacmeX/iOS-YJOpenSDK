//
//  RMPVersionDef.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/01.
//

#ifndef RMP_VERSION_DEF_H
#define RMP_VERSION_DEF_H

#define RMPLAYER_VERSION            @"v2.4.0-rc.4_release"

#define RMPLAYER_GIT_SHORT_HEAD     @"13e55fe4"

#define RMPLAYER_BUILD_TIME         @"20251121"

#endif //RMP_VERSION_DEF_H
