//
//  RMPMonoDownloader.h
//  rmplayer
//
//  Created by lujiongjian on 2025/7/1.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPMediaSource.h"
#import "RMPMonoDownloadProgress.h"
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@protocol RMPMonoDownloaderDelegate <NSObject>
@optional
/// 下载错误回调
- (void)downloader:(id _Nullable)downloader onError:(RMPMonoDownloadErrorCode)error desc:(NSString *_Nonnull)desc;

/// 下载进度回调
- (void)downloader:(id _Nullable)downloader onProgress:(RMPMonoDownloadProgress *_Nonnull)progress;

/// 下载完成回调
- (void)downloader:(id _Nullable)downloader onFinish:(NSArray<NSString *>  * _Nonnull)files;

@end

RTC_OBJC_EXPORT
@interface RMPMonoDownloader : NSObject

/// 初始化下载管理器
+ (instancetype _Nullable)createWithMediaSource:(RMPMediaSource * _Nonnull)mediaSource delegate:(id<RMPMonoDownloaderDelegate> _Nullable)delegate;

/// 设置下载的文件路径，例如：path/xxx.mp4
- (BOOL)setOutputFile:(NSString * _Nonnull)file;

- (BOOL)start;

- (void)stop;

@end
