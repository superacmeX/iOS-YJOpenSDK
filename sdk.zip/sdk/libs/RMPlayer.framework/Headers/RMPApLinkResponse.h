//
//  RMPApLinkResponse.h
//  rmplayer
//
//  Created by jelin on 2023/10/17.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>


RTC_OBJC_EXPORT
@interface RMPApLinkResponse : NSObject

@property(nonatomic, copy) NSString *response;

/**
 *  0 is ok ,<0 mean failure
 */
@property(nonatomic, assign) NSInteger code;

@end
