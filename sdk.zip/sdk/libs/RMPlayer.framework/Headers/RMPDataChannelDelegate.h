//
//  RMPDataChannelDelegate.h
//  rmplayer
//
//  Created by lujiongjian on 2025/10/16.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@protocol RMPDataChannelDelegate <NSObject>
@optional

/*!
 @abstract 监听设备上报的属性
*/
- (void)onProperty:(NSString * _Nonnull)property;

/*!
 @abstract 监听设备上报的事件
*/
- (void)onEvent:(NSString * _Nonnull)event;

@end
