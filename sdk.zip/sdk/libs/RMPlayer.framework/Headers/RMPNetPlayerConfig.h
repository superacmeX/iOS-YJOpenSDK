//
//  RMPNetPlayerConfig.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/15.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>

@class RMPEngine;
@class RMPNetDeviceParams;

RTC_OBJC_EXPORT
@interface RMPNetConfig : NSObject

/// 设备名
@property(nonatomic, copy, nullable) NSString *deviceName;

/// 产品识别码
@property(nonatomic, copy, nullable) NSString *productKey;

/// 播放器创建所需引擎，外部必须赋值
@property(nonatomic, strong, nullable) RMPEngine *engine;

@property(nonatomic, strong, nullable) RMPNetDeviceParams *params;

@end

RTC_OBJC_EXPORT
@interface RMPNetPlayerConfig : RMPNetConfig
@end
