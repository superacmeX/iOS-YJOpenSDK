//
//  RMPNetDataChannel.h
//  rmplayer
//
//  Created by lujiongjian on 2024/7/16.
//

#import <Foundation/Foundation.h>
#import "RMPTypes.h"
#import "RMPNetRequest.h"
#import "RMPNetDataChannelDelegate.h"
#import "RMPRequest.h"

RTC_OBJC_EXPORT
@interface RMPNetDataChannel : NSObject

@property(nonatomic, weak) id<RMPNetDataChannelDelegate> delegate;

/*!
 @abstract 创建一个通道实例，非单例
*/
+ (instancetype)createWithConfig:(RMPNetConfig *)config;

/*!
 @abstract 返回链接状态
*/
- (BOOL)isConnected;

/*!
 @abstract 发送请求，接收响应。成功通过 RMPNetResponse 返回负载。失败通过 RMPNetRequestStatus 返回错误码及状态原因
           该接口已废弃
*/
- (void)sendRequest:(RMPNetRequest *)request
         onResponse:(RMPNetResponse)response
    onRequestStatus:(RMPNetRequestStatus)requestStatus;

/*!
 @abstract 发送请求，接收响应。结果通过 RMPResponse 返回。
*/
- (void)sendRequest:(RMPRequest *)request
         onResponse:(RMPResponse)response;

/*!
 @abstract 订阅属性
*/
- (BOOL)subscribeProperty;

/*!
 @abstract 取消订阅所有属性
*/
- (BOOL)unsubscribeProperty;

/*!
 @abstract 订阅事件
 @param eventIds 事件id数组
*/
- (BOOL)subscribeEvents:(NSArray<NSString *> *)eventIds;

/*!
 @abstract 取消订阅事件
 @param eventIds 事件id数组
*/
- (BOOL)unsubscribeEvents:(NSArray<NSString *> *)eventIds;

/*!
 @abstract 订阅所有事件
*/
- (BOOL)subscribeAllEvents;

/*!
 @abstract 取消订阅所有事件
*/
- (BOOL)unsubscribeAllEvents;

@end
