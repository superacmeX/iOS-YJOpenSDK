//
//  RMPNetCloudVodDownloader.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/9.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>
#import "RMPTypes.h"

RTC_OBJC_EXPORT
@protocol RMPNetCloudVodDownloaderDelegate <NSObject>
@optional
- (void)downloader:(id)downloader onError:(RMPNetCloudVodDownloaderError)error desc:(NSString *)desc;

- (void)downloader:(id)downloader onFinish:(BOOL)hasPreroll prerollFile:(NSString *)prerollFile normalFiles:(NSArray<NSString *> *)normalFiles;

- (void)downloader:(id)downloader onDownloadProgress:(NSInteger)percent;

@end

RTC_OBJC_EXPORT
@interface RMPNetCloudVodDownloader : NSObject

+ (instancetype)createWithConfig:(RMPNetConfig *)config delegate:(id<RMPNetCloudVodDownloaderDelegate>)delegate;

- (BOOL)setCloudSource:(NSString *)url meta:(NSString *)meta;

- (BOOL)startDownload:(NSString *)mp4File;

- (void)cancel;

@end
