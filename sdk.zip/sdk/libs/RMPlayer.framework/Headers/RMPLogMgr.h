//
//  RMPLogMgr.h
//  rmplayer
//
//  Created by jelin on 2023/10/21.
//

#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>

#import "RMPTypes.h"

RTC_OBJC_EXPORT
@protocol RMPLogDelegate <NSObject>
@optional
-(void)logMsg:(int)level tag:(NSString*)tag msg:(NSString*)msg;
@end

RTC_OBJC_EXPORT
@interface RMPLogMgr : NSObject

+(instancetype)sharedInstance;

@property(nonatomic,weak) id<RMPLogDelegate> delegate;

@property(nonatomic, assign) RMPLogLevel level;

@end
