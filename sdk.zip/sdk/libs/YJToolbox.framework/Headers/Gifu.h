#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double GifuVersionNumber;
FOUNDATION_EXPORT const unsigned char GifuVersionString[];
