//
//  YJAliSignature.h
//  YJEncryptSignature
//
//  Created by zhu shuaishuai on 2023/6/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YJSigClient : NSObject

/// 创建用于签名对象 （2024-05-23 15:22:21 新增）
/// - Parameters:
///
///   - method: HTTP的方法，全部大写，POST/GET
///   - path: Path 地址；例如 /http2test/test
///   - header: 请求头header
///         appKey: 验签appkey (通过传入appkey自动匹配secret，支持海外与国内)； nonce: 随机值 ；timeStamp：时间戳
///   - bodyData: 请求httpBody
///
///
/// - Parameters:
///   - sigAppkey: 外界传入用于签名的appkey 会自动覆盖header中的appkey字段；如果为nil自动获取header中的appkey字段
///   - sigAppSecret: 外界传入用于签名的appsecret；如果为nil，则自动根据appkey匹配
///   - method: HTTP的方法，全部大写，POST/GET
///   - path: Path 地址；例如 /http2test/test
///   - header: 请求头header
///         appKey:   验签appkey (通过传入appkey自动匹配secret，支持海外与国内)； nonce: 随机值 ；timeStamp：时间戳
///   - bodyData: 请求httpBody
+ (YJSigClient *)createSig:(NSString *)sigAppkey
              sigAppSecret:(NSString *)sigAppSecret
                    method:(NSString *)method
                      path:(NSString *)path
                    header:(NSDictionary *)header
                  bodyData:(NSData *)bodyData;


/// 创建用于签名对象
/// - Parameters:
///   - method: HTTP的方法，全部大写，POST/GET
///   - path: Path 地址；例如 /http2test/test
///   - header: 请求头header
///         appKey: 验签appkey (通过传入appkey自动匹配secret，支持海外与国内)； nonce: 随机值 ；timeStamp：时间戳
///   - bodyData: 请求httpBody
+ (YJSigClient *)createSig:(NSString *)method
                      path:(NSString *)path
                    header:(NSDictionary *)header
                  bodyData:(NSData *)bodyData;




@end

@interface YJAPISignature : NSObject
+ (NSDictionary *)sigHeaders:(YJSigClient *)msg;
+ (NSString *)version;
@end

NS_ASSUME_NONNULL_END
