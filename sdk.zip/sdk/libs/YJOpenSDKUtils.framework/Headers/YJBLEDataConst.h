//
//  YJBLEDataConst.h
//  Pods
//
//  Created by zhu shuaishuai on 2024/11/8.
//
//#import <YJOpenSDK/YJOpenSDK-Swift.h>

#ifndef YJBLEDataConst_h
#define YJBLEDataConst_h

    #define YJBLE_BLTETOOTH_FRAME_SIZE 20
    #define YJBLE_BLTETOOTH_MSG_SIZE   19
    #define YJBLE_MAX_BLUETOOTH_MSG_LEN  1214 //2^6*19 = 1216 - 2(msg len take) = 1214
    #define YJBLE_BLUETOOTH_MASK  (Byte)0xC0
    #define YJBLE_BLUETOOTH_START  (Byte)0x80
    #define YJBLE_BLUETOOTH_MIDDLE (Byte)0x00
    #define YJBLE_BLUETOOTH_END  (Byte)0x40
    //#define BLUETOOTH_INTERVAL  40
    #define YJBLE_BLUETOOTH_INTERVAL  100


#endif /* YJBLEDataConst_h */




//void BLEBindLog(NSString *msg ) {
//    [YJBLELog pLog:msg isDebug:false];
//}
