//
//  RMPRecordItem.h
//  rmplayer
//
//  Created by jelin on 2023/10/4.
//


#import <Foundation/Foundation.h>
#import <RMPlayer/RTCMacros.h>

#import "RMPTypes.h"

RTC_OBJC_EXPORT
@interface RMPRecordItem : NSObject

@property(nonatomic, assign) RMPAPLinkRecordType type;
@property(nonatomic, assign) unsigned int bytes;
@property(nonatomic, assign) unsigned int startTime;
@property(nonatomic, assign) unsigned int endTime;

@property(nonatomic, copy) NSString *path;

@end
