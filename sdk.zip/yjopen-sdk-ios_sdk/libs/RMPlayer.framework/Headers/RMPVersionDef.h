//
//  RMPVersionDef.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/01.
//

#ifndef RMP_VERSION_DEF_H
#define RMP_VERSION_DEF_H

#define RMPLAYER_VERSION            @"v1.5.4_release"

#define RMPLAYER_GIT_SHORT_HEAD     @"e6c82a72"

#define RMPLAYER_BUILD_TIME         @"20250401"

#endif //RMP_VERSION_DEF_H
