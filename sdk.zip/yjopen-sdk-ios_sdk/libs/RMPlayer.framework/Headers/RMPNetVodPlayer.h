//
//  RMPNetVodPlayer.h
//  rmplayer
//
//  Created by lujiongjian on 2023/11/9.
//

#import <UIKit/UIKit.h>
#import "RMPlayerStats.h"
#import "RMPlayerDelegate.h"
#import <RMPlayer/RTCVideoRenderer.h>

RTC_OBJC_EXPORT
@interface RMPNetVodPlayer : NSObject

@property(nonatomic, weak) id<RMPlayerDelegate> delegate;

+ (instancetype)createWithConfig:(RMPNetPlayerConfig *)config;

/*!
 @abstract 远端摄像头T卡画面
*/
- (UIView *)playerView;

/*!
 @abstract 设置渲染远端摄像头视频的窗口
*/
- (void)setVideoView:(id<RTC_OBJC_TYPE(RTCVideoRenderer)>)view;

- (BOOL)setRangeStartSec:(long)startSec endSec:(long)endSec seekSec:(long)seekSec;

- (BOOL)muteRemoteAudio:(BOOL)mute;

- (BOOL)start;

- (void)stop;

- (RMPlayerStats *)getStats;

- (BOOL)snapshot:(NSString *)path;

- (BOOL)startFileRecording:(NSString *)path;

- (BOOL)stopFileRecording;

- (void)setSeiDataCallback:(id<RMPSEIDataDelegate>)callback;

- (long)getFileRecordingDuration;

- (void)pause;

- (void)resume;

- (void)seek:(long)offsetSec;

- (void)setPlaybackSpeed:(int)speed;

@end
