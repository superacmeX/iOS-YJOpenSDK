//
//  YJBLESendDataUtil.h
//  YJOpenSDK
//
//  Created by zhu shuaishuai on 2024/11/8.
//  蓝牙发送数据助手

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YJBLESendDataUtil : NSObject

/// 发送数据回调
typedef void (^YJBLESendDataUtilCompletion)(BOOL result, NSError* _Nullable error);

/// 发送数据
/// - Parameters:
///   - dict: json数据
///   - sendAction: 蓝牙发送data行为
///   - completion: 完成回调
- (void)startSendData: (NSDictionary *)dict sendAction: (void(^)(NSData * _Nonnull data))sendAction completion: (YJBLESendDataUtilCompletion)completion;

@end

NS_ASSUME_NONNULL_END
